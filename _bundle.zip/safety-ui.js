(function(root,factory){
  if(typeof module==='object'&&module.exports)module.exports=factory();
  else root.SafetyUI=factory();
})(typeof globalThis!=='undefined'?globalThis:this,function(){
  'use strict';
  const GROUPS=[
    {title:'Avoid buying into an immediate exit',scope:'Buy filter · automatic AND manual UP/DOWN buys',
      note:'Optional extra AND requirement. When this side’s independent Now-only sell is enabled, block a buy if that sell comparison is already true. Missing fresh Coinbase Now also blocks. Other entry and exit rules are unchanged.',
      fields:[['blockNowOnlyEntry','Block buying when the Now-only sell condition is already true']]},
    ...['up','down'].map(p=>({title:p.toUpperCase()+' following trail settings',
      scope:'Independent following exit · '+p.toUpperCase()+' positions only',
      note:'This enable switch controls the selected following method above. Current and Staged use these dollar settings; Volatility instead uses its BTC Now/ATR settings and ignores these dollar activation, giveback and floor values without deleting them. Current example: activate at +$2; $1 pullback gives a +$1 threshold when best is +$2. Floor 0 means estimated break-even after activation, never guaranteed break-even. This is NOT a pre-activation loss stop. Other exits remain independent.',
      fields:[[p+'ProfitTrailEnabled','Enable '+p.toUpperCase()+' selected following trail'],
        [p+'ProfitTrailActivation','Activate at estimated trade profit ($)'],
        [p+'ProfitTrailPullback','Allowed dollar pullback from best profit ($)'],
        [p+'ProfitFloorEnabled','Use minimum profit floor after activation'],
        [p+'ProfitFloor','Minimum estimated profit floor ($; 0 = break-even)']]})),
    {title:'Contract-loss protection',scope:'Independent emergency exits · shared by UP and DOWN',
      note:'Uses the held contract’s sell bid, not Coinbase Now. Either enabled limit can request an exit independently. Optional cooldown waits for a continuous loss breach before latching. Waiting can increase losses beyond your limit; other enabled exits can sell sooner.',
      fields:[
        ['tradeDollarsEnabled','Enable dollar loss exit'],
        ['tradeDollars','Maximum loss per trade ($)'],
        ['tradePercentEnabled','Enable percentage loss exit'],
        ['tradePercent','Maximum loss per trade (%)'],
        ['tradeLossCooldown','Stop-loss cooldown (seconds, 0 = off)'],
      ]},
    {title:'Pause buys, keep exits',scope:'Entry control · does not start the bot',
      note:'Checked and applied: block new automatic and manual buys. Keep the bot running to continue selected exits on its existing position.',
      fields:[['pauseEntries','Pause all new buys']]},
    {title:'Market and trading-day limits',scope:'Blocks new buys · does not force an open trade to close',
      note:'Limits latch when reached. Loss totals include realized P&L plus the fresh bid-based estimate for the remaining position. The trading day resets at midnight in New York.',
      fields:[
        ['marketLossEnabled','Enable market loss cap'],['marketLoss','Maximum market loss ($)'],
        ['dayLossEnabled','Enable trading-day loss cap'],['dayLoss','Maximum trading-day loss ($)'],
        ['losingTradesEnabled','Enable daily losing-trade cap'],['losingTrades','Maximum losing trades per day'],
      ]},
    {title:'Spread and displayed liquidity',scope:'Buy filters only · never blocks protective sells',
      note:'Reject wide spreads or insufficient displayed depth. Orderbook depth is a snapshot, not a promise that the liquidity will remain available.',
      fields:[
        ['spreadEnabled','Enable bid–ask spread filter'],['maxSpread','Maximum bid–ask spread (¢)'],
        ['depthEnabled','Enable displayed-depth filter'],['depthCoverage','Depth coverage (× planned contracts)'],
        ['depthTolerance','Depth price range (¢)'],
      ]},
    {title:'Feed age and disagreement',scope:'Buy filter only · contract-loss exits use Kalshi quotes',
      note:'Require recent Coinbase, another recent USD venue and a recent Kalshi quote. Compare the range of recent venue prices, not the display-only Kalshi index.',
      fields:[
        ['feedEnabled','Enable stricter feed guard'],['maxFeedAge','Maximum feed age (seconds)'],
        ['maxVenueGap','Maximum venue price range ($)'],
      ]},
    {title:'Entry confirmation and re-entry',scope:'Automatic buys only · manual buys bypass these two checks',
      note:'Require a continuous buy signal, or a genuinely new signal after re-entry cooldown. Existing cooldown and maximum-trades settings still apply.',
      fields:[
        ['confirmEnabled','Enable extra entry confirmation'],['confirmSeconds','Continuous entry confirmation (seconds)'],
        ['freshReentryEnabled','Require a new signal after cooldown'],
      ]},
    {title:'Immediate protection before buying',scope:'Automatic buys only · manual buys bypass this requirement',
      note:'When checked, automatic UP buys require UP entry-point protection; DOWN buys require DOWN entry-point protection. Fresh Now must be available to anchor the stop. Enable the matching protection in UP & DOWN rules. This never waits for trailing activation and does not guarantee an exit fill.',
      fields:[['requireEntryProtection','Require entry-point protection before automatic buys']]},
  ];
  const LABELS=Object.fromEntries(GROUPS.flatMap(g=>g.fields));
  const EXIT_CAVEAT='These are backend-managed exit attempts, not exchange-resting stop orders. The bot must be running; Live/Demo must remain armed. They cannot protect you when this backend stops or cannot reach Kalshi. Fills, prices, fees and losses are not guaranteed. No stop can guarantee break-even or prevent every rapid loss.';
  const APPLIED='All new switches default OFF. Edit this section, then use Apply Safety Controls. Opening help, editing a draft or expanding a section sends no order. Applying limits to an existing running trade can request an exit on the next fresh evaluation. Start/stop and mode are never changed by Apply.';
  const LOSS='For UP and DOWN alike, estimate the position using that held contract’s current Kalshi sell bid. Estimated whole-trade P&L equals realized partial-close P&L plus remaining bid value minus remaining entry cost, remaining entry fees and estimated exit fees. Percentage loss uses the total recorded buy cost including entry fees. This is not the Coinbase-minus-target Now number, the ask/button percentage, leverage or an account-wide stop.\n\nA loss equal to or larger than either enabled limit latches that exit immediately when stop-loss cooldown is 0 (default). With a nonzero cooldown, at least one enabled loss limit must remain reached on fresh marks for the entire interval before a new exit is latched. Recovery above both limits resets the pending wait. This bypasses spread qualification, LOW/HIGH sell waits, trailing/staircase activation, opening warm-ups and all entry filters, but not its own optional cooldown. Delaying a stop-loss can increase losses. Recovery after a confirmed latch does not cancel it or add another cooldown; existing confirmed latches are honored immediately. Failed or partial closes remain monitored and are revalidated before retry. A zero sell bid can satisfy a loss condition but cannot execute a sale; the app waits for an executable fresh bid.\n\nThe rule needs this copy’s own recorded position and a Kalshi quote no older than ten seconds, in the current open market. A stale/missing Coinbase feed alone does not block this exit. Stopped monitoring does not create a new loss latch. Turning the relevant loss rule OFF disables that exit path; its recorded latch is retained if you turn it back ON for the same trade. Other enabled exits can still sell sooner.\n\nPaper estimates use the existing zero-fee Paper fill model. Demo/Live use recorded entry fees plus the app’s estimated taker exit fee; actual fees and fills can differ. Legacy positions with no original full-trade cost/realized-partial history use the recorded remaining lot as the available basis; old missing information is never invented.';
  const CAPS='Shared by UP and DOWN within this app copy and trading mode. Market loss uses this market’s realized net P&L plus any fresh bid-based remaining-position estimate. Trading-day loss uses realized net P&L recorded since New York midnight plus that estimate. Profits offset losses in these net totals. Without a fresh position mark, the displayed totals are realized-only and the missing estimate is disclosed.\n\nReaching the inclusive loss threshold locks NEW buys. It does not liquidate the current position: enable a trade-loss exit separately if desired. Selected exits and manual closes remain allowed. A latched market lock lasts until the next ticker; a daily lock lasts until midnight America/New_York, including daylight-saving changes. Raising a number does not erase its existing lock. Explicitly disabling that cap overrides its lock; re-enabling in the same scope restores it.\n\nCounters and locks are private backend state, separate from displayed Results. Stop/start, restart, resetting Paper cash, clearing Results, loading a profile and changing a cooldown do not erase them. Paper/Demo/Live counters are separate. Initial migration can use only the retained history; already-deleted or older truncated history cannot be reconstructed.';
  const FILTERS='This is a NEW-BUY filter for both automatic and manual buys. It never blocks a protective sell. OFF means this extra filter is ignored, not that the app’s existing fresh-data, inventory, cooldown, market-entry cap, final-five-seconds or arming checks disappear. Enabled filters must all pass; missing or stale required data blocks entry rather than assuming it is safe.';
  function help(defaults){
    const text={
      blockNowOnlyEntry:'Optional NEW-BUY guard for automatic AND manual UP/DOWN buys, across every entry method. If the selected side’s independent Now-only exit is enabled, require its sell comparison to be FALSE on fresh Coinbase Now. Example: DOWN sells when Now is above −20. Now +59 blocks a DOWN buy, while −20 does not trigger this strict above comparison. UP works the same way with its own below/above choice and threshold. Missing fresh data fails closed. A disabled side-specific Now-only sell is ignored. The guard is checked again immediately before submission, including after asynchronous funding and on retries. It does not block manual or protective sells, replace entries, disable other exits, guarantee profit, start or arm trading. This does not inspect every possible compound or LOW/HIGH sell condition. Default OFF; requires backend44.',
      tradeDollarsEnabled:LOSS,tradeDollars:'Dollar loss allowed for one recorded trade. Example: a $10 total buy with a $2 limit requests an exit when estimated net whole-trade P&L is −$2 or worse, after any configured stop-loss cooldown. Inclusive comparison. Larger numbers allow larger losses. Allowed $0.01–$100,000.\n\n'+LOSS,
      tradePercentEnabled:LOSS,tradePercent:'Percentage of recorded total buy cost, including entry fees, allowed to be lost. Example: $10 cost and 20% means an estimated $2 loss. This is a loss percentage, not the UP/DOWN button value. Inclusive comparison; allowed 0.01–100%.\n\n'+LOSS,
      tradeLossCooldown:'Optional continuous wait before a NEW contract-loss exit latches, shared by dollar and percentage loss rules for both UP and DOWN. Allowed 0–300 seconds, including decimals; 0 (default) keeps immediate loss latching. Example: $2 loss limit and 3 seconds requires the estimated loss to remain $2 or worse for about 3 seconds before the stop-loss can sell. Recovery before then cancels the pending wait. Waiting may allow a larger loss or miss the opportunity to exit; candles cannot predict a recovery.\n\nRecovery above BOTH enabled limits, a stale/missing Kalshi quote, Stop/start, a monitoring gap over 3.5s, changing the loss plan, a different trade/side/market, applying Safety Controls or loading a profile restarts the pending timer. Backend restart clears unconfirmed timers. It requires fresh held-contract values at the end and does not depend on Coinbase or buy filters. Once latched, the existing stop-loss continues retrying after recovery, with no repeat cooldown on partial or failed closes. Existing confirmed latches are never delayed. LOW/HIGH, timed cash-out, profit trailing, entry protection, regular and manual sells are not delayed by this setting and can sell sooner. Applying never starts or arms a bot. Requires backend49.\n\n'+EXIT_CAVEAT,
      pauseEntries:'Checked and applied: block every new UP/DOWN buy, automatic or manual. It does not sell immediately, close positions, disarm trading, or stop the running bot. Its selected regular and independent exits continue normally. It does not make disabled exits active.\n\nUnchecked and applied: allow buys again only when all ordinary eligibility, cooldown, safety and signal conditions pass. This can permit a new buy on the next evaluation if the bot is running. The dashboard shortcut changes only this flag and never saves unrelated form drafts. The paused preference persists and is included in profiles; runtime running/arming does not persist across restart.\n\nStop all automation is different: it stops automatic buys AND sells and disarms exchange trading. With an owned open position, its in-page warning must be confirmed. No software protection operates while stopped.',
      marketLossEnabled:CAPS,marketLoss:'Maximum net dollar loss for the current ticker, shared by UP/DOWN. Example: −$6 realized plus −$4 estimated on the remaining position reaches a $10 cap. Equality locks new buys. Allowed $0.01–$100,000.\n\n'+CAPS,
      dayLossEnabled:CAPS,dayLoss:'Maximum net dollar loss for the New York trading day. Example: a $25 cap locks new buys at −$25 or worse in the stated net total. It is not a rolling 24-hour window or a server-restart session. Allowed $0.01–$100,000.\n\n'+CAPS,
      losingTradesEnabled:'Lock new buys when the day’s number of completed losing positions reaches the editable count. A completed position is losing when its whole-trade realized P&L, including recorded entry/exit fees and partial closes, is negative. Winning trades do not subtract from this count; this is not a consecutive-loss streak. Partial sell rows do not count as separate new losing trades.\n\nLegacy rows that lack completion metadata are conservatively treated as completed loss events; the app cannot reconstruct already-deleted trades. The display states this initialization limitation.\n\n'+CAPS,
      losingTrades:'Whole number of completed losing trades allowed before new buys lock for the New York day. Default value 3, switch OFF. The third completed loser reaches a limit of 3. Does not close an open position. Allowed 1–1,000.\n\n'+CAPS,
      spreadEnabled:FILTERS+'\n\nSpread = held-side ask minus that side’s bid in contract cents. Equality to the maximum passes; negative/crossed or missing quotes fail. This is not the multi-exchange BTC dollar spread. Both UP and DOWN use the same maximum.',
      maxSpread:'Maximum allowed entry bid–ask gap in contract cents. Example: ask60¢ and bid58¢ gives a 2¢ spread; maximum2 passes, maximum1 blocks. This does not set the buy price or slippage tolerance. Allowed 0.01–99¢.\n\n'+FILTERS,
      depthEnabled:FILTERS+'\n\nRead Kalshi’s public fixed-point event orderbook and derive asks from opposite-side bids. Require displayed buy-side AND immediate resale-side quantity at least planned contracts × coverage, within the configured price range and the order’s smaller actual slippage range. Paper orders have zero slippage, so only depth at the quoted entry/exit price counts.\n\nBook must match this ticker, be no older than five seconds, and have best quotes consistent with the market quote. Missing/empty/malformed/rate-limited books fail this filter. Refresh is bounded (about1.5s plus an entry recheck);429 backs off five seconds. Displayed depth can disappear before your order arrives; this is not spoof detection or a guaranteed full fill.',
      depthCoverage:'Required displayed quantity on EACH of the planned buy and immediate-resale sides, as a multiple of the calculated contract count. Example:12 planned contracts ×2 requires at least24 contracts on each side in the permitted range. Quantities are parsed as actual fixed-point contract counts, not price levels or order counts. Allowed1–20×.\n\n'+FILTERS,
      depthTolerance:'Number of contract cents from the quoted buy ask or resale bid within which depth may count. This is a depth measurement, not additional order slippage. The smaller of this value and the actual order slippage is used; Paper’s zero slippage counts only quoted-price-or-better levels. Example: ask60¢, tolerance2¢, actual slippage1¢ counts asks only up to61¢. Allowed0–20¢.\n\n'+FILTERS,
      feedEnabled:FILTERS+'\n\nRequire Coinbase and at least one other recent USD venue within the age limit, plus a recent Kalshi quote. Among eligible recent venues, compare highest price minus lowest price to the editable maximum. Equality passes. At least two qualifying venues are needed; old/missing venues cannot fill this requirement.\n\nThis does not use the display-only Kalshi index, prove manipulation or synchronize exchange trade timestamps. Existing base freshness checks still apply even with this option OFF. Contract-loss exits independently need a fresh Kalshi quote, not Coinbase availability.',
      maxFeedAge:'Maximum receipt age for Coinbase, at least one other eligible USD venue, and the Kalshi quote before a new buy. Example:3 seconds rejects a4-second Coinbase sample. Allowed1–15seconds; Kalshi still has the stricter existing ten-second ceiling. Future/negative ages are rejected.\n\n'+FILTERS,
      maxVenueGap:'Maximum highest-minus-lowest price among eligible recent USD venue prices, in BTC price dollars. Example:70,000 and70,040 gives a $40 range. A $50 maximum passes; $30 blocks. Coinbase and another recent venue must be present. Equality passes; allowed $0–$100,000.\n\n'+FILTERS,
      confirmEnabled:'Automatic buys only: require the existing selected buy signal and all enabled entry filters to remain valid continuously for the editable duration. Contract-price mode requires its price AND signed Now signal; spread mode still also needs its existing entry qualification. The timers run alongside each other, not as a reason to delay emergency exits.\n\nA broken signal, filter failure, stale/missing data, cooldown/inventory block, pause, stopped bot, settings apply or sampling gap longer than3.5seconds resets confirmation. Zero seconds means no extra delay. Manual Buy bypasses this signal timer, but still obeys entry filters and limits. The signal is rechecked before the order is submitted; confirmation cannot guarantee a profitable entry.',
      confirmSeconds:'Additional continuous entry-confirmation duration for automatic buys in seconds. Default5 with the switch OFF. Allowed0–300;0 adds no delay. This is not candle-close waiting, a sell delay, trailing recovery time or the re-entry cooldown.\n\nThe selected buy conditions and enabled filters must remain valid for the whole duration, and spread mode’s ordinary timer must also qualify. A larger value can avoid short-lived signals but can also miss or delay entries. No best-profit claim.',
      freshReentryEnabled:'Automatic re-entry only, after a recorded completed sell and the existing cooldown. First observe the selected buy signal FALSE on fresh eligible data AFTER cooldown; then wait for it to become TRUE again and satisfy enabled confirmation. A signal that simply stayed true throughout the sell/cooldown cannot immediately buy again.\n\nApplied independently for UP and DOWN. Spread mode observes its selected underlying BUY comparisons, not merely a temporarily unqualified timer. Missing/stale data does not count as the required false signal. Stop/start, edits, pause and ineligible periods clear observation, so a new post-eligibility reset is required. Existing re-entry permission and maximum trades per market still apply. First entries and manual buys bypass this crossing requirement. It does not force buying the opposite direction.',
    };
    const out={};
    for(const p of ['up','down']){
      const common=`Independent ${p.toUpperCase()} money-based trailing exit. Uses the recorded held contract’s fresh sell bid, realized partial-sale P&L, remaining buy cost and recorded entry fees plus estimated exit fees. Paper uses its existing zero-fee model. This is not BTC-reference movement, contract button percentage, or the chart BUY value. Activation and breach comparisons are inclusive. Only fresh executable bids observed while running can raise the peak. This is a sampled estimate, not a guaranteed full-position cash-out quote. Other selected exits can sell sooner.\n\nExample: activation $2 and pullback $1. Before estimated profit reaches +$2 there is no profit-trail barrier. Best +$2 sets the threshold to +$1; best +$4 raises it to +$3. A retreat to +$3 or below latches an exit attempt on the first fresh observation, with no extra confirmation timer. Recovery does not cancel a latched attempt. Partial or failed closes keep monitoring. Stale quotes pause execution; zero bids cannot execute. Stop disables observations and automatic exits while retaining the position and saved peak. Restart never starts or arms trading.\n\nOptional minimum floor applies ONLY after activation. With floor $0, the threshold cannot go below estimated net break-even. With floor $1, it cannot go below +$1. The floor must be at/below activation. Without a floor, a pullback larger than activation can allow a negative threshold. Neither floor prevents an actual losing fill or substitutes for pre-activation contract-loss protection.\n\nApplying changes affects an existing trade too. Changing this side’s plan starts a new observation key and peak, never reconstructing a historical high; applying an unrelated safety field preserves it. Turning this master OFF disables this exit path. Default master and floor switches OFF; requires backend44.`;
      for(const suffix of ['ProfitTrailEnabled','ProfitTrailActivation','ProfitTrailPullback','ProfitFloorEnabled','ProfitFloor'])
        text[p+suffix]={
          ProfitTrailEnabled:'Master switch. Check this, set an activation and pullback, optionally choose a floor, then Apply Safety Controls. Merely editing a number or checking the floor does not enable the trail. Example: a DOWN contract can gain dollar value while the BTC chart falls; this follows that held DOWN contract’s estimated profit.',
          ProfitTrailActivation:'Dollar profit needed before this trail starts. Example: $10 recorded trade cost, activation $2: estimated net trade value must first show +$2. At +$1.99 this trail does not protect the position. Allowed $0.01–$100,000; use a separate loss exit before activation.',
          ProfitTrailPullback:'Dollar retreat allowed from the best observed estimated trade profit, not a percentage of BTC. Example: best +$4 and pullback $1 sets +$3; a larger pullback $2 sets +$2. Smaller values allow less retreat but can exit on smaller fluctuations. Allowed $0.01–$100,000.',
          ProfitFloorEnabled:'Optional lower bound for the exit threshold, only after this side’s profit trail activates. Example: activation $2, pullback $5 would otherwise start at −$3; floor $0 raises that to estimated break-even. This checkbox alone does not enable the master trail.',
          ProfitFloor:'Nonnegative estimated dollar profit floor after activation. Use 0 for estimated break-even or, for example, 1 for a +$1 minimum threshold. Allowed $0–$100,000, and it must be at/below activation when checked. A floor equal to activation can request a sale as soon as activation occurs. Actual fills may still realize a loss.',
        }[suffix]+'\n\n'+common;
    }
    text.requireEntryProtection='Optional automatic-buy requirement. When ON, an UP buy needs UP entry-point protection enabled in UP & DOWN rules; a DOWN buy needs its own DOWN protection enabled. Fresh finite Coinbase-minus-target Now must be available to record the entry anchor. The final order preflight checks this again. This adds an AND gate to your existing entry rules and does not replace price, signed Now, confirmation, cooldown or trade limits. Manual buys bypass this one requirement, but enabled protection still applies to their recorded positions when the bot is running. It does not start or arm the bot, guarantee a fill or cap losses. Default OFF preserves existing entry behavior. Requires backend29.';
    for(const [key,def]of Object.entries(defaults)){
      if(!text[key])throw new Error('Missing safety option help: '+key);
      out['safe_'+key]=(key.includes('Profit')?'Optional following choice: this side’s existing master switch controls Current, Staged or Volatility. The dollar inputs/floor described here apply only to Current and Staged; Volatility uses BTC Now/ATR and does not apply a dollar-profit floor. Saved dollar values are retained when changing choice.\n\n':'')+
        text[key]+'\n\nFactory default: '+(typeof def==='boolean'?(def?'ON':'OFF'):def)+'. '+APPLIED+
        ((key.startsWith('trade')||key.includes('Profit'))?'\n\n'+EXIT_CAVEAT:'');
    }
    out.safetyHelpAnchor='These are separate optional safeguards, shared by UP and DOWN. Emergency trade-loss exits use an OR decision: either enabled loss limit can sell. All enabled entry filters must pass together. Market/day caps and pause block new buys only; they do not force a position to close.\n\n'+APPLIED+'\n\n'+EXIT_CAVEAT;
    return out;
  }
  function create(engine){
    const $=id=>document.getElementById(id),host=$('safetyGroups');
    let snapshot;
    for(const g of GROUPS){
      const d=document.createElement('details');d.className='safety-group';d.dataset.testid='safety-group-'+g.fields[0][0];
      const summary=document.createElement('summary'),title=document.createElement('span'),badge=document.createElement('span');
      title.textContent=g.title;badge.className='safety-group-state';summary.append(title,badge);
      const field=document.createElement('fieldset'),legend=document.createElement('legend');legend.textContent=g.scope;
      field.append(legend);
      const note=document.createElement('p');note.className='small muted';note.textContent=g.note;field.append(note);
      if(g.fields.some(([k])=>k==='tradeLossCooldown')){
        const compatibility=document.createElement('p');compatibility.id='stopLossCooldownCompatibility';
        compatibility.className='notice small';
        compatibility.textContent='Stop-loss cooldown NOT ACTIVE until approved backend49 restart. Its input is locked; existing loss protection is unchanged.';
        field.append(compatibility);
      }
      for(const [key,label]of g.fields){
        const id='safe_'+key,control=document.createElement('input'),l=document.createElement('label');
        control.id=id;control.dataset.testid='input-safety-'+key;l.htmlFor=id;l.textContent=label;
        if(typeof engine.DEFAULTS[key]==='boolean'){
          control.type='checkbox';l.className='rule-toggle';l.prepend(control);field.append(l);
        }else{
          const row=document.createElement('div');row.className='field-row';
          control.type='number';control.inputMode='decimal';control.min=engine.LIMITS[key][0];control.max=engine.LIMITS[key][1];
          control.step=key==='losingTrades'?'1':'0.01';row.append(l,control);field.append(row);
        }
      }
      d.append(summary,field);host.append(d);
    }
    function fill(s,applied=s){
      const v=engine.validate(s||{});
      snapshot=engine.validate(applied||{});
      for(const [key,value]of Object.entries(v)){
        const input=$('safe_'+key);if(input.type==='checkbox')input.checked=value;else input.value=value;
      }
    }
    function read(){return engine.validate(Object.fromEntries(Object.keys(engine.DEFAULTS).map(key=>{
      const input=$('safe_'+key);return [key,input.type==='checkbox'?input.checked:input.value];
    })));}
    function dirty(saved){const d=read(),v=engine.validate(saved||{});return Object.keys(v).some(k=>d[k]!==v[k]);}
    function render(state,disconnected,pending){
      if(!state)return;
      const s=engine.validate(state.settings.safety||{}),r=state.safety;
      $('safe_requireEntryProtection').disabled=pending||disconnected||!state.features?.requireEntryProtection;
      const supported=state.features?.profitProtection===true;
      $('profitProtectionCompatibility').hidden=supported;
      for(const k of engine.NEW_KEYS)$('safe_'+k).disabled=pending||disconnected||!supported;
      const lossCooldownSupported=state.features?.stopLossCooldown===true;
      $('safe_tradeLossCooldown').disabled=pending||disconnected||!lossCooldownSupported;
      $('stopLossCooldownCompatibility').hidden=lossCooldownSupported;
      let draft,invalid=false;try{draft=read();}catch{invalid=true;}
      const isDirty=invalid||Object.keys(s).some(k=>draft[k]!==s[k]);
      $('safetyAppliedState').textContent=disconnected?'CONNECTION UNKNOWN':!r?'BACKEND UPDATE NEEDED':
        isDirty?'UNSAVED DRAFT':Object.values(s).filter(v=>v===true).length+' OPTIONS ON';
      $('safetySaveState').textContent=invalid?'Fix the invalid value before applying.':
        isDirty?'Draft only. Applied safety rules have not changed.':
        'Applied to this copy. All limits are editable; test in Paper first.';
      $('applySafety').disabled=pending||disconnected||!r;
      for(const [i,g]of GROUPS.entries()){
        const enabled=g.fields.filter(([k])=>typeof s[k]==='boolean').some(([k])=>$('safe_'+k).checked);
        const changed=g.fields.some(([k])=>invalid?$('safe_'+k).value==='':draft[k]!==s[k]);
        const badge=host.children[i].querySelector('.safety-group-state');
        badge.textContent=(enabled?'ON':'OFF')+(changed?' · draft':'');badge.classList.toggle('positive',enabled);
      }
      $('pauseBuys').disabled=pending||disconnected||!state.running||!r;
      $('pauseBuys').textContent=s.pauseEntries?'Resume new buys':'Pause new buys';
      $('safetyRuntime').textContent=disconnected?'Backend connection lost. Safety status unknown.':
        !state.running?'STOPPED: automatic buys AND sells are off.':
          s.pauseEntries?'EXITS RUNNING: new buys paused.':'RUNNING: selected entries and exits enabled.';
      if(!r){$('safetyEntryStatus').textContent='Waiting for updated backend safety support.';return;}
      $('safetyEntryStatus').textContent=disconnected?'Entry safety state unknown.':
        r.blockers.length?r.blockers.join(' '):'No market/day/pause lock. Entry signals and filters must still pass.';
      const loss=r.contractLoss,own=!!state.openTrade&&state.openTrade.ticker===state.market?.ticker;
      $('safetyLossStatus').textContent=disconnected?'Contract-loss exit state unknown.':
        !s.tradeDollarsEnabled&&!s.tradePercentEnabled?'Contract-loss exits OFF.':
        !own?'Contract-loss protection enabled · no strategy-owned position.':
        `${state.openTrade.side==='yes'?'UP':'DOWN'} loss protection · ${loss?.action==='EXIT_WAIT'?'COOLDOWN':loss?.action||'WAITING'}`;
      $('safetyLossDetail').textContent=loss?.reason||'Independent loss exits use the held contract’s sell bid, not Coinbase Now. No fill or break-even guarantee.';
      const profit=r.contractProfit;
      const profitText=!supported?'Contract-profit trail NOT ACTIVE: approved backend44 restart required.':
        disconnected?'Contract-profit state unknown: backend disconnected.':
        !own?'No owned position. UP profit trail '+(s.upProfitTrailEnabled?'ON':'OFF')+
          ' · DOWN profit trail '+(s.downProfitTrailEnabled?'ON':'OFF')+'.':
        !state.running?'STOPPED: contract-profit automatic exits are off. Recorded position and peak retained.':
        profit?.reason||'Waiting for a fresh backend profit evaluation.';
      $('safetyProfitStatus').textContent=profitText;
      $('profitTrailSummary').textContent=profitText;
      $('positionProfitStatus').textContent=profitText;
      $('safetyProtectionWarning').textContent=(!s.tradeDollarsEnabled&&!s.tradePercentEnabled?
        'Contract-loss exits are OFF. Neither chart trailing nor profit trailing protects against losses before activation. Review the separate loss limits; no exit or maximum loss is guaranteed.':
        'Loss limits and profit trailing are independent exits. Other enabled rules may sell first; fills and maximum loss are not guaranteed.')+
        (s.tradeLossCooldown>0?` Stop-loss cooldown ${s.tradeLossCooldown}s: waiting can increase losses beyond the configured limit.`:'');
      $('safetyTotals').textContent=`${state.settings.mode.toUpperCase()} · New York day ${r.day} · market estimate ${money(r.marketPnl)} · day estimate ${money(r.dayPnl)} · ${r.losers} completed losers.`;
      $('safetyMarkNote').textContent=own&&!r.mark?'Open-position estimate unavailable; totals currently include realized P&L only.':
        r.mark?`Bid-based estimated whole-trade P&L ${money(r.mark.pnl)}${Number.isFinite(r.mark.lossPercent)?' · loss '+Math.max(0,r.mark.lossPercent).toFixed(2)+'%':''}. Actual fills/fees may differ.`:
          'Totals persist independently of Results. Legacy initialization can use only retained history.';
      const rows=[];
      for(const side of ['UP','DOWN']){
      for(const c of r.filters?.[side]?.checks||[])rows.push([side+' · '+c.name,
          !c.enabled?'OFF':c.passed?'PASS':'BLOCKED',c.detail]);
        const e=r.entries?.[side];
        rows.push([side+' · Automatic entry',!state.running?'STOPPED':e?.passed?'READY':'WAIT',e?.reason||'Waiting for eligible fresh entry data.']);
      }
      $('safetyChecks').replaceChildren(...rows.map(([name,status,detail])=>{
        const li=document.createElement('li'),head=document.createElement('div'),label=document.createElement('span'),
          strong=document.createElement('strong'),p=document.createElement('p');
        label.textContent=name;strong.textContent=disconnected?'UNKNOWN':status;
        head.append(label,strong);p.textContent=detail;p.className='small muted';li.append(head,p);return li;
      }));
    }
    function money(v){return (v<0?'−':'')+'$'+Math.abs(v).toFixed(2);}
    fill(engine.DEFAULTS);
    return {fill,read,dirty,render,expected:()=>({...snapshot})};
  }
  return {GROUPS,LABELS,help,create};
});
