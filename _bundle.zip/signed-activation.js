(function(root,factory){
  const api=factory();
  if(typeof module==='object'&&module.exports)module.exports=api;
  else root.SignedDownActivation=api;
})(typeof globalThis!=='undefined'?globalThis:this,function(){
  'use strict';
  // Native number inputs may discard a Unicode minus and keep the positive digits.
  // Keep the raw text until this parser converts an explicit sign to a number.
  function number(raw){
    if(!['string','number'].includes(typeof raw))return NaN;
    const s=String(raw).trim().replace(/^[\u2212\u2013\u2014\uFE63\uFF0D]/,'-')
      .replace(/^(-)\s+(?=[\d.])/,'$1');
    if(!/^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?$/.test(s))return NaN;
    return Number(s);
  }
  function read(raw){
    const n=number(raw);
    if(!Number.isFinite(n)||n < -100000||n>0)
      throw Error('DOWN trailing activation: enter a signed Now value from -100000 to 0, such as -40. Use the minus-sign button if your keyboard cannot enter it.');
    return n===0?0:n;
  }
  function makeNegative(raw){
    const n=number(raw);
    if(!Number.isFinite(n)||Math.abs(n)>100000)
      throw Error('Enter an activation amount from 0 to 100000 first, then use the minus-sign button.');
    return n===0?0:-Math.abs(n);
  }
  return {read,makeNegative};
});
