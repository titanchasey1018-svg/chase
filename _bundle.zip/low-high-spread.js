(function(root,factory){
  const api=factory();
  if(typeof module==='object'&&module.exports)module.exports=api;
  else root.LowHighSpread=api;
})(globalThis,function(){
  'use strict';
  const DEFAULTS={};
  for(const p of ['up','down'])for(const kind of ['Low','High'])
    Object.assign(DEFAULTS,{[p+kind+'UseSpread']:false,[p+kind+'SpreadLevel']:null});
  Object.freeze(DEFAULTS);
  const KEYS=Object.freeze(Object.keys(DEFAULTS));
  function preserve(input,current={}){
    if(!input||typeof input!=='object'||Array.isArray(input))return input;
    const out={...input};
    for(const k of KEYS)if(!Object.hasOwn(out,k))out[k]=current?.[k]??DEFAULTS[k];
    return out;
  }
  function forBackend(config,features){
    const out={...config};
    if(features?.lowHighExchangeSpread!==true){
      if(KEYS.some(k=>k.endsWith('UseSpread')&&out[k]===true))
        throw Error('LOW/HIGH Exchange spread is NOT ACTIVE until an approved backend restart. Existing source edits remain available.');
      for(const k of KEYS)delete out[k];
    }
    return out;
  }
  return {DEFAULTS,KEYS,preserve,forBackend};
});
