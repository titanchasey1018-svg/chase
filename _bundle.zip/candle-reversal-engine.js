(function(root,factory){
  if(typeof module==='object'&&module.exports)module.exports=factory();
  else root.CandleReversal=factory();
})(typeof globalThis!=='undefined'?globalThis:this,function(){
  'use strict';
  const DEFAULTS=Object.freeze(Object.fromEntries(['up','down'].flatMap(p=>[
    [p+'Enabled',false],[p+'Mode','timed'],[p+'RequireFavorable',true],
    [p+'ActivationEnabled',true],[p+'Activation',2],[p+'Seconds',10],[p+'MinProfit',.5],
  ])));
  function validate(input={}){
    if(!input||typeof input!=='object'||Array.isArray(input))throw Error('Candle exit settings must be an object.');
    if(Object.keys(input).some(k=>!Object.hasOwn(DEFAULTS,k)))throw Error('Unknown candle exit setting.');
    const out={};
    for(const [k,d]of Object.entries(DEFAULTS)){
      const v=Object.hasOwn(input,k)?input[k]:d;
      if(typeof d==='boolean'){
        if(typeof v!=='boolean')throw Error(k+': use a checkbox.');out[k]=v;
      }else if(k.endsWith('Mode')){
        if(!['timed','closed'].includes(v))throw Error('Choose timed forming candle or completed candle.');
        out[k]=v;
      }else{
        const n=Number(v),min=k.endsWith('Activation')?.01:0,max=k.endsWith('Seconds')?59:100000;
        if(!['number','string'].includes(typeof v)||String(v).trim()===''||!Number.isFinite(n)||n<min||n>max)
          throw Error(k+': enter '+min+' to '+max+'.');
        out[k]=n;
      }
    }
    return out;
  }
  function evaluate(config,open,mark,tape,now,running,previous){
    const c=validate(config),p=open?.side==='no'?'down':'up',up=p==='up';
    const key=JSON.stringify([open?.tradeId||open?.startedAt,open?.ticker,open?.side,c]);
    let state=previous?.key===key?{...previous}:{key,armed:false,armedAt:null,
      favorable:false,since:null,last:null,monitorAt:now};
    const enabled=c[p+'Enabled'],requiredMs=c[p+'Seconds']*1000;
    const finish=(action,reason,extra={})=>({state,enabled,action,reason,mode:c[p+'Mode'],
      armed:state.armed,favorable:state.favorable,requiredMs,
      elapsedMs:state.since==null?0:Math.max(0,now-state.since),minProfit:c[p+'MinProfit'],
      pnl:mark?.pnl??null,...extra});
    if(!enabled||!running||!open){
      state={key,armed:false,armedAt:null,favorable:false,since:null,last:null,monitorAt:now};
      return finish(!enabled?'OFF':!running?'STOPPED':'NO_POSITION',
        !enabled?p.toUpperCase()+' candle exit OFF.':!running?
          'Stopped: candle exit observes no position and sends no automatic sell.':'No owned position.');
    }
    const gap=state.last==null||now<state.last||now-state.last>3000;
    if(gap){state.since=null;if(state.last!=null)state.monitorAt=now;}
    state.last=now;
    if(!tape?.ready||!tape.fresh||!tape.current?.openKnown||
      !Number.isFinite(tape.sourceAt)||now-tape.sourceAt>3000||now<tape.sourceAt-250||
      !Number.isFinite(tape.observedAt)||now-tape.observedAt>3000||now<tape.observedAt){
      state.since=null;state.monitorAt=now;return finish('PAUSED','Candle exit paused: fresh, known-open Coinbase candle required.');
    }
    const entered=open.startedAt;
    if(!Number.isFinite(entered)||tape.sourceAt<entered){
      state.since=null;return finish('PAUSED','Waiting for a candle observation after the recorded buy.');
    }
    const bar=tape.current,favorable=up?'green':'red',reversal=up?'red':'green';
    if(bar.color===favorable)state.favorable=true;
    if(!mark||!Number.isFinite(mark.pnl)||!mark.executable){
      state.since=null;return finish('NO_BID','Candle exit waits for a fresh executable Kalshi profit estimate.');
    }
    if(!state.armed&&(!c[p+'ActivationEnabled']||mark.pnl>=c[p+'Activation']-1e-9)){
      state.armed=true;state.armedAt=now;
    }
    if(!state.armed||c[p+'RequireFavorable']&&!state.favorable){
      state.since=null;return finish('WAIT_ACTIVATION',
        !state.armed?'Waiting for estimated whole-trade profit activation.':'Waiting for favorable candle color after buying.');
    }
    let confirmed=false;
    if(c[p+'Mode']==='closed'){
      const closed=tape.lastClosed;
      confirmed=!!closed&&closed.openKnown&&closed.complete&&closed.color===reversal&&
        closed.endAt>entered&&closed.endAt>state.monitorAt&&closed.endAt>=state.armedAt&&
        now>=closed.endAt&&now-closed.endAt<60000;
      state.since=null;
    }else if(bar.color===reversal&&Number.isFinite(bar.colorSince)){
      const since=Math.max(bar.colorSince,entered,state.armedAt,state.monitorAt);
      state.since=gap||state.since==null?Math.max(since,now):Math.max(state.since,since);
      confirmed=now-state.since>=requiredMs;
    }else state.since=null;
    if(!confirmed)return finish('WATCHING','Watching '+reversal+' reversal; recovery, a new candle or a data gap resets the wait.');
    if(mark.pnl<c[p+'MinProfit']-1e-9)return finish('PROFIT_WAIT',
      'Reversal confirmed, but conservative estimated net trade profit is below the minimum. Other exits remain available.');
    return finish('SELL',p.toUpperCase()+' candle reversal confirmed; estimated whole-trade net profit $'+
      mark.pnl.toFixed(2)+' meets $'+c[p+'MinProfit'].toFixed(2)+'. Not a guaranteed fill or profit.',
      {confirmed:true});
  }
  return {DEFAULTS,validate,evaluate};
});
