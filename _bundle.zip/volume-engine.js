(function(root,factory){
  const api=factory();
  if(typeof module==='object'&&module.exports)module.exports=api;
  else root.ContractVolume=api;
})(typeof globalThis!=='undefined'?globalThis:this,function(){
  'use strict';
  const DEFAULTS={};
  for(const p of ['up','down'])Object.assign(DEFAULTS,{
    [p+'VolumeEnabled']:false,[p+'VolumeLookback']:30,
    [p+'VolumeMinimum']:100,[p+'VolumePercent']:60,
  });
  const EXIT_DEFAULTS=Object.fromEntries(Object.entries(DEFAULTS).map(([k,v])=>[k.replace('Volume','SellVolume'),v]));
  const MAX_AGE=6000;
  function validateFields(input,defaults){
    const out={};
    for(const [k,d]of Object.entries(defaults)){
      const v=Object.hasOwn(input,k)?input[k]:d;
      if(typeof d==='boolean'){
        if(typeof v!=='boolean')throw Error(k+': check or uncheck this rule.');
        out[k]=v;continue;
      }
      const [lo,hi]=k.endsWith('Lookback')?[5,300]:k.endsWith('Percent')?[50,100]:[1,10000000];
      const n=Number(v);
      if(!['number','string'].includes(typeof v)||String(v).trim()===''||
        !Number.isFinite(n)||n<lo||n>hi||k.endsWith('Lookback')&&!Number.isInteger(n))
        throw Error(`${k}: enter ${lo} to ${hi}${k.endsWith('Lookback')?' whole seconds':''}.`);
      out[k]=n;
    }
    return out;
  }
  const validate=(input={})=>validateFields(input,DEFAULTS);
  const validateExit=(input={})=>validateFields(input,EXIT_DEFAULTS);
  const exitKey=side=>(side==='UP'?'up':'down')+'SellVolume';
  function evaluate(rules,data,market,side,now=Date.now(),env='live',sell=false){
    const p=sell?exitKey(side):(side==='UP'?'up':'down')+'Volume';
    const r=sell?{...EXIT_DEFAULTS,...rules}:{...DEFAULTS,...rules};
    const enabled=r[p+'Enabled']===true,lookback=r[p+'Lookback'],
      minimum=r[p+'Minimum'],required=r[p+'Percent'];
    const flowSide=sell?(side==='UP'?'DOWN':'UP'):side,label=sell?'exit':'entry';
    const result={side,enabled,allowed:!enabled,lookback,minimum,required,
      up:null,down:null,total:null,percent:null,ageMs:null,reason:''};
    if(!enabled)return {...result,reason:`${side} contract-volume confirmation OFF. Automatic entries use your other rules.`};
    const wait=reason=>({...result,reason:`${side} automatic ${label} waiting: ${reason}`});
    if(!market||!Number.isFinite(market.openTime)||!Number.isFinite(market.closeTime)||
      now<market.openTime||now>=market.closeTime)return wait('current open market required.');
    if(!data||data.ticker!==market.ticker||data.env!==env)return wait('current-market UP/DOWN trade data required.');
    if(data.error)return wait(sell?'contract trade feed unavailable.':data.error);
    if(!data.complete||!Array.isArray(data.trades))return wait('complete trade-history window required.');
    if(!Number.isFinite(data.asOf)||now<data.asOf||now-data.asOf>MAX_AGE)return wait('contract-volume snapshot is stale or unavailable.');
    result.ageMs=now-data.asOf;
    const start=data.asOf-lookback*1000;
    if(start<market.openTime)return wait(`collecting the full ${lookback}s window after market open.`);
    if(!Number.isFinite(data.from)||data.from>start)return wait(`complete ${lookback}s lookback is still loading.`);
    let up=0,down=0;
    for(const t of data.trades){
      if(!Number.isFinite(t.ts)||!Number.isFinite(t.count)||t.count<=0||
        !['UP','DOWN'].includes(t.side))return wait(`invalid trade data; no automatic ${label}.`);
      if(t.ts<start||t.ts>data.asOf)continue;
      if(t.side==='UP')up+=t.count;else down+=t.count;
    }
    const total=up+down;
    if(!Number.isFinite(total))return wait('invalid contract-volume total.');
    const percent=total>0?(flowSide==='UP'?up:down)/total*100:null;
    const allowed=total+1e-8>=minimum&&percent!==null&&percent+1e-8>=required;
    const counts=`UP ${up.toFixed(2)} / DOWN ${down.toFixed(2)} contracts in ${lookback}s`;
    return {...result,up,down,total,percent,allowed,
      reason:`${side} automatic ${label} ${allowed?'PASS':'WAIT'}: ${counts}; `+
        `${total.toFixed(2)} total ${total+1e-8>=minimum?'≥':'<'} ${minimum}; `+
        `${flowSide} share ${percent===null?'unavailable':percent.toFixed(1)+'%'} `+
        `${percent!==null&&percent+1e-8>=required?'≥':'<'} ${required}%. `+
        `Snapshot ${(result.ageMs/1000).toFixed(1)}s old. Not a win probability.`};
  }
  function evaluateExit(rules,data,market,quote,side,now=Date.now(),env='live',running=false,owns=false){
    const key=exitKey(side),opposite=side==='UP'?'DOWN':'UP';
    if(rules[key+'Enabled']!==true)return {action:'OFF',enabled:false,reason:`${side} contract-volume sell OFF.`};
    const wait=reason=>({action:'WAIT',enabled:true,reason});
    if(!owns)return wait(`Waiting for a strategy-owned ${side} position.`);
    if(!running)return wait('Start the bot to monitor this optional exit.');
    const result=evaluate(rules,data,market,side,now,env,true);
    if(!result.allowed)return {...result,action:'WAIT'};
    const bid=side==='UP'?quote?.upBid:quote?.downBid;
    if(quote?.ticker!==market?.ticker||!['open','active'].includes(quote?.status)||
      !Number.isFinite(quote?.ts)||quote.ts>now||now-quote.ts>10000||!Number.isFinite(bid)||!(bid>0&&bid<100))
      return {...result,action:'WAIT',reason:`${side} volume sell waiting for a fresh executable bid.`};
    return {...result,action:'SELL',reason:`${side} contract-volume sell: ${opposite} flow ${result.percent.toFixed(1)}% · ${result.total.toFixed(2)} total contracts in ${result.lookback}s.`};
  }
  return {DEFAULTS,EXIT_DEFAULTS,MAX_AGE,validate,validateExit,evaluate,evaluateExit,exitKey};
});
