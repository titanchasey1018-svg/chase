(function(root,factory){
  const api=factory(typeof module==='object'&&module.exports?require('./now-entry-engine'):root.NowEntry);
  if(typeof module==='object'&&module.exports)module.exports=api;else root.NowEntryEditor=api;
})(globalThis,function(E){
  'use strict';
  function scope(saved,raw,side){
    if(!['up','down'].includes(side))throw Error('Choose UP or DOWN.');
    const c=E.validate(saved);
    c.enabled=raw.enabled;
    for(const k of E.FIELDS)if(k.startsWith(side))c[k]=raw[k];
    return E.validateForApply(c);
  }
  function changed(saved,raw,prefix=''){
    const c=E.validate(saved);
    return E.FIELDS.filter(k=>!prefix||k.startsWith(prefix)).some(k=>{
      const v=typeof E.DEFAULTS[k]==='boolean'?raw[k]:
        (k.endsWith('KalshiNowLevel')||k.endsWith('SpreadLevel'))&&(raw[k]==null||raw[k]==='')?null:E.number(raw[k]);
      return v!==c[k];
    });
  }
  function retainOther(committed,raw,side){
    const c={...E.validate(committed)},other=side==='up'?'down':'up';
    for(const k of E.FIELDS)if(k.startsWith(other))c[k]=raw[k];
    return c; // Intentionally raw: preserve incomplete "-" drafts without coercion.
  }
  function forBackend(config,features){
    const c=E.validate(config);
    if(features?.nowEntryDirection!==true){
      if(c.upDirectionEnabled||c.downDirectionEnabled)
        throw Error('Movement confirmation needs backend activation. Existing threshold edits remain available.');
      for(const p of ['up','down'])for(const suffix of ['Enabled','Move','Seconds'])
        delete c[p+'Direction'+suffix];
    }
    if(features?.percentageExitDistance!==true){
      if(['up','down'].some(p=>['Trail','Stair'].some(k=>c[p+k+'PercentEnabled'])))
        throw Error('Percentage exits need backend activation. Existing dollar settings remain available.');
      for(const p of ['up','down'])for(const kind of ['Trail','Stair'])for(const suffix of ['PercentEnabled','Percent'])
        delete c[p+kind+suffix];
    }
    return (typeof module==='object'&&module.exports?require('./low-high-spread'):globalThis.LowHighSpread).forBackend(c,features);
  }
  return {scope,changed,retainOther,forBackend};
});
