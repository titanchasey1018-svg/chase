(function(root,factory){
  const api=factory();
  if(typeof module==='object'&&module.exports)module.exports=api;
  else root.BuySound=api;
})(typeof globalThis!=='undefined'?globalThis:this,function(){
  'use strict';
  const STORAGE_KEY='spread-guard.buy-sound.v1';
  const FILL=/^(UP|DOWN) fill recorded\. Keeping exit monitoring active while exchange positions synchronize\.$/;
  // These good-kind records are emitted by buyWithRetry only after ledgerBuy
  // has recorded owned inventory. Neither an order attempt nor "Filled 0" is
  // evidence. Using the log also catches a buy sold again between UI polls.
  function tracker(){
    let scope=null,baseline=null,lastClock=null;
    const seen=new Set();
    return {
      reset(){scope=null;baseline=null;lastClock=null;seen.clear();},
      observe(state,nextScope){
        const clock=state?.serverTime,rows=Array.isArray(state?.log)?state.log:[];
        if(!Number.isFinite(clock))return [];
        const candidates=rows.filter(e=>e?.kind==='good'&&Number.isFinite(e.t)&&FILL.test(e.msg));
        const key=e=>`${e.t}:${e.msg}`;
        if(scope!==nextScope||baseline===null){
          scope=nextScope;baseline=clock;lastClock=clock;seen.clear();
          for(const e of candidates)seen.add(key(e));
          return [];
        }
        if(clock<lastClock)return [];
        const floor=Math.max(baseline,lastClock);lastClock=clock;
        const events=[];
        for(const e of candidates){
          const id=key(e);if(seen.has(id))continue;
          seen.add(id);
          if(e.t>=floor&&e.t<=clock&&clock-e.t<=10000)
            events.push({side:e.msg.startsWith('UP')?'UP':'DOWN',at:e.t});
        }
        // Retain enough deduplication history for the bounded 80-entry UI log.
        while(seen.size>512)seen.delete(seen.values().next().value);
        return events;
      }
    };
  }
  function create(options={}){
    let storage=options.storage;
    if(storage===undefined)try{storage=globalThis.localStorage;}catch{}
    const Audio=options.AudioContext||globalThis.AudioContext||globalThis.webkitAudioContext;
    const report=options.onStatus||(()=>{}),events=tracker();
    let enabled=false,audio=null,lastStatus='',storageWorks=!!storage;
    try{enabled=storage?.getItem(STORAGE_KEY)==='on';}catch{storageWorks=false;}
    function status(text){
      lastStatus=text+(!storageWorks?' This browser cannot save the preference; it lasts for this page only.':'');
      report(lastStatus);
    }
    function describe(){
      status(!Audio?'Buy sound unavailable in this browser. Trading is unchanged.':
        !enabled?'Buy sound off. Test sound previews the chime without enabling alerts.':
        audio?.state==='running'?'Buy sound on for fresh confirmed UP/DOWN buys while this app is open.':
        'Buy sound on. Tap Test sound to enable audio for this visit.');
    }
    function chime(){
      if(audio?.state!=='running')return false;
      const at=audio.currentTime;
      for(const [frequency,delay]of [[660,0],[990,.14]]){
        const oscillator=audio.createOscillator(),gain=audio.createGain();
        oscillator.type='sine';oscillator.frequency.setValueAtTime(frequency,at+delay);
        gain.gain.setValueAtTime(0,at+delay);
        gain.gain.linearRampToValueAtTime(.09,at+delay+.015);
        gain.gain.exponentialRampToValueAtTime(.001,at+delay+.15);
        oscillator.connect(gain);gain.connect(audio.destination);
        oscillator.onended=()=>{oscillator.disconnect();gain.disconnect();};
        oscillator.start(at+delay);oscillator.stop(at+delay+.16);
      }
      return true;
    }
    async function test(){
      if(!Audio){describe();return false;}
      try{
        // Called only by explicit user input. Do not autoplay/unlock on a poll.
        if(!audio||audio.state==='closed')audio=new Audio();
        await audio.resume();
        if(!chime())throw new Error('Audio is suspended');
        status(`Test chime played. Buy sound ${enabled?'ON':'OFF'}. Keep volume on; background/locked-phone audio is not guaranteed.`);
        return true;
      }catch{
        status('Audio could not play. Tap Test sound again and check browser/phone sound settings. Trading is unchanged.');
        return false;
      }
    }
    async function setEnabled(value){
      enabled=value===true;
      try{storage?.setItem(STORAGE_KEY,enabled?'on':'off');}catch{storageWorks=false;}
      if(enabled)return test();
      describe();return false;
    }
    function observe(state,scope,visible=true){
      const fresh=events.observe(state,scope);
      if(!fresh.length||!enabled||!visible)return false;
      try{
        if(!chime()){describe();return false;}
        const sides=[...new Set(fresh.map(e=>e.side))].join(' / ');
        status(`Confirmed ${sides} buy received: chime played. Buy sound ON.`);
        return true;
      }catch{
        status('Buy confirmed, but audio could not play. Tap Test sound to re-enable audio. Trading is unchanged.');
        return false;
      }
    }
    describe();
    return {get enabled(){return enabled;},get supported(){return !!Audio;},
      get status(){return lastStatus;},setEnabled,test,observe,reset:()=>events.reset()};
  }
  return {STORAGE_KEY,tracker,create};
});
