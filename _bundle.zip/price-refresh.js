(function(root){
  'use strict';
  function matches(state, prices){
    return !!state?.market && prices?.marketTicker===state.market.ticker &&
      prices.strike===state.market.strike && Number.isFinite(prices.feeds?.timestamp);
  }
  function merge(state, prices){
    if(!matches(state,prices) || prices.feeds.timestamp < (state.feeds?.timestamp ?? 0))return state;
    return {...state,feeds:prices.feeds,
      kalshiIndex:prices.kalshiIndex??state.kalshiIndex};
  }
  const api={matches,merge};
  if(typeof module==='object'&&module.exports)module.exports=api;
  else root.PriceRefresh=api;
})(globalThis);
