(function(root){
  'use strict';
  root.NowExitUI={create(save){
    const $=id=>document.getElementById(id),E=root.NowExit,keys=Object.keys(E.DEFAULTS);
    let state,snapshot,signature='',pending=false,offline=false,conflict=false;
    const toggle=(k,text)=>`<label class="rule-toggle"><input id="nx-${k}" type="checkbox">${text}</label>`;
    const timed=k=>k.endsWith('Seconds')||k.endsWith('Cooldown');
    const field=(k,text)=>`<div class="field-row"><label for="nx-${k}">${text}</label><input id="nx-${k}" type="text" inputmode="${timed(k)?'decimal':'text'}" autocomplete="off" placeholder="${timed(k)?'0':'Enter signed value'}"></div>`;
    $('nowExitFields').innerHTML=toggle('enabled','Use separate LOW/HIGH sell rules')+
      '<p id="nowExitSpreadCompatibility" class="notice small" hidden>Exchange spread is NOT ACTIVE until an approved backend restart. Only the new spread controls are locked; existing sell settings remain available.</p>'+['up','down'].map(p=>
      `<fieldset><legend>${p.toUpperCase()} LOW/HIGH selling</legend>`+
      toggle(p+'Enabled','Use new sell rules for '+p.toUpperCase())+
      ['Low','High'].map(kind=>{
        const k=p+kind;
        return `<section class="now-entry-band">`+toggle(k+'Enabled','Allow '+p.toUpperCase()+' '+kind.toUpperCase()+' sell ('+(kind==='Low'?'at/below':'at/above')+')')+
          `<details class="now-entry-conditions"><summary>${kind.toUpperCase()} sell values and checkboxes</summary>`+
          `<p class="micro-note">All checked SELL conditions must pass together. LOW and HIGH are alternatives, not requirements to meet together.</p>`+
          ['Target','Kalshi','Now','Spread'].map(s=>toggle(k+'Use'+s,'SELL: require '+({Target:'All vs target',Kalshi:'signed Kalshi Now',Now:'Coinbase Now',Spread:'Exchange spread'}[s]))+
            field(k+s+'Level',kind.toUpperCase()+' '+({Target:'All vs target',Kalshi:'Kalshi Now',Now:'Coinbase Now',Spread:'Exchange spread'}[s])+' ($, signed)')).join('')+
          field(k+'Seconds',kind.toUpperCase()+' sell confirmation (seconds)')+
          field(k+'Cooldown',kind.toUpperCase()+' extra cooldown (seconds, 0 = off)')+
          `</details><p id="nx-${k}Live" class="micro-note" role="status"></p></section>`;
      }).join('')+`<p id="nx-${p}Status" class="notice small" role="status"></p></fieldset>`).join('');
    function draft(){return Object.fromEntries(keys.map(k=>[k,typeof E.DEFAULTS[k]==='boolean'?$('nx-'+k).checked:$('nx-'+k).value]));}
    function dirty(){const values=draft();return !!snapshot&&keys.some(k=>{
      const v=values[k];return typeof E.DEFAULTS[k]==='boolean'?v!==snapshot[k]:
        (k.endsWith('Level')&&v===''?null:E.number(v))!==snapshot[k];
    });}
    function fill(c){
      snapshot=E.validate(c);signature=JSON.stringify(snapshot);conflict=false;
      for(const k of keys)if(typeof E.DEFAULTS[k]==='boolean')$('nx-'+k).checked=snapshot[k];
      else $('nx-'+k).value=snapshot[k]??'';
    }
    function update(){
      const supported=state?.features?.lowHighSell===true,locked=!supported||pending||offline||state?.running;
      $('nowExitCompatibility').hidden=supported;
      const spreadSupported=state?.features?.lowHighExchangeSpread===true;
      $('nowExitSpreadCompatibility').hidden=spreadSupported;
      for(const k of keys)$('nx-'+k).disabled=locked;
      for(const p of ['up','down']){
        const sideLocked=locked||!$('nx-'+p+'Enabled').checked;
        for(const k of keys.filter(k=>k.startsWith(p)&&k!==p+'Enabled'))$('nx-'+k).disabled=sideLocked;
        for(const kind of ['Low','High']){
          const k=p+kind,bandLocked=sideLocked||!$('nx-'+k+'Enabled').checked;
          for(const s of ['Target','Kalshi','Now','Spread']){
            const sourceLocked=bandLocked||(s==='Spread'&&!spreadSupported);
            $('nx-'+k+'Use'+s).disabled=sourceLocked;
            $('nx-'+k+s+'Level').disabled=sourceLocked||!$('nx-'+k+'Use'+s).checked;
          }
          $('nx-'+k+'Seconds').disabled=bandLocked;
          $('nx-'+k+'Cooldown').disabled=bandLocked;
        }
        const own=!!state?.openTrade&&state.openTrade.ticker===state?.market?.ticker&&
          state.openTrade.side===(p==='up'?'yes':'no');
        const d=own&&state.guard?.lowHigh||E.evaluate(null,state?.settings?.nowExit,state?.feeds,p.toUpperCase(),
          'preview',Date.now(),false,state?.kalshiIndex);
        $('nx-'+p+'Status').textContent=offline?'Connection lost: server exit state unknown.':
          (own?'HELD · ':'PREVIEW ONLY · ')+d.reason;
        for(const g of d.groups){
          const selected=g.checks.filter(x=>x.enabled),fmt=v=>Number.isFinite(v)?v.toFixed(2):'[not set]';
          const mode=offline?'CONNECTION UNKNOWN':!d.enabled?'SELL GROUPS INACTIVE':!own?'PREVIEW ONLY':!state.running?'STOPPED · automatic sells OFF':'LIVE';
          $('nx-'+p+g.kind+'Live').textContent=mode+' · Saved '+g.kind.toUpperCase()+': '+(!g.enabled?'group OFF.':
            selected.map(x=>x.name+': '+fmt(x.value)+' '+x.op+' '+fmt(x.threshold)+
              (!x.ready?' · needs fresh source/value':x.passed?' · MET':' · NOT MET')).join(' AND ')||'no checked SELL sources.')+
            (g.enabled?' · '+(g.elapsedMs/1000).toFixed(1)+' / '+g.requiredMs/1000+'s'+(g.cooldownMs>0?
              ' · cooldown '+(g.cooldownElapsedMs/1000).toFixed(1)+' / '+g.cooldownMs/1000+'s':''):'');
        }
      }
      $('nowExitBadge').textContent=!supported?'PENDING ACTIVATION':state.settings.nowExit?.enabled?'SELL MODE ON':'SELL MODE OFF';
      $('nowExitSaveState').textContent=!supported?'Backend update pending. Existing sell rules are unchanged.':
        offline?'Offline: saved exit state unknown.':conflict?'Saved sell settings changed elsewhere. Your draft is kept; Reload before applying.':
        dirty()?'Unsaved SELL draft. Trading still uses the saved sell settings.':
        state.running?'Stop the bot before editing sell settings.':'Saved. Apply never starts, arms, buys or sells.';
      $('applyNowExit').disabled=locked||conflict;$('reloadNowExit').disabled=pending||!state;
    }
    $('applyNowExit').onclick=async()=>{
      try{await save(E.forBackend(E.validate(draft(),true),state.features),E.forBackend(snapshot,state.features));$('nowExitFeedback').textContent='LOW/HIGH sell settings saved. No bot started or armed and no order sent.';}
      catch(e){$('nowExitFeedback').textContent=e.message;}
    };
    $('reloadNowExit').onclick=()=>{fill(state.settings.nowExit);update();$('nowExitFeedback').textContent='Saved sell settings reloaded. Unsaved draft discarded; no order sent.';};
    $('nowExitFields').addEventListener('input',update);
    return {dirty,reload(){if(state){fill(state.settings.nowExit);update();}},
      render(s,flags={}){
        state=s;pending=!!flags.pending;offline=!!flags.disconnected;
        const c=E.validate(s.settings.nowExit),next=JSON.stringify(c);
        if(!snapshot)fill(c);else if(next!==signature){if(dirty()&&!pending)conflict=true;else fill(c);}
        update();
      }};
  }};
})(globalThis);
