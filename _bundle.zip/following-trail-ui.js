(function(root){'use strict';
  const FIELDS=[
    ['StageAt','Tighten at trade profit ($)','staged'],
    ['StagePullback','Tightened dollar giveback ($)','staged'],
    ['ActivationAtr','Activate after favorable entry ATR ×','volatility'],
    ['AtrMultiplier','Current ATR distance ×','volatility'],
    ['MinimumDistance','Minimum BTC Now distance ($)','volatility'],
    ['MaximumDistance','Maximum BTC Now distance ($)','volatility'],
    ['ConfirmationSeconds','Continuous breach confirmation (seconds)','volatility'],
  ];
  const explanation='Choices are independent for UP and DOWN. The per-side Enable selected following trail switch below is the master for the selected trail. Selecting a choice does not enable it. Current keeps your existing dollar settings. Staged uses those same initial settings and adds tightening. Volatility replaces only this following exit with a BTC Now trail, not a dollar-profit floor. Other exits stay active. Change choices only while stopped, disarmed and flat, then Apply Safety Controls.';
  function help(){
    const out={};
    for(const p of ['up','down']){
      out['follow_'+p+'Mode']=explanation+'\n\nVolatility uses the simple mean of 14 true ranges from 15 consecutive CLOSED one-minute Coinbase candles, not Wilder smoothing. A missing entry Now/ATR makes this trail unavailable for that trade, without changing buy rules or disabling other exits. Experimental, not proven profitable.';
      for(const [key,label]of FIELDS)out['follow_'+p+key]=label+'. '+
        (key==='StageAt'?'Must be at/above the initial dollar-profit activation.':
        key==='StagePullback'?'Must be positive and no greater than the initial dollar giveback.':
        key==='ActivationAtr'?'Example: 2 and entry ATR $15 activates after a favorable $30 BTC Now move.':
        key==='AtrMultiplier'?'Example: 1.5 and current ATR $20 requests a $30 BTC Now distance, subject to the minimum/maximum.':
        key==='ConfirmationSeconds'?'A breach must remain continuously observed for this duration. Recovery, stale data, Stop or a sampling gap resets a pending wait. A confirmed latch retries even after recovery.':
        'Distance is BTC price dollars, not position P&L. The minimum must not exceed the maximum; established barriers never loosen.')+
        '\n\n'+explanation+'\n\nNo fill, maximum-loss or break-even guarantee. Saved values are separate from the Paper comparison.';
    }
    return out;
  }
  function create(engine){
    const $=id=>document.getElementById(id),host=$('followingChoices');
    let expected=engine.validate();
    for(const p of ['up','down']){
      const d=document.createElement('details');d.className='safety-group';
      const summary=document.createElement('summary');summary.textContent=p.toUpperCase()+' trail choice';
      const field=document.createElement('fieldset'),legend=document.createElement('legend');
      legend.textContent=p.toUpperCase()+' optional following method';field.append(legend);
      const label=document.createElement('label');label.htmlFor='follow_'+p+'Mode';label.textContent='Following trail';
      const select=document.createElement('select');select.id=label.htmlFor;select.dataset.testid='select-'+p+'-following';
      for(const [value,text]of [['current','Current'],['staged','Staged'],['volatility','Volatility']]){
        const o=document.createElement('option');o.value=value;o.textContent=text;select.append(o);
      }
      const modeRow=document.createElement('div');modeRow.className='field-row';
      modeRow.style.clear='both';modeRow.append(label,select);field.append(modeRow);
      const note=document.createElement('p');note.id='follow_'+p+'Note';note.className='small muted';field.append(note);
      for(const [key,title,mode]of FIELDS){
        const row=document.createElement('div');row.className='field-row';row.dataset.followMode=p+':'+mode;
        const l=document.createElement('label'),input=document.createElement('input');
        l.htmlFor='follow_'+p+key;l.textContent=title;input.id=l.htmlFor;
        input.type='number';input.step='.01';input.min=key==='ConfirmationSeconds'?'0':'.01';
        input.max=key==='ConfirmationSeconds'?'300':'100000';input.inputMode='decimal';
        input.dataset.testid='input-following-'+p+key;row.append(l,input);field.append(row);
      }
      d.append(summary,field);host.append(d);
    }
    function read(){return engine.validate(Object.fromEntries(Object.keys(engine.DEFAULTS)
      .map(k=>[k,$('follow_'+k).value])));}
    function fill(c,applied=c){
      expected=engine.validate(applied);
      for(const [k,v]of Object.entries(engine.validate(c)))$('follow_'+k).value=v;
    }
    function render(state,disconnected,pending){
      if(!state)return;
      const supported=state.features?.followingTrails===true;
      $('followingCompatibility').hidden=supported;
      const occupied=state.running||state.armedLive||!!state.openTrade||!!state.position||
        state.awaitingSettle>0||state.paper?.pending>0;
      for(const k of Object.keys(engine.DEFAULTS))$('follow_'+k).disabled=!supported||disconnected||pending||occupied;
      for(const p of ['up','down']){
        const mode=$('follow_'+p+'Mode').value,enabled=state.settings.safety[p+'ProfitTrailEnabled'];
        for(const row of host.querySelectorAll('[data-follow-mode^="'+p+':"]'))row.hidden=row.dataset.followMode!==p+':'+mode;
        $('follow_'+p+'Note').textContent=(enabled?'Applied master ON. ':'Applied master OFF. ')+
          (mode==='current'?'Current: existing activation, dollar giveback and floor below.':
          mode==='staged'?'Staged: existing initial dollar settings below, then tighter giveback.':
          'Volatility: BTC Now distance; dollar activation, giveback and floor below are not used for this choice.');
      }
      const saved=engine.validate(state.settings.following);
      let dirty=false;try{dirty=JSON.stringify(read())!==JSON.stringify(saved);}catch{dirty=true;}
      const bars=state.safety?.followingCandles;
      $('followingStatus').textContent=!supported?'New choices locked pending approved backend52 restart. Existing settings are unchanged.':
        (occupied?'Choice editing locked: stop, disarm and finish positions/settlements. ':'')+
        (dirty?'UNSAVED TRAIL DRAFT. ':'Applied trail choices. ')+
        'UP '+saved.upMode+' · DOWN '+saved.downMode+'. '+
        (bars?(bars.ready?'Closed-candle ATR ready. ':bars.reason+' '):'')+
        'Existing master switches control whether they run.';
    }
    function payload(features){
      if(features?.followingTrails!==true){
        if(JSON.stringify(read())!==JSON.stringify(engine.validate()))
          throw Error('New trail choices need approved backend52 activation.');
        return {};
      }
      return {following:read(),expectedFollowing:{...expected}};
    }
    fill();
    return {read,fill,render,payload};
  }
  root.FollowingTrailUI={create,help};
})(globalThis);
