(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.SpreadGuard = factory();
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const Trailing = typeof module === 'object' && module.exports ? require('./trailing-engine') : globalThis.NowTrailing;
  const Cashout = typeof module === 'object' && module.exports ? require('./cashout-engine') : globalThis.TimedCashout;
  const Volume = typeof module === 'object' && module.exports ? require('./volume-engine') : globalThis.ContractVolume;
  const DEFAULT_RULES = Object.freeze({
    ...Trailing.DEFAULTS,
    ...Cashout.DEFAULTS,
    ...Volume.DEFAULTS,
    ...Volume.EXIT_DEFAULTS,
    upSpread: 24.50, upSeconds: 5, upTarget: 50, upNow: 30, upSellSeconds: 0,
    downSpread: -23.50, downSeconds: 5, downTarget: -50,
    downHold: -30, downSell: -20, downSellSeconds: 0,
    upUseSpread: true, upUseTarget: true, upUseNow: true,
    downUseSpread: true, downUseTarget: true, downUseNow: true,
    upBuyUseSpread: true, upBuyUseTarget: true, upBuyUseNow: true,
    downBuyUseSpread: true, downBuyUseTarget: true, downBuyUseNow: true,
    upRequireQualification: false, downRequireQualification: false,
    upNowOnlyEnabled: false, upNowOnlyThreshold: 30, upNowOnlyDirection: 'below',
    downNowOnlyEnabled: false, downNowOnlyThreshold: -20, downNowOnlyDirection: 'above',
  });
  const LIMITS = {
    upSpread: [-100000, 100000], upSeconds: [1, 120],
    upTarget: [-100000, 100000], upNow: [-100000, 100000],
    downSpread: [-100000, 100000], downSeconds: [1, 120],
    downTarget: [-100000, 100000], downHold: [-100000, 100000],
    downSell: [-100000, 100000],
    upSellSeconds: [0, 300], downSellSeconds: [0, 300],
    upNowOnlyThreshold: [-100000,100000], downNowOnlyThreshold: [-100000,100000],
  };
  // Additive migration: existing Use* flags remain regular SELL selections.
  // Before this split they also selected buys, so copy each legacy selection only
  // when its new BUY flag is absent. Never replace an explicit false.
  function migrateRules(input = {}) {
    const rules = {...DEFAULT_RULES,...input};
    for (const side of ['up','down']) for (const check of ['Spread','Target','Now']) {
      const buy = side+'BuyUse'+check, legacy = side+'Use'+check;
      if (!Object.hasOwn(input,buy)) rules[buy] = input[legacy] ?? DEFAULT_RULES[legacy];
    }
    return rules;
  }
  function validateRules(input) {
    const migrated = migrateRules(input);
    input = {...input};
    for (const key of Object.keys(DEFAULT_RULES).filter(k=>k.includes('BuyUse'))) input[key] = migrated[key];
    const rules = {...Trailing.validate(input),...Cashout.validate(input),...Volume.validate(input),...Volume.validateExit(input)};
    for (const [key, [lo, hi]] of Object.entries(LIMITS)) {
      // Older saved rule files/clients predate the optional sell-wait fields.
      const optional = key.endsWith('SellSeconds') || key.endsWith('NowOnlyThreshold');
      const value = optional && !Object.hasOwn(input, key) ? DEFAULT_RULES[key] : input[key];
      if (value === '' || value == null || typeof value === 'boolean' ||
          !Number.isFinite(Number(value)) || Number(value) < lo || Number(value) > hi) {
        throw new Error(`${key}: enter a number from ${lo} to ${hi}.`);
      }
      rules[key] = Number(value);
    }
    for (const key of Object.keys(DEFAULT_RULES).filter(k=>typeof DEFAULT_RULES[k] === 'boolean')) {
      const value = Object.hasOwn(input,key) ? input[key] : DEFAULT_RULES[key];
      if (typeof value !== 'boolean') throw new Error(`${key}: use a checked or unchecked rule.`);
      rules[key] = value;
    }
    for (const side of ['up','down']) {
      const key = side+'NowOnlyDirection', value = Object.hasOwn(input,key) ? input[key] : DEFAULT_RULES[key];
      if (!['below','above'].includes(value)) throw new Error(`${key}: choose below or above.`);
      rules[key] = value;
    }
    if (rules.downHold > rules.downSell) {
      throw new Error('DOWN hold threshold must be at or below its sell threshold.');
    }
    return rules;
  }
  const blank = (key = '') => ({ key, since: null, armed: false, last: null, sellSince: null });
  const uses = (rules, side, check, buying = false) => {
    const prefix = side === 'UP' ? 'up' : 'down', legacy = prefix+'Use'+check, buy = prefix+'BuyUse'+check;
    return (buying && Object.hasOwn(rules,buy) ? rules[buy] : rules[legacy]) !== false;
  };
  // Pure state machine. Optional qualification is separate from the spread exit check.
  // A missing/stale feed or sampling gap resets the latch; elapsed wall time is never
  // inferred by counting polling ticks. The backend owns this state, not the browser.
  function evaluate(previous, rules, m, side, key, now) {
    let state = previous && previous.key === key ? { ...previous } : blank(key);
    const requireQualification = uses(rules,side,'Spread') &&
      rules[(side === 'UP' ? 'up' : 'down')+'RequireQualification'] === true;
    const requiredMs = requireQualification ? (side === 'UP' ? rules.upSeconds : rules.downSeconds) * 1000 : 0;
    const sellRequiredMs = (side === 'UP' ? rules.upSellSeconds : rules.downSellSeconds) * 1000 || 0;
    const ready = m && m.ready === true &&
      [m.spread, m.targetDiff, m.nowDiff].every(Number.isFinite);
    if (!ready) {
      state = blank(key);
      return { state, action: 'PAUSED', reason: m?.reason || 'Waiting for fresh prices and the market target.',
        elapsedMs: 0, requiredMs, requireQualification, sellElapsedMs: 0, sellRequiredMs, checks: [] };
    }
    if (state.last != null && (now - state.last > 3500 || now < state.last)) state = blank(key);
    state.last = now;
    const up = side === 'UP';
    const prefix = up ? 'up' : 'down';
    const nowOnly = {
      enabled: rules[prefix+'NowOnlyEnabled'] === true, value:m.nowDiff,
      threshold:rules[prefix+'NowOnlyThreshold'] ?? DEFAULT_RULES[prefix+'NowOnlyThreshold'],
      direction:rules[prefix+'NowOnlyDirection'] || DEFAULT_RULES[prefix+'NowOnlyDirection'],
    };
    nowOnly.passed = nowOnly.direction === 'below' ? nowOnly.value < nowOnly.threshold : nowOnly.value > nowOnly.threshold;
    const favorable = up ? m.spread >= rules.upSpread : m.spread <= rules.downSpread;
    if (!requireQualification) state.armed = true;
    if (!state.armed) {
      if (favorable) {
        if (state.since == null) state.since = now;
        if (now - state.since >= requiredMs) state.armed = true;
      } else state.since = null;
    }
    const elapsedMs = state.armed ? requiredMs : state.since == null ? 0 : Math.max(0, now - state.since);
    const checks = [
      { name: 'Spread weakened', value: m.spread, op: up ? '<' : '>',
        threshold: up ? rules.upSpread : rules.downSpread,
        passed: up ? m.spread < rules.upSpread : m.spread > rules.downSpread },
      { name: 'All exchanges vs target', value: m.targetDiff, op: up ? '<' : '>',
        threshold: up ? rules.upTarget : rules.downTarget,
        passed: up ? m.targetDiff < rules.upTarget : m.targetDiff > rules.downTarget },
      { name: 'Coinbase vs target (now)', value: m.nowDiff, op: up ? '<' : '>',
        threshold: up ? rules.upNow : rules.downSell,
        passed: up ? m.nowDiff < rules.upNow : m.nowDiff > rules.downSell },
    ].map((c,i)=>({...c,enabled:uses(rules,side,['Spread','Target','Now'][i])}));
    const active = checks.filter(c=>c.enabled);
    const sellReady = active.length > 0 && state.armed && active.every(c => c.passed);
    if (!sellReady) state.sellSince = null;
    else if (state.sellSince == null) state.sellSince = now;
    const sellElapsedMs = state.sellSince == null ? 0 : Math.max(0, now - state.sellSince);
    if (nowOnly.enabled && nowOnly.passed) {
      return {state,action:'SELL',reason:`Now-only exit: Coinbase minus target is ${nowOnly.direction} ${nowOnly.threshold}. No qualification or sell wait required.`,
        elapsedMs,requiredMs,requireQualification,sellElapsedMs,sellRequiredMs,checks,nowOnly,exitKind:'now-only'};
    }
    let action = 'HOLD', reason;
    if (!active.length) {
      reason = 'All compound rules are unchecked. Compound exits are disabled.';
    } else if (!state.armed) {
      action = favorable ? 'QUALIFYING' : 'WAITING';
      reason = favorable ? `Qualifying ${side} spread for ${requiredMs / 1000}s.`
        : `${active.every(c=>c.passed) ? 'All checked sell conditions are met, but qualification is blocking the exit. ' : ''}Spread has not qualified for ${requiredMs / 1000} continuous seconds. Turn off "Require spread qualification before selling" to remove this prerequisite.`;
    } else if (sellReady) {
      action = sellElapsedMs >= sellRequiredMs ? 'SELL' : 'EXIT_WAIT';
      reason = action === 'SELL' ? 'All enabled exit checks agree and the sell wait is complete.'
        : `Waiting to sell: all enabled checks must stay true for ${sellRequiredMs / 1000}s.`;
    } else if (!up && uses(rules,side,'Now') && m.nowDiff <= rules.downHold) {
      reason = 'Coinbase is at or below the DOWN hold threshold.';
    } else if (!up && uses(rules,side,'Now') && m.nowDiff <= rules.downSell) {
      reason = 'Inside the DOWN hold/sell gap. Keep holding.';
    } else {
      reason = 'Holding: not all enabled exit checks agree.';
    }
    return { state, action, reason, elapsedMs, requiredMs, requireQualification, sellElapsedMs, sellRequiredMs, checks, nowOnly, exitKind:'compound' };
  }
  function entryChecks(rules, m, side) {
    const up = side === 'UP';
    return [
      { name:'Spread', value:m?.spread, op:up ? '>=' : '<=', threshold:up ? rules.upSpread : rules.downSpread },
      { name:'All vs target', value:m?.targetDiff, op:up ? '>=' : '<=', threshold:up ? rules.upTarget : rules.downTarget },
      { name:'Now vs target', value:m?.nowDiff, op:up ? '>=' : '<=', threshold:up ? rules.upNow : rules.downHold },
    ].map((c,i) => ({...c,enabled:uses(rules,side,['Spread','Target','Now'][i],true),
      passed:Number.isFinite(c.value) && (up ? c.value >= c.threshold : c.value <= c.threshold)}));
  }
  function evaluateEntry(previous, rules, m, side, key, now) {
    let state = previous?.key === key ? {...previous} : blank(key);
    if (state.last != null && (now - state.last > 3500 || now < state.last)) state = blank(key);
    state.last = now;
    const requiredMs = (side === 'UP' ? rules.upSeconds : rules.downSeconds) * 1000;
    const checks = entryChecks(rules,m,side);
    const active = checks.filter(c=>c.enabled);
    const ready = m?.ready === true && active.every(c => Number.isFinite(c.value));
    if (!active.length || !ready || !active.every(c => c.passed)) state.since = null;
    else if (state.since == null) state.since = now;
    const elapsedMs = state.since == null ? 0 : Math.max(0,now-state.since);
    const action = !active.length ? 'DISABLED' : !ready ? 'PAUSED' : state.since == null ? 'WAITING' :
      elapsedMs >= requiredMs ? 'READY' : 'QUALIFYING';
    return {state,action,checks,elapsedMs,requiredMs};
  }
  return { DEFAULT_RULES, migrateRules, validateRules, blank, evaluate, entryChecks, evaluateEntry };
});
