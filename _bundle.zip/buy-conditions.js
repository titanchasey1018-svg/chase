(function(root,factory){
  const api=factory();
  if(typeof module==='object'&&module.exports)module.exports=api;else root.BuyConditions=api;
})(globalThis,function(){
  'use strict';
  const SOURCES=Object.freeze({Target:'All vs target',Now:'Coinbase Now vs target',
    Kalshi:'Kalshi Now vs target',Spread:'Exchange spread',TimeLeft:'Time left in market'});
  const empty=()=>({enabled:false,match:'all',rules:[]});
  function validate(input){
    if(input===undefined)input={};
    if(!input||typeof input!=='object'||Array.isArray(input))throw Error('Buy conditions must be an object.');
    for(const k of Object.keys(input))if(!['up','down'].includes(k))throw Error('Unknown buy condition side: '+k);
    const out={};
    for(const p of ['up','down']){
      const c=input[p]===undefined?empty():input[p];
      if(!c||typeof c!=='object'||Array.isArray(c)||
        Object.keys(c).some(k=>!['enabled','match','rules'].includes(k))||
        typeof c.enabled!=='boolean'||!['all','any'].includes(c.match)||!Array.isArray(c.rules)||c.rules.length>10)
        throw Error(p.toUpperCase()+': choose ON/OFF, ALL/ANY and up to 10 conditions.');
      const rules=c.rules.map(r=>{
        if(!r||typeof r!=='object'||Array.isArray(r)||Object.keys(r).some(k=>!['source','op','value'].includes(k))||
          !Object.hasOwn(SOURCES,r.source)||!['lte','gte'].includes(r.op)||
          !['number','string'].includes(typeof r.value))
          throw Error('Choose a buy source and comparison.');
        const text=String(r.value).trim().replace(/^[\u2212\u2013\u2014\uFE63\uFF0D]/,'-');
        if(!/^[+-]?(?:\d+(?:\.\d*)?|\.\d+)$/.test(text)||!Number.isFinite(Number(text))||Math.abs(Number(text))>100000)
          throw Error(r.source==='TimeLeft'?'Time left in market: enter minutes from 0 to 15 (0.5 = 30 seconds).':
            'Each condition needs a signed number from -100000 to 100000.');
        if(r.source==='TimeLeft'&&(Number(text)<0||Number(text)>15))
          throw Error('Time left in market: enter minutes from 0 to 15 (0.5 = 30 seconds).');
        return {source:r.source,op:r.op,value:Number(text)};
      });
      if(c.enabled&&!rules.length)throw Error(p.toUpperCase()+': add at least one condition or turn the alternative OFF.');
      out[p]={enabled:c.enabled,match:c.match,rules};
    }
    return out;
  }
  function assertUsage(config,entry){
    const c=validate(config);
    for(const p of ['up','down'])if(c[p].enabled&&
      (!entry?.enabled||!entry[p+'Enabled']||!['Low','High'].some(k=>entry[p+k+'Enabled']&&entry[p+k+'UseSpread'])))
      throw Error(p.toUpperCase()+': first enable low/high buying and a checked Exchange spread condition for this side.');
    return c;
  }
  function evaluate(config,metrics,index,side,now=Date.now(),market=null){
    const c=validate(config)[side.toLowerCase()];
    if(!c.enabled)return {enabled:false,ready:true,passed:false,checks:[],description:'Alternative OFF'};
    const kalshiReady=index?.fresh===true&&index?.status==='live'&&
      ['authenticated_index','public_chart'].includes(index.sourceKind)&&
      Number.isFinite(index.price)&&index.price>0&&Number.isFinite(index.nowDiff)&&Number.isFinite(index.sourceTime)&&
      now-index.sourceTime<=5000&&index.sourceTime-now<=1000;
    const timeReady=Number.isFinite(now)&&typeof market?.ticker==='string'&&market.ticker.length>0&&
      Number.isFinite(market.openTime)&&Number.isFinite(market.closeTime)&&market.openTime>0&&
      market.closeTime>market.openTime&&now>=market.openTime&&now<market.closeTime;
    const values={Target:metrics?.targetDiff,Now:metrics?.nowDiff,Spread:metrics?.spread,
      TimeLeft:timeReady?(market.closeTime-now)/60000:null,
      Kalshi:Number.isFinite(index?.nowDiff)?Math.sign(index.nowDiff)*Math.round((Math.abs(index.nowDiff)+Number.EPSILON)*100)/100:null};
    const checks=c.rules.map(r=>{
      const value=values[r.source],ready=metrics?.ready===true&&Number.isFinite(value)&&(r.source!=='Kalshi'||kalshiReady);
      return {...r,name:SOURCES[r.source],actual:value,ready,passed:ready&&(r.op==='lte'?value<=r.value:value>=r.value)};
    });
    // Missing data never makes an alternative pass, even in ANY mode.
    const ready=checks.length>0&&checks.every(r=>r.ready);
    return {enabled:true,match:c.match,ready,checks,
      passed:ready&&(c.match==='all'?checks.every(r=>r.passed):checks.some(r=>r.passed)),
      description:checks.map(describe).join(c.match==='all'?' AND ':' OR ')};
  }
  function needsKalshi(config){
    return Object.values(validate(config)).some(c=>c.enabled&&c.rules.some(r=>r.source==='Kalshi'));
  }
  function describe(r){return SOURCES[r.source]+' '+(r.op==='lte'?'≤':'≥')+' '+r.value+
    (r.source==='TimeLeft'?' min':'');}
  return {SOURCES,validate,assertUsage,evaluate,needsKalshi,describe};
});
