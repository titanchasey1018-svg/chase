(function(root){
  'use strict';
  function create(engine,apply){
    const $=id=>document.getElementById(id),host=$('candleExitFields');
    const labels={Enabled:'Enable candle-reversal exit',Mode:'Reversal confirmation',
      RequireFavorable:'Require favorable color after buying',ActivationEnabled:'Require profit activation',
      Activation:'Activate at estimated trade profit ($)',Seconds:'Continuous reversal (seconds)',
      MinProfit:'Minimum estimated net trade profit ($)'};
    let expected=engine.validate(),latest=null,ready=false;
    for(const p of ['up','down']){
      const details=document.createElement('details');details.className='safety-group';
      const summary=document.createElement('summary');summary.id='candle_'+p+'Summary';
      const field=document.createElement('fieldset');field.id='candle_'+p+'Fields';
      const legend=document.createElement('legend');legend.textContent=p.toUpperCase()+' candle reversal';
      field.append(legend);
      const note=document.createElement('p');note.className='small muted';
      note.textContent=p==='up'?'UP: observe green, then confirm red.':'DOWN: observe red, then confirm green.';
      field.append(note);
      for(const [suffix,label]of Object.entries(labels)){
        const key=p+suffix,row=document.createElement('div');row.className='field-row';
        const l=document.createElement('label');l.htmlFor='candle_'+key;l.textContent=label;
        let input;
        if(suffix==='Mode'){
          input=document.createElement('select');
          for(const [v,t]of [['timed','Timed forming candle'],['closed','Wait for candle close']]){
            const o=document.createElement('option');o.value=v;o.textContent=t;input.append(o);
          }
        }else{
          input=document.createElement('input');input.type=typeof engine.DEFAULTS[key]==='boolean'?'checkbox':'number';
          if(input.type==='number'){input.step='.01';input.min=suffix==='Activation'?'.01':'0';
            input.max=suffix==='Seconds'?'59':'100000';input.inputMode='decimal';}
        }
        input.id=l.htmlFor;row.append(l,input);field.append(row);
      }
      const help=document.createElement('p');help.className='micro-note';
      help.textContent='1-minute observed Coinbase BTC candles, not Kalshi Now. The timer resets on recovery, neutral color, a new candle, stale data or Stop. Closed mode ignores seconds and requires a fully observed closed candle. Profit values cover the whole trade, including realized partial sales; Paper uses its existing zero-fee model. Live/Demo estimates include fees and configured sell slippage. Every retry rechecks the signal and minimum profit. This is not loss protection or a profit guarantee.';
      field.append(help);details.append(summary,field);host.append(details);
    }
    function read(){
      return engine.validate(Object.fromEntries(Object.keys(engine.DEFAULTS).map(k=>{
        const el=$('candle_'+k);return [k,el.type==='checkbox'?el.checked:el.value];
      })));
    }
    function dirty(){try{return JSON.stringify(read())!==JSON.stringify(expected);}catch{return true;}}
    function fill(c,applied=c){
      expected=engine.validate(applied);
      for(const [k,v]of Object.entries(engine.validate(c))){
        const el=$('candle_'+k);if(el.type==='checkbox')el.checked=v;else el.value=v;
      }
      ready=true;
    }
    function feedback(text,error=false){$('candleExitFeedback').textContent=text;
      $('candleExitFeedback').className='feedback '+(error?'error':'success');}
    function chart(state,disconnected){
      const tape=state.candleChart,plot=$('candleChartPlot');
      const focusedStart=plot.contains(document.activeElement)?document.activeElement.getAttribute('data-candle-start'):null;
      $('candleChartStatus').textContent=disconnected?'Disconnected: last observed candles only; no fresh signal.':
        state.features?.candleReversal!==true?'Candle graph awaits approved backend54 activation. Existing chart and settings are unchanged.':
        tape?.reason||'Waiting for observed Coinbase trades.';
      $('candleChartBadge').textContent=disconnected?'STALE':tape?.ready?'LIVE':tape?.fresh?'PARTIAL':'WAITING';
      const bars=(tape?.bars||[]).slice(-Number($('candleChartRange').value));
      const line=root.LineTrailUI?.overlay(state);
      $('candleLineTrailStatus').textContent=line&&Number.isFinite(line.btcLevel)?
        line.side+' trailing-line sell · BTC $'+line.btcLevel.toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2})+
          ' · same threshold as Now chart. '+(disconnected?'Disconnected: last observed line only.':
          !state.running?'Stopped: automatic sells inactive.':state.guard?.lineTrail?.reason||'Monitoring.'):
        state.features?.lineTrail!==true?'Optional trailing line awaits approved backend55 activation.':
        'Optional trailing line: no enabled owned-position threshold. Configure under Exit settings.';
      if(!bars.length){plot.replaceChildren();plot.textContent='Observed 1-minute candles will appear here. No historical bars are invented.';return;}
      const ns='http://www.w3.org/2000/svg',svg=document.createElementNS(ns,'svg');
      const width=Math.max(300,plot.clientWidth),inner=width-85;
      svg.setAttribute('viewBox','0 0 '+width+' 220');svg.setAttribute('role','group');
      svg.setAttribute('aria-label','Observed Coinbase BTC USD 1-minute candlestick graph');
      const make=(tag,attrs,text)=>{
        const el=document.createElementNS(ns,tag);for(const [k,v]of Object.entries(attrs))el.setAttribute(k,String(v));
        if(text!=null)el.textContent=text;return el;
      };
      const points=line&&state.nowChart?.ticker===state.market?.ticker?
        (state.nowChart.points||[]).filter(p=>p.position===state.openTrade.startedAt&&Number.isFinite(p.line)&&
          p.t>=bars[0].startAt&&p.t<=state.serverTime):[];
      const levels=[...bars.flatMap(b=>[b.low,b.high]),...points.map(p=>p.line+state.market.strike),
        ...(Number.isFinite(line?.btcLevel)?[line.btcLevel]:[])];
      const lo=Math.min(...levels),hi=Math.max(...levels),pad=Math.max(2,(hi-lo)*.12);
      const bottom=lo-pad,top=hi+pad,y=v=>180-(v-bottom)/(top-bottom)*160;
      const slot=inner/Math.max(15,bars.length),money=v=>v.toLocaleString('en-US',{maximumFractionDigits:2});
      for(let i=0;i<4;i++){
        const value=bottom+(top-bottom)*i/3,yy=y(value);
        svg.append(make('line',{x1:6,x2:inner+6,y1:yy,y2:yy,stroke:'var(--border,#33413b)'}));
        svg.append(make('text',{x:inner+12,y:yy+4,fill:'var(--muted,#a4b4ac)','font-size':12},money(value)));
      }
      bars.forEach((b,i)=>{
        const x=6+i*slot+slot/2,col=b.color==='green'?'#78c5a2':b.color==='red'?'#dd9a8d':'#a9b5b0';
        const g=make('g',{tabindex:0,role:'button','data-candle-start':b.startAt,'aria-label':new Date(b.startAt).toLocaleTimeString()+
          ' open '+money(b.open)+' high '+money(b.high)+' low '+money(b.low)+' close '+money(b.close)});
        g.append(make('line',{x1:x,x2:x,y1:y(b.high),y2:y(b.low),stroke:col,'stroke-width':1.5}));
        g.append(make('rect',{x:x-Math.max(.75,slot*.28),y:Math.min(y(b.open),y(b.close)),
          width:Math.max(1.5,slot*.56),height:Math.max(2,Math.abs(y(b.open)-y(b.close))),
          fill:b.complete?col:'none',stroke:col,'stroke-dasharray':b.complete?'none':'3 2'}));
        const inspect=()=>{$('candleChartReadout').textContent=new Date(b.startAt).toLocaleTimeString()+
          ' · Open $'+money(b.open)+' · High $'+money(b.high)+' · Low $'+money(b.low)+
          ' · Close $'+money(b.close)+(b.complete?' · continuously observed':' · partial/gapped observations');};
        g.addEventListener('click',inspect);g.addEventListener('focus',inspect);
        g.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();inspect();}});
        svg.append(g);
      });
      if(Number.isFinite(line?.btcLevel)){
        const x=t=>Math.max(6,Math.min(inner+6,6+((t-bars[0].startAt)/60000+.5)*slot));
        let path='',previous=null;
        for(const p of points){
          const xx=x(p.t),yy=y(p.line+state.market.strike),continuous=previous&&p.t-previous.t<=3500;
          path+=continuous?'H'+xx+' V'+yy+' ':'M'+xx+','+yy+' ';previous=p;
        }
        svg.append(make('path',{d:path,fill:'none',class:'chart-line-trail','stroke-width':2}));
        const end=Math.min(inner+6,x(state.serverTime));
        const last=points.at(-1),start=last?Math.min(end,x(last.t)):Math.max(6,Math.min(end,x(line.startedAt)));
        svg.append(make('line',{x1:start,x2:end,y1:y(line.btcLevel),y2:y(line.btcLevel),
          class:'chart-line-trail','stroke-width':2,'stroke-dasharray':'6 4',
          'data-testid':'candle-trailing-line','data-btc-level':line.btcLevel,'data-now-level':line.level}));
        svg.append(make('circle',{cx:end,cy:y(line.btcLevel),r:3,class:'chart-line-trail'}));
        // Fixed top-left legend cannot collide with either candle or axis labels.
        svg.append(make('rect',{x:7,y:1,width:Math.min(inner,210),height:20,fill:'var(--panel,#18201c)'}));
        svg.append(make('text',{x:12,y:15,class:'chart-line-trail-label','font-size':12},
          line.side+' LINE $'+money(line.btcLevel)));
      }
      svg.append(make('text',{x:10,y:210,fill:'var(--muted,#a4b4ac)','font-size':12},
        new Date(bars[0].startAt).toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'})));
      svg.append(make('text',{x:inner-65,y:210,fill:'var(--muted,#a4b4ac)','font-size':12},
        new Date(bars.at(-1).startAt).toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'})));
      plot.replaceChildren(svg);
      if(focusedStart)plot.querySelector('[data-candle-start="'+focusedStart+'"]')?.focus({preventScroll:true});
    }
    function render(state,disconnected,pending){
      if(!state)return;latest={state,disconnected,pending};
      const saved=engine.validate(state.settings.candleReversal);
      if(!ready||!dirty())fill(saved);
      const supported=state.features?.candleReversal===true;
      const unsafe=disconnected||pending||state.running||state.armedLive||!!state.openTrade||
        !!state.position||state.awaitingSettle>0||state.paper?.pending>0||
        ['BUYING','SELLING','MANUAL'].includes(state.phase);
      const changed=JSON.stringify(expected)!==JSON.stringify(saved);
      $('candleExitCompatibility').hidden=supported;
      $('applyCandleExit').disabled=!supported||unsafe||changed;
      $('reloadCandleExit').disabled=disconnected||pending;
      for(const p of ['up','down']){
        $('candle_'+p+'Fields').disabled=!supported||unsafe;
        const enabled=saved[p+'Enabled'],draft=$('candle_'+p+'Enabled').checked!==enabled||dirty();
        $('candle_'+p+'Summary').textContent=p.toUpperCase()+' candle exit · '+(enabled?'ON':'OFF')+(draft?' · draft':'');
        $('candle_'+p+'Seconds').disabled=!supported||unsafe||$('candle_'+p+'Mode').value==='closed';
      }
      const decision=state.guard?.candleReversal;
      $('candleExitStatus').textContent='Applied: UP '+(saved.upEnabled?'ON':'OFF')+' · DOWN '+
        (saved.downEnabled?'ON':'OFF')+'. '+(changed?'Settings changed elsewhere; reload before applying. ':
        dirty()?'Unsaved draft. ':'')+(!state.running?'Stopped: automatic candle exits inactive. ':decision?decision.reason:'No owned position. ')+
        (unsafe?' Editing requires stopped, disarmed and flat.':'');
      chart(state,disconnected);
    }
    host.addEventListener('input',()=>{if(latest)render(latest.state,latest.disconnected,latest.pending);});
    $('candleChartRange').addEventListener('change',()=>{if(latest)chart(latest.state,latest.disconnected);});
    root.addEventListener('resize',()=>{if(latest)chart(latest.state,latest.disconnected);});
    $('applyCandleExit').onclick=async()=>{
      try{
        if(!latest||latest.state.features?.candleReversal!==true)throw Error('Approved backend54 activation required.');
        await apply({candleReversal:read(),expectedCandleReversal:expected});
        fill(latest.state.settings.candleReversal);render(latest.state,latest.disconnected,latest.pending);
        feedback('Candle exit settings applied. No bot started or armed.');
      }catch(e){feedback(e.message,true);}
    };
    $('reloadCandleExit').onclick=()=>{
      if(latest){fill(latest.state.settings.candleReversal);render(latest.state,latest.disconnected,latest.pending);
        feedback('Reloaded applied candle settings. No trading changed.');}
    };
    fill();ready=false;
    return {read,fill,render,dirty};
  }
  root.CandleReversalUI={create};
})(globalThis);
