(function(root){
  'use strict';
  const signed=n=>(n>=0?'+':'−')+'$'+Math.abs(n).toFixed(2);
  function calculate(entry,percent,side){
    if(!Number.isFinite(entry)||entry===0||!Number.isFinite(percent)||percent<0.01||percent>100)return null;
    const step=Math.abs(entry)*percent/100,sign=side==='UP'?1:-1;
    return {entry,percent,step,first:entry+sign*step,next:entry+sign*2*step};
  }
  function preview(side,own,enabled,percent){
    if(!enabled)return 'Automatic buy-value calculation OFF. The saved dollar step is used when staircase barriers are enabled.';
    const entry=own?.side===(side==='UP'?'yes':'no')?own.entryNow:null;
    if(!Number.isFinite(percent)||percent<0.01||percent>100)
      return 'Enter a percentage from 0.01 to 100. No calculation or setting has been applied.';
    const c=calculate(entry,percent,side);
    if(!c)return `After the next ${side} fill, automatically use its chart BUY value × ${percent}% for each barrier step. No buy value to type. Missing/zero BUY pauses this percentage exit.`;
    return `Draft preview only: chart BUY ${signed(c.entry)} × ${c.percent}% = $${c.step.toFixed(2)} per step. Reach ${signed(c.first)} to lock ${signed(c.entry)}; then ${signed(c.next)} to lock ${signed(c.first)}. Existing LOW/HIGH trades keep their captured plan.`;
  }
  function live(own,stair){
    if(!own||!stair?.enabled||!stair.percentMode)return '';
    const c=calculate(own.entryNow,stair.percent,own.side==='yes'?'UP':'DOWN');
    if(!c||!Number.isFinite(stair.step)||stair.step<=0)
      return 'Automatic barrier step paused: recorded chart BUY must be finite and nonzero. No buy value is guessed.';
    return `Chart BUY ${signed(c.entry)} × ${c.percent}% = $${stair.step.toFixed(2)} per barrier step. `+
      (Number.isFinite(stair.level)?`Locked barrier ${signed(stair.level)}.`:
        `First lock at ${signed(c.first)}; no barrier before that full step.`)+
      ' Recorded at first-fill confirmation, not the contract price.';
  }
  const api={calculate,preview,live};
  root.BarrierBuyValue=api;
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
})(globalThis);
