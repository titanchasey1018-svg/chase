(function(root,factory){
  const api=factory();
  if(typeof module==='object'&&module.exports)module.exports=api;
  else root.NowTrailing=api;
})(typeof globalThis!=='undefined'?globalThis:this,function(){
  'use strict';
  const DEFAULTS={upTrailEnabled:false,upTrailActivation:100,upTrailPullback:30,upTrailSeconds:2,
    upTrailWarmupEnabled:false,upTrailWarmupSeconds:120,
    downTrailEnabled:false,downTrailActivation:-100,downTrailPullback:30,downTrailSeconds:2,
    downTrailWarmupEnabled:false,downTrailWarmupSeconds:120,
    upStairEnabled:false,upStairStep:20,upStairSeconds:2,upStairWarmupEnabled:false,upStairWarmupSeconds:120,
    downStairEnabled:false,downStairStep:20,downStairSeconds:2,downStairWarmupEnabled:false,downStairWarmupSeconds:120,
    upTrailFromEntryEnabled:false,upTrailFromEntryMove:10,
    downTrailFromEntryEnabled:false,downTrailFromEntryMove:10,
    upEntryProtectionEnabled:false,upEntryProtectionBuffer:0,
    downEntryProtectionEnabled:false,downEntryProtectionBuffer:0,
    upTrailPercentEnabled:false,upTrailPercent:35,downTrailPercentEnabled:false,downTrailPercent:35,
    upStairPercentEnabled:false,upStairPercent:35,downStairPercentEnabled:false,downStairPercent:35};
  function validate(input){
    const out={};
    for(const p of ['up','down']){
      for(const kind of ['Trail','Stair']){
        const flag=p+kind+'PercentEnabled',key=p+kind+'Percent';
        if(Object.hasOwn(input,flag)&&typeof input[flag]!=='boolean')throw Error(flag+': use checked or unchecked.');
        out[flag]=input[flag]??false;
        const raw=Object.hasOwn(input,key)?input[key]:35,n=Number(raw);
        if(!['number','string'].includes(typeof raw)||String(raw).trim()===''||!Number.isFinite(n)||n<0.01||n>100)
          throw Error(key+': enter a percentage from 0.01 to 100.');
        out[key]=n;
      }
      const relativeKey=p+'TrailFromEntryEnabled',moveKey=p+'TrailFromEntryMove';
      if(Object.hasOwn(input,relativeKey)&&typeof input[relativeKey]!=='boolean')
        throw new Error(relativeKey+': use checked or unchecked.');
      out[relativeKey]=input[relativeKey]??false;
      const rawMove=Object.hasOwn(input,moveKey)?input[moveKey]:10,move=Number(rawMove);
      if(!['number','string'].includes(typeof rawMove)||String(rawMove).trim()===''||
        !Number.isFinite(move)||move<0.01||move>100000)
        throw new Error(moveKey+': enter a number from 0.01 to 100000.');
      out[moveKey]=move;
      const entryEnabled=p+'EntryProtectionEnabled',entryBuffer=p+'EntryProtectionBuffer';
      if(Object.hasOwn(input,entryEnabled)&&typeof input[entryEnabled]!=='boolean')
        throw new Error(entryEnabled+': use checked or unchecked.');
      out[entryEnabled]=input[entryEnabled]??false;
      const rawBuffer=Object.hasOwn(input,entryBuffer)?input[entryBuffer]:0,nBuffer=Number(rawBuffer);
      if(!['number','string'].includes(typeof rawBuffer)||String(rawBuffer).trim()===''||
        !Number.isFinite(nBuffer)||nBuffer<0||nBuffer>100000)
        throw new Error(entryBuffer+': enter a number from 0 to 100000.');
      out[entryBuffer]=nBuffer;
      for(const suffix of ['Enabled','WarmupEnabled']){
        const key=p+'Stair'+suffix,raw=input[key]??DEFAULTS[key];
        if(Object.hasOwn(input,key)&&typeof input[key]!=='boolean')throw new Error(key+': use checked or unchecked.');
        out[key]=raw;
      }
      for(const [suffix,lo,hi]of [['Step',0.01,100000],['Seconds',0,300],['WarmupSeconds',1,900]]){
        const key=p+'Stair'+suffix,raw=Object.hasOwn(input,key)?input[key]:DEFAULTS[key],n=Number(raw);
        if(!['number','string'].includes(typeof raw)||String(raw).trim()===''||!Number.isFinite(n)||n<lo||n>hi)
          throw new Error(`${key}: enter a number from ${lo} to ${hi}.`);
        out[key]=n;
      }
      const enabled=input[p+'TrailEnabled']??false;
      if(Object.hasOwn(input,p+'TrailEnabled')&&typeof input[p+'TrailEnabled']!=='boolean')
        throw new Error(p+'TrailEnabled: use checked or unchecked.');
      out[p+'TrailEnabled']=enabled;
      const warmupKey=p+'TrailWarmupEnabled',warmup=input[warmupKey]??false;
      if(Object.hasOwn(input,warmupKey)&&typeof input[warmupKey]!=='boolean')
        throw new Error(warmupKey+': use checked or unchecked.');
      out[warmupKey]=warmup;
      for(const [suffix,lo,hi] of [['Activation',p==='up'?0:-100000,p==='up'?100000:0],
        ['Pullback',0.01,100000],['Seconds',0,300],['WarmupSeconds',1,900]]){
        const key=p+'Trail'+suffix,raw=Object.hasOwn(input,key)?input[key]:DEFAULTS[key],n=Number(raw);
        if(!['number','string'].includes(typeof raw)||String(raw).trim()===''||!Number.isFinite(n)||n<lo||n>hi)
          throw new Error(`${key}: enter a number from ${lo} to ${hi}.`);
        out[key]=n;
      }
    }
    return out;
  }
  function entryDistance(rules,p,kind,entryNow,dollars){
    const percentMode=rules[p+kind+'PercentEnabled']===true,percent=rules[p+kind+'Percent']??35;
    const distance=percentMode?(Number.isFinite(entryNow)&&Math.abs(entryNow)>0?
      Math.abs(entryNow)*percent/100:null):dollars;
    return {percentMode,percent,distance,available:Number.isFinite(distance)&&distance>0};
  }
  function evaluate(previous,rules,m,side,key,now,running=true,marketOpenTime=null,entryNow=null){
    const up=side==='UP',p=up?'up':'down';
    const state=previous?.key===key?{...previous}:{key,best:null,since:null,last:null};
    const enabled=rules[p+'TrailEnabled']===true;
    const fromEntry=rules[p+'TrailFromEntryEnabled']===true;
    const entryMove=rules[p+'TrailFromEntryMove']??10;
    const anchored=Number.isFinite(entryNow);
    const activation=fromEntry?(anchored?entryNow+(up?entryMove:-entryMove):null):
      rules[p+'TrailActivation']??DEFAULTS[p+'TrailActivation'];
    const basis=entryDistance(rules,p,'Trail',entryNow,rules[p+'TrailPullback']??DEFAULTS[p+'TrailPullback']);
    const pullback=basis.distance;
    const requiredMs=(rules[p+'TrailSeconds']??2)*1000;
    const warmupEnabled=rules[p+'TrailWarmupEnabled']===true;
    const warmupMs=(rules[p+'TrailWarmupSeconds']??120)*1000;
    const marketAgeMs=Number.isFinite(marketOpenTime)&&marketOpenTime>0?now-marketOpenTime:null;
    const warmupRemainingMs=marketAgeMs==null?null:Math.max(0,warmupMs-marketAgeMs);
    const warmupBlocked=warmupEnabled&&(marketAgeMs==null||marketAgeMs<warmupMs);
    const ready=m?.ready===true&&Number.isFinite(m.nowDiff);
    if(!Number.isFinite(state.best))state.best=null;
    if(!ready||!running||state.last==null||now<state.last||now-state.last>3500)state.since=null;
    state.last=ready?now:null;
    if(ready)state.best=state.best==null?m.nowDiff:(up?Math.max(state.best,m.nowDiff):Math.min(state.best,m.nowDiff));
    const active=enabled&&basis.available&&Number.isFinite(activation)&&state.best!=null&&(up?state.best>=activation:state.best<=activation);
    const candidate=active?state.best+(up?-pullback:pullback):null;
    if(active)state.level=basis.percentMode&&Number.isFinite(state.level)?
      (up?Math.max(state.level,candidate):Math.min(state.level,candidate)):candidate;
    const level=active?state.level:null;
    const breached=ready&&active&&(up?m.nowDiff<=level:m.nowDiff>=level);
    if(!breached||!enabled||!running||warmupBlocked)state.since=null;
    else if(state.since==null)state.since=now;
    const elapsedMs=state.since==null?0:Math.max(0,now-state.since);
    const action=!enabled?'OFF':!ready?'PAUSED':!running?'STOPPED':!basis.available||fromEntry&&!anchored?'PAUSED':
      warmupEnabled&&marketAgeMs==null?'PAUSED':warmupBlocked?'WARMUP':!active?'WAITING':
      !breached?'HOLD':elapsedMs>=requiredMs?'SELL':'EXIT_WAIT';
    const reason=action==='SELL'?`${side} trailing exit: Now ${m.nowDiff.toFixed(2)} reached ${level.toFixed(2)} after a $${pullback} pullback from best ${state.best.toFixed(2)}; wait complete.`:
      action==='EXIT_WAIT'?`Trailing pullback confirmed for ${(elapsedMs/1000).toFixed(1)} / ${requiredMs/1000}s.`:
      action==='WARMUP'?`Opening warm-up: ${Math.ceil(warmupRemainingMs/1000)}s left of ${warmupMs/1000}s from market open. Only trailing is blocked; other exits remain active. Best is tracked; confirmation starts after warm-up.`:
      action==='PAUSED'?!basis.available?
        'Percentage trailing paused: a finite, nonzero recorded entry Now is required. No dollar fallback or anchor is guessed. Other exits remain independent.':fromEntry&&!anchored?
        'Trailing paused: recorded entry Now is unavailable. Entry-relative activation cannot be guessed. Other exits remain independent.':
        warmupEnabled&&marketAgeMs==null?
        'Trailing paused: market opening time unavailable; warm-up cannot be verified. Other exits remain independent.':
        'Trailing paused: fresh prices required. Best retained; timer reset.':
      action==='STOPPED'?'Trailing monitor only: bot stopped. No automatic orders.':
      action==='OFF'?'Trailing exit is off.':
      action==='WAITING'?`Waiting for Now ${up?'≥':'≤'} ${activation}${fromEntry?` ($${entryMove} favorable from entry ${entryNow.toFixed(2)})`:''} to activate trailing.`:
      `Trailing active: sell if Now ${up?'≤':'≥'} ${level.toFixed(2)} for ${requiredMs/1000}s.`;
    return {state,enabled,active,level,best:state.best,now:m?.nowDiff??null,activation,pullback,fromEntry,entryMove,entryNow,
      percentMode:basis.percentMode,percent:basis.percent,requiredMs,elapsedMs,breached,action,reason,side,warmupEnabled,warmupMs,
      marketAgeMs,warmupRemainingMs,warmupBlocked};
  }
  function evaluateStair(previous,rules,m,side,key,now,running=true,marketOpenTime=null,entryNow=null){
    const up=side==='UP',p=(up?'up':'down')+'Stair',sign=up?1:-1;
    const state=previous?.key===key?{...previous}:{key,best:null,level:null,since:null,last:null};
    const enabled=rules[p+'Enabled']===true;
    const basis=entryDistance(rules,up?'up':'down','Stair',entryNow,rules[p+'Step']??20),step=basis.distance;
    const requiredMs=(rules[p+'Seconds']??2)*1000;
    const warmupEnabled=rules[p+'WarmupEnabled']===true,warmupMs=(rules[p+'WarmupSeconds']??120)*1000;
    const marketAgeMs=Number.isFinite(marketOpenTime)&&marketOpenTime>0?now-marketOpenTime:null;
    const warmupRemainingMs=marketAgeMs==null?null:Math.max(0,warmupMs-marketAgeMs);
    const warmupBlocked=warmupEnabled&&(marketAgeMs==null||marketAgeMs<warmupMs);
    const ready=m?.ready===true&&Number.isFinite(m.nowDiff);
    if(!Number.isFinite(state.best))state.best=null;
    if(!Number.isFinite(state.level))state.level=null;
    if(!ready||!running||state.last==null||now<state.last||now-state.last>3500)state.since=null;
    state.last=ready?now:null;
    if(ready)state.best=state.best==null?m.nowDiff:(up?Math.max(state.best,m.nowDiff):Math.min(state.best,m.nowDiff));
    const anchored=Number.isFinite(entryNow);
    // Tiny relative tolerance compensates binary rounding only at exact step boundaries.
    const distance=anchored&&state.best!=null?sign*(state.best-entryNow):0;
    const steps=anchored&&basis.available?Math.max(0,Math.floor(distance/step+1e-9)):0;
    if(enabled&&steps>=1){
      const candidate=entryNow+sign*(steps-1)*step;
      state.level=state.level==null?candidate:(up?Math.max(state.level,candidate):Math.min(state.level,candidate));
    }
    const active=enabled&&anchored&&basis.available&&state.level!=null;
    const level=active?state.level:null;
    const breached=ready&&active&&(up?m.nowDiff<=level:m.nowDiff>=level);
    if(!breached||!running||warmupBlocked)state.since=null;
    else if(state.since==null)state.since=now;
    const elapsedMs=state.since==null?0:Math.max(0,now-state.since);
    const action=!enabled?'OFF':!ready?'PAUSED':!running?'STOPPED':!anchored||!basis.available?'PAUSED':
      warmupEnabled&&marketAgeMs==null?'PAUSED':warmupBlocked?'WARMUP':!active?'WAITING':
      !breached?'HOLD':elapsedMs>=requiredMs?'SELL':'EXIT_WAIT';
    const reason=action==='OFF'?'Staircase exit is off.':
      action==='PAUSED'?!basis.available?'Percentage staircase paused: a finite, nonzero recorded entry Now is required. No step or anchor is guessed.':
        !anchored?'Staircase paused: entry Now was unavailable. No entry is guessed.':
        !ready?'Staircase paused: fresh prices required; barrier retained, recovery timer reset.':
          'Staircase paused: market opening time unavailable.':
      action==='STOPPED'?'Staircase monitor only: bot stopped. No automatic orders.':
      action==='WARMUP'?`Staircase opening warm-up: ${Math.ceil(warmupRemainingMs/1000)}s left. Other exits remain independent.`:
      action==='WAITING'?`Waiting for a full $${step} favorable move from entry Now ${entryNow.toFixed(2)}. No staircase barrier yet.`:
      action==='SELL'?`${side} staircase exit: Now ${m.nowDiff.toFixed(2)} breached locked barrier ${level.toFixed(2)}; ${requiredMs/1000}s recovery wait complete.`:
      action==='EXIT_WAIT'?`Staircase breach: ${(elapsedMs/1000).toFixed(1)} / ${requiredMs/1000}s recovery timer; recover ${up?'above':'below'} ${level.toFixed(2)} to cancel.`:
      `Locked staircase barrier ${level.toFixed(2)}; next full $${step} favorable step tightens it.`;
    return {state,enabled,active,level,best:state.best,entryNow,step,steps,percentMode:basis.percentMode,percent:basis.percent,requiredMs,elapsedMs,
      breached,action,reason,side,warmupEnabled,warmupMs,marketAgeMs,warmupRemainingMs,warmupBlocked};
  }
  function evaluateEntryProtection(rules,m,side,entryNow,running=true){
    const up=side==='UP',p=up?'up':'down';
    const enabled=rules[p+'EntryProtectionEnabled']===true;
    const buffer=rules[p+'EntryProtectionBuffer']??0,anchored=Number.isFinite(entryNow);
    const level=anchored?entryNow+(up?-buffer:buffer):null;
    const ready=m?.ready===true&&Number.isFinite(m.nowDiff);
    const active=enabled&&anchored;
    const breached=ready&&active&&(up?m.nowDiff<level:m.nowDiff>level);
    const action=!enabled?'OFF':!anchored||!ready?'PAUSED':!running?'STOPPED':breached?'SELL':'HOLD';
    const reason=action==='OFF'?'Entry-point protection is off.':
      action==='PAUSED'?!anchored?'Entry protection paused: recorded entry Now is unavailable. No entry is guessed.':
        'Entry protection paused: fresh prices required.':
      action==='STOPPED'?'Entry protection monitor only: bot stopped. No automatic orders.':
      action==='SELL'?`${side} entry protection: Now ${m.nowDiff.toFixed(2)} is ${up?'below':'above'} entry stop ${level.toFixed(2)} (entry ${entryNow.toFixed(2)}, buffer $${buffer}). No extra wait.`:
      `Entry protection active: sell if Now ${up?'below':'above'} ${level.toFixed(2)}. Equality holds; no favorable move is required first.`;
    return {enabled,active,entryNow:anchored?entryNow:null,buffer,level:active?level:null,
      now:ready?m.nowDiff:null,breached,action,reason,side};
  }
  return {DEFAULTS,validate,evaluate,evaluateStair,evaluateEntryProtection};
});
