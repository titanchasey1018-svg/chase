(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.SignedBuy = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const DEFAULTS = { upBuyNow: 40, downBuyNow: -40 };
  function priceThreshold(settings, side) {
    return Number(settings[side === 'UP' ? 'upBuyCents' : 'downBuyCents'] ?? settings.triggerPoint ?? 90);
  }
  function validate(body, settings, running) {
    for (const [key, lo, hi] of [['upBuyNow', 0, 100000], ['downBuyNow', -100000, 0],
      ['upBuyCents',1,99],['downBuyCents',1,99]]) {
      if (body[key] === undefined) continue;
      const raw = body[key], n = Number(raw);
      if (!['number','string'].includes(typeof raw) || String(raw).trim() === '' ||
          !Number.isFinite(n) || n < lo || n > hi) {
        throw new Error(`${key}: enter ${key.endsWith('Cents')?'a cents value':'a signed dollar value'} from ${lo} to ${hi}.`);
      }
      const saved = key.endsWith('Cents') ? priceThreshold(settings,key.startsWith('up')?'UP':'DOWN') : settings[key];
      if (running && n !== saved) throw new Error('Stop the bot before changing buy thresholds.');
    }
  }
  function evaluate(settings, quote, metrics, side) {
    const up = side === 'UP';
    const ask = up ? quote?.upAsk : quote?.downAsk;
    const threshold = settings[up ? 'upBuyNow' : 'downBuyNow'];
    const now = metrics?.nowDiff;
    const centsThreshold = priceThreshold(settings,side);
    const pricePassed = Number.isFinite(ask) && ask > centsThreshold;
    const nowPassed = Number.isFinite(now) && Number.isFinite(threshold) &&
      (up ? now >= threshold : now <= threshold);
    const ready = metrics?.ready === true && Number.isFinite(now);
    const passed = ready && pricePassed && nowPassed;
    const reason = !ready ? 'Fresh Coinbase, exchange prices and Kalshi target/quote are required.' :
      !pricePassed ? `${side} ask must exceed ${centsThreshold} cents.` :
      !nowPassed ? `${side} Now must be ${up ? 'at or above' : 'at or below'} ${threshold} USD.` :
      `${side} contract price and signed Now requirements both pass.`;
    return { side, ask, now, threshold, centsThreshold, pricePassed, nowPassed, ready, passed, reason };
  }
  return { DEFAULTS, priceThreshold, validate, evaluate };
});
