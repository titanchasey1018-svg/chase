(function(root){
  'use strict';
  root.NowEntryUI={create(save){
    const $=id=>document.getElementById(id),engine=root.NowEntry;
    let state,snapshot,signature='',pending=false,offline=false,conflict=false;
    let side='up',applying=null,preservedDraft=null,applyingSignature='';
    const fields=engine.FIELDS,node=$('nowEntryFields');
    const field=(key,label,min,max)=>`<div class="field-row"><label for="nw-${key}">${label}</label><input id="nw-${key}" ${key.endsWith('Level')?'type="text" inputmode="text"':'type="number" inputmode="decimal"'} min="${min}" max="${max}" step="0.01" autocomplete="off"></div>`;
    const toggle=(key,label)=>`<label class="rule-toggle"><input id="nw-${key}" type="checkbox">${label}</label>`;
    node.innerHTML=`<div class="buy-mode">`+toggle('enabled','Use low/high buy mode')+
      `<p class="micro-note">Shared by both directions. ON makes these the only buy conditions.</p></div>`+
      `<p id="nowEntrySpreadCompatibility" class="notice small" hidden>Exchange spread is NOT ACTIVE until an approved backend restart. Only the new spread controls are locked; existing buy settings remain available.</p>`+
      `<div class="buy-side-tabs" role="tablist" aria-label="Buy direction">
      <button id="buyEditorUp" role="tab" aria-controls="buyEditor-up" aria-selected="true" data-testid="tab-buy-up">UP buys <span id="buyDraft-up"></span></button>
      <button id="buyEditorDown" role="tab" aria-controls="buyEditor-down" aria-selected="false" tabindex="-1" data-testid="tab-buy-down">DOWN buys <span id="buyDraft-down"></span></button></div>`+
      ['up','down'].map(p=>{
      const side=p.toUpperCase();
      return `<div id="buyEditor-${p}" role="tabpanel" aria-labelledby="buyEditor${p==='up'?'Up':'Down'}"${p==='down'?' hidden':''}>`+
        `<div class="buy-direction-head"><h3>${side} buy settings</h3><span id="buySaved-${p}" class="tag"></span></div>`+
        toggle(p+'Enabled','Allow buying '+side)+
        `<p class="micro-note">LOW or HIGH can qualify. All checked sources must pass together, except an enabled conditional spread alternative can satisfy the Exchange spread check.</p>`+
        `<p class="micro-note">${side==='UP'?'UP minimum/floor: use HIGH ≥.':'DOWN maximum/ceiling: use LOW ≤.'} LOW/HIGH are entry alternatives, not profit-taking rules.</p>`+
        `<details class="now-entry-protection buy-direction"><summary>${side} movement guard <span id="nw-${p}DirectionState"></span></summary>`+
        toggle(p+'DirectionEnabled',side==='UP'?'Require rising confirmation before UP buys':'Require falling confirmation before DOWN buys')+
        field(p+'DirectionMove','Minimum favorable move per checked source ($)',0.01,100000)+
        field(p+'DirectionSeconds','Recent confirmation window (seconds)',0.1,300)+
        `<p class="micro-note">Additional to LOW/HIGH levels. Every checked source of one qualifying group must move ${side==='UP'?'higher':'lower'} by this amount in the recent window, with no adverse sampled move. Flat samples alone cannot qualify. An adverse sample or data gap resets confirmation. Optional: existing saved setups keep this OFF until you enable and Apply.</p>`+
        `<p id="nw-${p}DirectionLive" class="micro-note" role="status"></p></details>`+
        `<details class="buy-walkthroughs"><summary>${side} examples: step-by-step</summary>`+
        `<p class="micro-note">Read-only walkthroughs. No settings are filled or applied.</p><div class="buy-walkthrough-list">`+
        root.NowEntryExamples.walkthroughs(p).map(t=>`<button id="${t.id}" type="button" class="buy-walkthrough-button" data-testid="${t.id}" aria-haspopup="dialog" aria-controls="optionHelpDialog">${t.title.slice(side.length+3)}</button>`).join('')+
        `</div></details>`+
        ['Low','High'].map(kind=>`<section class="now-entry-band" aria-label="${side} ${kind} entry">`+
          toggle(p+kind+'Enabled',kind.toUpperCase()+' · '+(kind==='Low'?'at / below ≤':'at / above ≥'))+
          `<div class="buy-source-head"><span>Checked source</span><span>Signed level ($)</span></div>`+
          [['Target','TargetLevel','All vs target'],['Kalshi','KalshiNowLevel','Kalshi Now vs target'],['Now','Level','Coinbase Now vs target'],['Spread','SpreadLevel','Exchange spread']].map(([s,suffix,name])=>{
            const key=p+kind+suffix;
            return `<div class="buy-source-row"><div class="buy-source-choice">`+
              toggle(p+kind+'Use'+s,name)+`</div><div class="buy-source-value">`+
              `<label class="visually-hidden" for="nw-${key}">${side} ${kind.toUpperCase()} ${name} signed level</label>`+
              `<input id="nw-${key}" type="text" inputmode="text" autocomplete="off" aria-label="${side} ${kind.toUpperCase()} ${name} signed level"></div></div>`;
          }).join('')+
          `</section>`).join('')+
        `<div id="buyConditions-${p}" class="buy-conditions"></div>`+
        `<details class="buy-live"><summary>${side} saved signal details</summary>`+
        `<p id="nw-${p}Status" class="micro-note buy-signal" role="status"></p>`+
        ['Low','High'].map(kind=>`<p id="nw-${p+kind}Live" class="micro-note" role="status"></p>`).join('')+`</details>`+
        `<details class="now-entry-protection"><summary>${side} optional trailing and barriers</summary>`+
        `<p class="micro-note">Paper comparison drafts: select one Now-following method at a time. These buttons change only this side’s trail/stair switches and, for staircase, its breach confirmation. Distances, entries, percentages and independent exits are kept. Apply this side to save; no start, arm, order or profile save.</p>`+
        `<div class="rules-tools">`+
        [['trail','Trailing only'],['stair0','Staircase only · 0s'],['stair1','Staircase only · 1s']].map(([mode,label])=>
          `<button id="nw-${p}-compare-${mode}" type="button" class="text-button" data-testid="paper-compare-${p}-${mode}">Paper draft: ${label}</button>`).join('')+
        `</div><p class="micro-note">Shorter staircase confirmation reacts sooner but may exit on temporary breaches. Other enabled exits, including money-based profit trailing, can still sell first. Existing positions retain their captured Now-following plan; compare on new Paper entries.</p>`+
        toggle(p+'TrailEnabled','Enable '+side+' trailing (required for percentage mode)')+
        `<p class="micro-note">Main switch for dollar OR percentage trailing. For percentage trailing, keep this ON and check the percentage option below; the dollar pullback is then ignored. A grayed-out percentage selection is saved but does not enable trailing by itself. Changes here apply to new buys; existing positions keep their captured plan.</p>`+
        field(p+'TrailMove','Activate after favorable move from entry ($)',0.01,100000)+
        field(p+'TrailPullback','Pullback from best Now ($)',0.01,100000)+
        toggle(p+'TrailPercentEnabled','Use % of entry Now for pullback (requires trailing ON)')+
        field(p+'TrailPercent','Trailing distance (% of entry Now)',0.01,100)+
        field(p+'TrailSeconds','Trailing breach confirmation (seconds)',0,300)+
        toggle(p+'StairEnabled','Enable '+side+' staircase (required for chart-based percentage steps)')+
        `<p class="micro-note">Chart-based percentage steps require this staircase switch ON, not the trailing switch. Keep staircase ON and check automatic calculation below. The chart BUY value sets the step distance; the barrier follows favorable full steps. The percentage checkbox alone does not enable staircase. Changes here apply to new buys; existing positions keep their captured plan.</p>`+
        field(p+'StairStep','Favorable staircase step ($)',0.01,100000)+
        toggle(p+'StairPercentEnabled','Automatically calculate barrier step from chart BUY (requires staircase ON)')+
        field(p+'StairPercent','Percentage of BUY value (%)',0.01,100)+
        `<p id="nw-${p}BarrierBuyPreview" class="micro-note" role="status" data-testid="barrier-buy-preview-${p}"></p>`+
        field(p+'StairSeconds','Staircase breach confirmation (seconds)',0,300)+
        `<p id="nw-${p}PercentNote" class="micro-note"></p>`+
        `<p class="micro-note">Percentage uses absolute first-fill Coinbase Now, not contract cost, profit or the moving peak. Missing/zero entry pauses that percentage exit. Dollar values stay saved when percentage is checked. Activation and confirmation still apply. A staircase has no barrier before its first full favorable step.</p>`+
        `<p class="micro-note">Favorable for ${side}: Now moves ${p==='up'?'higher':'lower'}, regardless of whether a low or high trigger bought it. No opening warm-up here. Zero seconds means attempt an exit on the first fresh breach.</p></details></div>`;
    }).join('');
    function draft(){
      return {...snapshot,...Object.fromEntries(fields.map(k=>[k,typeof engine.DEFAULTS[k]==='boolean'?$('nw-'+k).checked:$('nw-'+k).value]))};
    }
    function dirty(){
      if(!snapshot)return false;
      return root.NowEntryEditor.changed(snapshot,draft());
    }
    function message(text,error=false){
      $('nowEntryFeedback').textContent=text;
      $('nowEntryFeedback').className='feedback '+(error?'error':'success');
    }
    function fill(config){
      snapshot=engine.validate(config);signature=JSON.stringify(snapshot);conflict=false;
      for(const k of fields)if(typeof engine.DEFAULTS[k]==='boolean')$('nw-'+k).checked=snapshot[k];
      else $('nw-'+k).value=snapshot[k]??'';
    }
    function restoreRaw(raw){
      for(const k of fields)if(typeof engine.DEFAULTS[k]==='boolean')$('nw-'+k).checked=raw[k];
      else $('nw-'+k).value=raw[k]??'';
    }
    function show(p,focus=false){
      side=p;
      for(const x of ['up','down']){
        const tab=$('buyEditor'+(x==='up'?'Up':'Down')),active=x===side;
        tab.setAttribute('aria-selected',String(active));tab.tabIndex=active?0:-1;
        $('buyEditor-'+x).hidden=!active;
        if(active&&focus)tab.focus();
      }
      if(state)update();
    }
    for(const p of ['up','down']){
      for(const mode of ['trail','stair0','stair1'])$('nw-'+p+'-compare-'+mode).onclick=()=>{
        if(state?.settings.mode!=='paper'||state.running||pending||offline||conflict)return;
        $('nw-'+p+'TrailEnabled').checked=mode==='trail';
        $('nw-'+p+'StairEnabled').checked=mode!=='trail';
        if(mode!=='trail')$('nw-'+p+'StairSeconds').value=mode==='stair0'?0:1;
        message(p.toUpperCase()+' Paper comparison draft only. Apply '+p.toUpperCase()+' buy settings to save. Other independent exits remain unchanged.');
        update();
      };
      const tab=$('buyEditor'+(p==='up'?'Up':'Down'));
      tab.onclick=()=>show(p);
      tab.onkeydown=e=>{
        if(['ArrowLeft','ArrowRight','Home','End'].includes(e.key)){
          e.preventDefault();show(e.key==='Home'?'up':e.key==='End'?'down':side==='up'?'down':'up',true);
        }
      };
    }
    function update(){
      const supported=state?.features?.nowEntrySignedKalshi===true;
      const movementSupported=state?.features?.nowEntryDirection===true;
      const spreadSupported=state?.features?.lowHighExchangeSpread===true;
      $('nowEntrySpreadCompatibility').hidden=spreadSupported;
      $('nowEntryCompatibility').hidden=supported&&movementSupported;
      $('nowEntryCompatibility').textContent=supported?
        'Existing thresholds and source checkboxes can be edited and applied while stopped. The new movement guard is NOT ACTIVE and its controls remain locked until an approved backend restart. Starts and manual buys remain paused in this view pending activation; manual sells remain available.':
        'Signed Kalshi entry support is unavailable. Threshold edits require a compatible backend; saved settings are unchanged.';
      const locked=!supported||pending||offline||state?.running;
      for(const k of fields)$('nw-'+k).disabled=locked;
      for(const p of ['up','down']){
        const sideLocked=locked||!$('nw-'+p+'Enabled').checked;
        for(const mode of ['trail','stair0','stair1'])$('nw-'+p+'-compare-'+mode).disabled=
          locked||conflict||state?.settings.mode!=='paper';
        for(const k of fields.filter(k=>k.startsWith(p)&&k!==p+'Enabled'))
          $('nw-'+k).disabled=sideLocked;
        for(const kind of ['Low','High']){
          const bandLocked=sideLocked||!$('nw-'+p+kind+'Enabled').checked;
          for(const source of ['Now','Target','Kalshi','Spread']){
            const sourceLocked=bandLocked||(source==='Spread'&&!spreadSupported);
            $('nw-'+p+kind+'Use'+source).disabled=sourceLocked;
            $('nw-'+p+kind+(source==='Now'?'Level':source==='Kalshi'?'KalshiNowLevel':source+'Level')).disabled=
              sourceLocked||!$('nw-'+p+kind+'Use'+source).checked;
          }
        }
        for(const suffix of ['Move','Pullback','Seconds'])
          $('nw-'+p+'Trail'+suffix).disabled=sideLocked||!$('nw-'+p+'TrailEnabled').checked;
        for(const suffix of ['Step','Seconds'])
          $('nw-'+p+'Stair'+suffix).disabled=sideLocked||!$('nw-'+p+'StairEnabled').checked;
        for(const kind of ['Trail','Stair']){
          const supported=state?.features?.percentageExitDistance===true;
          const mode=$('nw-'+p+kind+'PercentEnabled'),selected=mode.checked;
          mode.disabled=sideLocked||!supported||!$('nw-'+p+kind+'Enabled').checked;
          $('nw-'+p+kind+'Percent').disabled=mode.disabled||!selected;
          if(selected)$('nw-'+p+kind+(kind==='Trail'?'Pullback':'Step')).disabled=true;
        }
        const percent=k=>engine.number($('nw-'+p+k+'Percent').value);
        $('nw-'+p+'BarrierBuyPreview').textContent=root.BarrierBuyValue.preview(
          p.toUpperCase(),state?.openTrade?.ticker===state?.market?.ticker?state.openTrade:null,
          $('nw-'+p+'StairPercentEnabled').checked,percent('Stair'));
        const example=k=>Number.isFinite(percent(k))?(165*percent(k)/100).toFixed(2):'--';
        $('nw-'+p+'PercentNote').textContent=state?.features?.percentageExitDistance!==true?
          'Percentage options NOT ACTIVE until an approved backend restart. Existing dollar settings remain editable.':
          `Example entry ${p==='up'?'+165':'−165'}: trail ${percent('Trail')}% → $${example('Trail')} pullback; barrier ${percent('Stair')}% → $${example('Stair')} per step. Draft examples only; enable and Apply to use for new entries.`;
        $('nw-'+p+'DirectionEnabled').disabled=sideLocked||!movementSupported;
        for(const suffix of ['Move','Seconds'])
          $('nw-'+p+'Direction'+suffix).disabled=sideLocked||!movementSupported||!$('nw-'+p+'DirectionEnabled').checked;
      }
      $('applyNowEntry').disabled=locked||conflict;
      $('applyNowEntry').textContent='Apply '+side.toUpperCase()+' buy settings';
      $('nowEntryApplyScope').textContent='Saves '+side.toUpperCase()+' + shared mode. Keeps '+(side==='up'?'DOWN':'UP')+' saved values and drafts.';
      $('reloadNowEntry').disabled=pending||!state;
      $('nowEntryBadge').textContent=!supported?'PENDING ACTIVATION':state.settings.nowEntry?.enabled?'APPLIED ON':'APPLIED OFF';
      $('nowEntrySaveState').textContent=!supported?'Signed Kalshi entry support is unavailable. Threshold edits are disabled until compatible backend activation.':
        offline?'Offline. Saved bot trading state is unknown; changes are disabled.':
        conflict?'Saved Now settings changed elsewhere. Your draft was kept. Use Reload saved before editing again.':
        dirty()?'Unsaved Now-monitor draft. Apply to save; trading has not changed.':
        state.running?'Stop this bot before changing the Now monitor.':'Saved. Applying never starts or arms trading.';
      for(const p of ['up','down']){
        const isDirty=snapshot&&root.NowEntryEditor.changed(snapshot,draft(),p);
        $('buyDraft-'+p).textContent=isDirty?'· DRAFT':'';
        $('buySaved-'+p).textContent=state.settings.nowEntry?.[p+'Enabled']?'SAVED: ALLOWED':'SAVED: DISABLED';
        const signal=state?.nowEntrySignals?.[p.toUpperCase()]||
          engine.evaluate(state?.settings?.nowEntry,state?.feeds,p.toUpperCase(),state?.kalshiIndex);
        $('nw-'+p+'DirectionState').textContent=$('nw-'+p+'DirectionEnabled').checked?' · ON'+(isDirty?' draft':''):' · OFF';
        const movement=signal.direction;
        $('nw-'+p+'DirectionLive').textContent=offline?'Connection lost; movement confirmation unknown.':
          !movementSupported?'New movement guard NOT ACTIVE. Existing thresholds can still be edited and applied. Activation needs restart approval.':
          !state.settings.nowEntry?.[p+'DirectionEnabled']?'Saved movement guard OFF. A matching threshold alone does not prove direction.':
          (state.running?'':'STOPPED · observations only, no automatic orders. ')+(movement?.reason||'Waiting for server observations.')+
          (movement?.groups||[]).map(g=>' '+g.kind.toUpperCase()+': '+(g.confirmed?'confirmed':
            'waiting')+(Number.isFinite(g.move)?' · smallest source move $'+g.move.toFixed(2):'')).join('');
        $('nw-'+p+'Status').textContent=offline?'Connection lost. Signal state unknown.':
          (state?.running?'':'STOPPED · ')+signal.reason;
        for(const g of signal.groups){
          const checks=g.checks.filter(x=>x.enabled);
          const display=n=>Number.isFinite(n)?n.toFixed(2):'--';
          $('nw-'+p+g.kind+'Live').textContent='Saved '+g.kind.toUpperCase()+': '+
            (!g.enabled?'group OFF.':offline?'connection lost; values unknown.':
            checks.map(x=>x.name+': '+(!x.ready?'unavailable':display(x.value)+' '+x.op+' '+display(x.threshold)+
              (x.passed?' · MET':x.substituted?' · NOT MET; conditional alternative MET':' · NOT MET'))).join(' | ')||'no checked conditions.');
        }
      }
      $('nowEntryOwned').hidden=!state?.openTrade?.nowEntryConfig;
      const missing=engine.missingKalshiLevels(draft());
      $('nowEntryKalshiMigration').hidden=!missing.length;
      $('nowEntryKalshiMigration').textContent=missing.length?
        missing.join(', ')+': enter a signed Kalshi Now value, such as -26.90. Old full BTC price values remain saved but are not used. Apply saves new values without starting or arming.':'';
    }
    $('applyNowEntry').onclick=async()=>{
      try{
        const raw=draft(),scope=side,config=root.NowEntryEditor.scope(snapshot,raw,scope);
        applying=scope;preservedDraft=raw;
        applyingSignature=JSON.stringify(config);
        await save(root.NowEntryEditor.forBackend(config,state.features),
          root.NowEntryEditor.forBackend(snapshot,state.features));
        message(scope.toUpperCase()+' buy settings and shared mode saved. '+(scope==='up'?'DOWN':'UP')+' values and drafts kept. No bot started or armed.');
      }catch(e){message(e.message,true);}
      finally{applying=null;preservedDraft=null;if(state)update();}
    };
    $('reloadNowEntry').onclick=()=>{
      fill(state?.settings?.nowEntry);update();message('Saved Now settings reloaded. Unsaved drafts discarded; no trading changed.');
    };
    node.addEventListener('input',()=>{$('nowEntryFeedback').textContent='';update();});
    return {
      dirty,
      reveal(p){show(p.toLowerCase());},
      reload(){if(state){fill(state.settings.nowEntry);update();}},
      render(s,flags={}){
        state=s;pending=!!flags.pending;offline=!!flags.disconnected;
        const config=engine.validate(s.settings.nowEntry),next=JSON.stringify(config);
        if(!snapshot)fill(config);
        else if(next!==signature){
          if(applying&&preservedDraft&&next===applyingSignature){
            const retained=root.NowEntryEditor.retainOther(config,preservedDraft,applying);
            fill(config);restoreRaw(retained);
          }else if(dirty()&&(!pending||applying))conflict=true;
          else fill(config);
        }
        update();
      },
    };
  }};
})(globalThis);
