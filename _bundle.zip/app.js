(() => {
  'use strict';
  const RAW = window.__API__ || '';
  const API = RAW.startsWith('__PORT') ? '' : RAW.replace(/\/$/, '');
  const $ = id => document.getElementById(id);
  const coinQuery=new URL(location.href).searchParams.get('coin');
  const invalidCoin=coinQuery!==null&&!['BTC','ETH','SOL'].includes(coinQuery);
  const viewedCoin=['ETH','SOL'].includes(coinQuery)?coinQuery:'BTC';
  const coinButtons=[...document.querySelectorAll('[data-coin]')];
  const apiUrl=path=>API+(viewedCoin!=='BTC'&&path.startsWith('/api/')&&!path.startsWith('/api/session/')?
    `/api/coins/${viewedCoin}/${path.slice(5)}`:path);
  function coinUrl(asset){
    const url=new URL(location.href);url.hash='';
    if(asset==='BTC')url.searchParams.delete('coin');else url.searchParams.set('coin',asset);
    return url.href;
  }
  const reveal=el=>{
    for(let p=el?.parentElement;p;p=p.parentElement)if(p.tagName==='DETAILS')p.open=true;
    return el;
  };
  const KEYS = Object.keys(SpreadGuard.DEFAULT_RULES);
  const SELL_VOLUME_KEYS=Object.keys(ContractVolume.EXIT_DEFAULTS);
  const safetyUI=SafetyUI.create(SafetyControls);
  const followingUI=FollowingTrailUI.create(FollowingTrail);
  const candleUI=CandleReversalUI.create(CandleReversal,async body=>{
    await perform(()=>api('/api/settings',body));
  });
  const lineUI=LineTrailUI.create(LineTrail,async body=>{
    await perform(()=>api('/api/settings',body));
  });
  $('editLineTrail').onclick=()=>{
    const el=reveal($('lineTrailSection'));el.scrollIntoView({behavior:'smooth',block:'start'});
  };
  const entryWindowUI=EntryWindowUI.create(async body=>{
    await perform(()=>api('/api/settings',body));
  });
  let state, offset = 0, pending = false, selected = 'UP', initialized = false;
  let polling = false, wakeLock = null, lastSuccess = 0, dialogResolve, disconnected = false;
  let pricePolling=false, latestPrices=null, priceChannel='standard', nextPriceTry=0;
  let chartMinutes=15,chartView={minutes:15,end:null},chartScope=null;
  let sessionEpoch=0,sessionBusy=false,recoveredSessions=[],recoveryRequired=false;
  const buySound=BuySound.create({onStatus:text=>{$('buySoundStatus').textContent=text;}});
  $('buySoundEnabled').checked=buySound.enabled;
  $('buySoundEnabled').disabled=$('testBuySound').disabled=!buySound.supported;
  $('buySoundEnabled').onchange=()=>{void buySound.setEnabled($('buySoundEnabled').checked);};
  $('testBuySound').onclick=()=>{void buySound.test();};
  const nowEntryUI=NowEntryUI.create(async(nowEntry,expectedNowEntry)=>{
    await perform(()=>api('/api/settings',{nowEntry,expectedNowEntry}));
  });
  const buyConditionsUI=BuyConditionsUI.create(async(buyConditions,expectedBuyConditions)=>{
    await perform(()=>api('/api/settings',{buyConditions,expectedBuyConditions}));
  });
  const nowExitUI=NowExitUI.create(async(nowExit,expectedNowExit)=>{
    await perform(()=>api('/api/settings',{nowExit,expectedNowExit}));
  });
  const REBUY_FIELDS={
    inUpRebuyEnabled:['upRebuyEnabled',false],inUpRebuyDirection:['upRebuyDirection','above'],inUpRebuyMove:['upRebuyMove',20],
    inDownRebuyEnabled:['downRebuyEnabled',false],inDownRebuyDirection:['downRebuyDirection','below'],inDownRebuyMove:['downRebuyMove',20]};
  const supportsRebuy=()=>typeof state?.settings?.upRebuyEnabled==='boolean';
  function rebuyDraft(){
    return supportsRebuy()?Object.fromEntries(Object.entries(REBUY_FIELDS).map(([id,[key,value]])=>
      [key,typeof value==='boolean'?$(id).checked:typeof value==='number'?$(id).value:$(id).value])):{};
  }
  function rebuyDirty(){
    return supportsRebuy()&&Object.entries(rebuyDraft()).some(([key,value])=>
      (typeof state.settings[key]==='number'?(String(value).trim()===''?NaN:Number(value)):value)!==state.settings[key]);
  }
  function renderRebuyPreviews(){
    const sold=state?.nowChart?.sales?.filter(s=>s.completed).at(-1);
    for(const [side,prefix]of [['UP','Up'],['DOWN','Down']]){
      const enabled=$('in'+prefix+'RebuyEnabled').checked;
      const direction=$('in'+prefix+'RebuyDirection').value;
      const raw=$('in'+prefix+'RebuyMove').value,move=Number(raw);
      const target=$(side==='UP'?'upRebuyPreview':'downRebuyPreview');
      if(!enabled){target.textContent=`OFF · No Sold-line movement requirement for buying ${side}.`;continue;}
      if(!Number.isFinite(sold?.now)){target.textContent='Waiting for a completed sale with fresh Now. Its Sold line will set the reference automatically.';continue;}
      if(raw.trim()===''||!Number.isFinite(move)||move<0||move>100000){target.textContent='Enter a distance from $0 to $100,000.';continue;}
      const level=sold.now+(direction==='above'?move:-move);
      target.textContent=`${rebuyDirty()?'Draft':'Applied'}: SOLD ${signed(sold.now)} → buy ${side} when Now is ${direction==='above'?'at or above':'at or below'} ${signed(level)}. ${!$('inReentryEnabled').checked?'Enable ordinary re-entry first. ':''}Other entry rules still apply.${rebuyDirty()?' Save to apply.':''}`;
    }
  }
  const usd = n => Number.isFinite(n) ? n.toLocaleString('en-US', { style:'currency', currency:'USD' }) : '--';
  const quoteUsd=n=>viewedCoin==='BTC'?usd(n):Number.isFinite(n)?
    n.toLocaleString('en-US',{style:'currency',currency:'USD',maximumFractionDigits:4}):'--';
  const signed = n => Number.isFinite(n) ? (n >= 0 ? '+' : '−') + quoteUsd(Math.abs(n)) : '--';
  const number = n => Number.isFinite(n) ? (n >= 0 ? '+' : '−') + Math.abs(n).toFixed(2) : '--';
  const time = t => new Date(t).toLocaleTimeString([], { hour12:false });
  async function api(path, body) {
    const epoch=sessionEpoch;
    const res = await fetch(apiUrl(path), body === undefined ? { cache:'no-store' } :
      { method:'POST', headers:{ 'Content-Type':'application/json' }, body:JSON.stringify(body) });
    let data; try { data = await res.json(); } catch { throw Object.assign(new Error('Server response was not readable.'),{status:res.status}); }
    if(epoch!==sessionEpoch)throw new Error('Session view changed. Refreshing connection.');
    if (!res.ok) {
      const error=new Error(data.error || `Request failed (${res.status}).`);
      error.code=data.code;
      error.status=res.status;
      throw error;
    }
    if(path==='/api/state'&&(data.settings?.asset||'BTC')!==viewedCoin)
      throw Object.assign(new Error('Wrong coin response. Trading controls stay hidden.'),{status:404});
    return data;
  }
  function feedback(id, message, type = '') { $(id).textContent = message; $(id).className = 'feedback ' + type; }
  function toast(message) {
    $('toast').textContent = message; $('toast').classList.add('show');
    clearTimeout(toast.timer); toast.timer = setTimeout(() => $('toast').classList.remove('show'), 4000);
  }
  function confirmAction(title, body, accept = 'Confirm') {
    $('confirmTitle').textContent = title; $('confirmBody').textContent = body;
    $('confirmAccept').textContent = accept; $('confirmDialog').showModal();
    return new Promise(resolve => { dialogResolve = resolve; });
  }
  function finishConfirm(value) { $('confirmDialog').close(); dialogResolve?.(value); dialogResolve = null; }
  $('confirmAccept').onclick = () => finishConfirm(true);
  $('confirmCancel').onclick = () => finishConfirm(false);
  $('confirmDialog').addEventListener('cancel', e => { e.preventDefault(); finishConfirm(false); });
  function paintValue(id, value) {
    const el = $(id); el.textContent = signed(value);
    el.classList.toggle('positive', Number.isFinite(value) && value >= 0);
    el.classList.toggle('negative', Number.isFinite(value) && value < 0);
  }
  function renderClock() {
    const remaining = state?.market ? Math.max(0, Math.floor((state.market.closeTime - Date.now() - offset) / 1000)) : null;
    $('clock').textContent = remaining == null ? '--:--' :
      `${String(Math.floor(remaining / 60)).padStart(2,'0')}:${String(remaining % 60).padStart(2,'0')}`;
  }
  function renderFeeds() {
    const f = state.feeds || {};
    $('coinbasePrice').textContent = quoteUsd(f.coinbase); $('aggregatePrice').textContent = quoteUsd(f.aggregate);
    const cb = f.venues?.find(v => v.name === 'Coinbase');
    $('coinbaseStatus').textContent = cb?.fresh ? 'Live' : 'Unavailable';
    $('coinbaseStatus').classList.toggle('fresh', !!cb?.fresh);
    $('aggregateStatus').textContent = f.count >= 2 ? `${f.count} live venues` : 'Waiting';
    $('aggregateStatus').classList.toggle('fresh', f.count >= 2);
    $('venueSummary').textContent = `${f.count || 0} fresh venues · details`;
    $('venueRows').replaceChildren(...(f.venues || []).map(v => {
      const row = document.createElement('div'); row.className = 'venue-row';
      const name = document.createElement('span'); name.textContent = v.name;
      const val = document.createElement('span');
      val.textContent = v.fresh ? `${quoteUsd(v.price)} · ${Math.floor(v.ageMs / 1000)}s` : 'Unavailable / stale';
      row.append(name,val); return row;
    }));
    paintValue('spreadValue', f.spread); paintValue('targetValue', f.targetDiff); paintValue('nowValue', f.nowDiff);
    const index=state.kalshiIndex,live=index?.fresh===true&&!disconnected;
    const publicIndex=index?.sourceKind==='public_chart';
    $('kalshiIndexBasis').textContent=publicIndex?'Kalshi chart − same target':`CF ${index?.indexId||(viewedCoin==='BTC'?'BRTI':`${viewedCoin}USD_RTI`)} − same target`;
    paintValue('kalshiIndexDiff',live?index.nowDiff:null);
    $('kalshiIndexPrice').textContent=`Full ${publicIndex?'reference ':''}${viewedCoin} price `+(live?quoteUsd(index.price):'--');
    $('kalshiIndexStatus').textContent=disconnected?'Unknown':live?
      `${publicIndex?'Public':'Live'} · ${(index.ageMs/1000).toFixed(1)}s source age`:
      ({needs_key:'API key needed',no_access:'Access unavailable',connecting:'Connecting',
        reconnecting:'Reconnecting',stale:'Stale',unavailable:'Unavailable'}[index?.status]||'Unavailable');
    $('kalshiIndexStatus').classList.toggle('fresh',live);
    $('kalshiIndexReason').textContent=disconnected?'Index connection unknown; no live comparison shown.':
      index?.reason||(publicIndex?
      'Public Kalshi chart reference · requested about every 2s. Signed Kalshi Now can confirm selected entries; full coin price is display-only. Exits/chart use Coinbase Now.':
      'Signed Kalshi Now can confirm selected low/high entries. Full coin price is display-only. Exits/chart use Coinbase Now; no settlement guarantee.');
    const banner = $('connectionBanner');
    banner.hidden = f.ready && !state.error;
    banner.textContent = state.error ? `Kalshi connection: ${state.error}. Automatic actions pause on errors.` :
      (f.reason || 'Connecting to live data…');
    if(disconnected)markDisconnectedFeeds();
    renderPriceRefreshStatus();
  }
  function renderPriceRefreshStatus(){
    $('priceRefreshStatus').textContent=disconnected?
      'Connection lost · last received prices; freshness unknown.':
      priceChannel==='fast'?
      'Fast price display · 250ms refresh target; actual timing depends on network. Coinbase-based, not Kalshi index. Figures rounded independently.':
      'Standard price display · 1s refresh target; fast channel reconnecting.';
  }
  function markDisconnectedFeeds(){
    renderPriceRefreshStatus();
    for(const id of ['coinbaseStatus','aggregateStatus']){
      $(id).textContent='Unknown';$(id).classList.remove('fresh');
    }
    $('venueSummary').textContent='Connection lost · last received venues';
    $('kalshiIndexStatus').textContent='Unknown';$('kalshiIndexStatus').classList.remove('fresh');
    paintValue('kalshiIndexDiff',null);$('kalshiIndexPrice').textContent='Index price --';
    $('kalshiIndexReason').textContent='Index connection unknown; no live comparison shown.';
    $('venueRows').replaceChildren(...(state?.feeds?.venues||[]).map(v=>{
      const row=document.createElement('div');row.className='venue-row';
      row.textContent=`${v.name}: freshness unknown`;return row;
    }));
    $('connectionBanner').hidden=false;
    $('connectionBanner').textContent='Server unreachable. Last received prices shown; freshness and backend status are unknown.';
  }
  function renderGuard() {
    const own = state.openTrade?.ticker === state.market?.ticker ? state.openTrade : null;
    const side = own ? (own.side === 'yes' ? 'UP' : 'DOWN') : selected;
    const preview = SpreadGuard.evaluate(null, state.settings.rules, state.feeds, side, 'preview', Date.now());
    const d = own && state.guard ? state.guard : preview;
    const lowHigh=own&&d.lowHigh||NowExit.evaluate(null,state.settings.nowExit,state.feeds,side,'preview',Date.now(),false,state.kalshiIndex);
    $('legacySellChecks').hidden=lowHigh.enabled;
    for(const p of ['up','down']){
      $(p+'LegacySellNotice').hidden=!(state.settings.nowExit?.enabled&&state.settings.nowExit[p+'Enabled']);
    }
    $('positionChip').textContent = own ? `${own.count} ${side}` : 'NO POSITION';
    const label = !own ? 'No position' : !state.running ? 'Monitor only' : {
      HOLD:'Holding ' + side, SELL:'Sell ' + side, EXIT_WAIT:'Waiting before sell', QUALIFYING:'Qualifying spread',
      TRAIL_WAIT:'Confirming trailing exit',
      STAIR_WAIT:'Staircase recovery timer',
      STAIR_WARMUP:'Staircase opening warm-up',
      TRAIL_WARMUP:'Trailing opening warm-up',
      LOSS_NO_BID:'Loss stop waiting for sell bid', LOSS_PAUSED:'Loss stop waiting for fresh quote',
      LOSS_WAIT:'Stop-loss cooldown',
      WAITING:'Waiting to qualify', PAUSED:'Data paused',
    }[d.action] || 'Monitoring';
    $('guardAction').textContent = label;
    $('guardReason').textContent = !own ? `Buy a position or start the bot. Showing ${side} exit checks as a preview.` :
      !state.running ? `Bot is stopped. ${d.reason} No automatic exit orders will be sent.` : d.reason;
    $('positionSyncStatus').hidden=!state.positionStatus?.reconciling;
    $('positionSyncStatus').textContent=state.positionStatus?.reconciling?
      `POSITION RECONCILIATION · Recorded ${state.positionStatus.recordedCount} ${side}; exchange snapshot ${state.positionStatus.exchangeCount??'unavailable'}. ${state.positionStatus.reason} ${!state.running?'Bot stopped: automatic exits are OFF.':''}`:'';
    $('decisionDot').className = 'status-dot ' + (!own || !state.running ? '' : d.action === 'SELL' ? 'red' : d.action === 'HOLD' ? 'green' : 'amber');
    const elapsed = own ? d.elapsedMs || 0 : 0, total = d.requiredMs / 1000;
    $('qualifyTime').textContent = total === 0 ? 'OFF · no prerequisite' : `${(elapsed / 1000).toFixed(1)} / ${total.toFixed(1)}s`;
    $('qualifyLabel').textContent = total === 0 ? 'Prior spread prerequisite OFF' :
      own && d.state.armed ? 'Prior spread prerequisite met' : 'Regular exit: awaiting prior spread';
    $('qualifyProgress').max = total || 1; $('qualifyProgress').value = elapsed / 1000;
    const sellTotal = (d.sellRequiredMs ?? (side === 'UP' ? state.settings.rules.upSellSeconds : state.settings.rules.downSellSeconds) * 1000) / 1000 || 0;
    const sellElapsed = own ? (d.sellElapsedMs || 0) / 1000 : 0;
    $('sellWaitTime').textContent = `${Math.min(sellElapsed, sellTotal).toFixed(1)} / ${sellTotal.toFixed(1)}s${sellTotal === 0 ? ' · off' : ''}`;
    $('sellWaitProgress').max = sellTotal || 1;
    $('sellWaitProgress').value = Math.min(sellElapsed, sellTotal);
    const checks = d.checks?.length ? d.checks : preview.checks;
    const active = checks.filter(c=>c.enabled !== false);
    const allMet = active.length > 0 && active.every(c=>c.passed);
    $('checksCount').textContent = `${active.filter(c => c.passed).length} / ${active.length} sell checks${own?'':' · preview'}`;
    const blocked=!!own&&active.length>0&&d.requireQualification===true&&!d.state.armed&&d.action!=='SELL';
    $('qualificationBlocker').hidden=!blocked;
    if(blocked){
      const up=side==='UP',r=state.settings.rules;
      $('qualificationBlockerTitle').textContent=allMet?
        'All sell checks met; regular exit blocked':'Prior spread prerequisite not met';
      $('qualificationBlockerDetail').textContent=
        `${side} regular selling first requires spread ${up?'≥':'≤'} ${signed(up?r.upSpread:r.downSpread)} for ${total}s continuously after buying. That prerequisite is not currently qualified. `+
        'To let the selected SELL checks act without this earlier requirement, uncheck “Require spread qualification before selling” and click Apply UP & DOWN rules. Keep the SELL spread checkbox selected if you still want that sell comparison. '+
        'The separate sell wait still applies; independent exits are not blocked by this prerequisite. If running, applying this change can allow a sell on the next fresh evaluation.'+
        (!state.running?' The bot is stopped: removing the prerequisite does not start automatic trading.':'');
    }
    $('guardChecks').replaceChildren(...checks.map(c => {
      const li = document.createElement('li'); if (c.enabled === false) li.className = 'disabled-rule';
      const dot = document.createElement('span'); dot.className = 'check-dot' + (c.passed && c.enabled !== false ? ' passed' : '');
      dot.textContent = c.enabled === false ? '−' : c.passed ? '✓' : '·'; dot.setAttribute('aria-label', c.enabled === false ? 'Rule disabled' : c.passed ? 'Exit condition true' : 'Exit condition false');
      const body = document.createElement('div'); body.className = 'check-name'; body.textContent = c.name;
      const equation = document.createElement('span'); equation.className = 'check-equation';
      equation.textContent = c.enabled === false ? 'Unchecked: ignored' : `Sell if ${c.op} ${signed(c.threshold)}`; body.append(equation);
      const value = document.createElement('strong'); value.className = 'check-value' + (c.passed && c.enabled !== false ? ' negative' : '');
      value.textContent = signed(c.value); li.append(dot,body,value); return li;
    }));
    const p = side === 'UP' ? 'up' : 'down', rules = state.settings.rules;
    $('nowOnlyStatus').textContent = rules[p+'NowOnlyEnabled'] ?
      `Independent ${side} now-only exit ON: sell if now ${rules[p+'NowOnlyDirection']} ${signed(rules[p+'NowOnlyThreshold'])}. Bypasses qualification and sell wait; fresh data and running bot required.` :
      `Independent ${side} now-only exit is off.`;
    const c=own&&state.guard?.cashout?state.guard.cashout:
      TimedCashout.evaluate(rules,state.quote,state.feeds,side,
        state.market?(state.market.closeTime-state.serverTime)/1000:null,state.serverTime,state.running);
    $('cashoutStatus').textContent=`${side} timed cash-out · ${own?c.action:c.enabled?'PREVIEW · no position':'OFF'}\nButton ${Number.isFinite(c.ask)?c.ask+'%':'--'} · sell bid ${Number.isFinite(c.bid)?c.bid+'¢':'--'}`+
      `\n${own?c.reason:c.enabled?`Cash out this side if button ≥ ${c.threshold}% AND time left ≤ ${c.windowSeconds}s. No position to close.`:c.reason}`+
      (c.enabled?`\nAfter full cash-out: ${c.stopReentry?'block both UP/DOWN buys for this market':'normal re-entry settings apply'}.`:'');
    for(const dir of ['UP','DOWN']){
      const result=state.safety?.filters?.[dir]?.cashout;
      $(dir.toLowerCase()+'CashoutEntryStatus').textContent=disconnected?
        'Connection lost. Applied entry protection status unknown.':
        result?'Applied rule: '+result.reason:'Backend update required for the timed cash-out entry blocker.';
      const volume=state.safety?.filters?.[dir]?.volume;
      $(dir.toLowerCase()+'VolumeStatus').textContent=disconnected?
        'Connection lost. Contract-volume status unknown.':
        volume?'Applied rule: '+volume.reason:'Backend update required for contract-volume confirmation.';
    }
    $('volumeEntrySummary').textContent=disconnected?'Contract-volume confirmation: connection unknown.':
      'Kalshi contract-volume auto-entry: '+['UP','DOWN'].map(dir=>{
        const v=state.safety?.filters?.[dir]?.volume;
        return dir+' '+(!v?'backend update required':!v.enabled?'OFF':v.allowed?'PASS':'WAIT')+
          (v?.enabled&&Number.isFinite(v.percent)?` (${v.percent.toFixed(1)}%)`:'');
      }).join(' · ')+(state.settings.nowEntry?.enabled?'. Low/high-mode manual buys must also pass this filter.':'. Manual buys bypass this filter.');
    $('monitorNote').textContent = lowHigh.enabled?
      'LOW and HIGH are alternative SELL groups; checked sources inside each group combine with AND. Each group needs its own fresh sources and confirmation time. Independent protective exits remain active. Stop disables automatic buys and sells.':
      !state.feeds?.ready ? 'Stale or missing inputs reset qualification and block automatic actions.' :
      !own ? 'Preview only. Automatic exits monitor this copy’s open position while the bot is running.' :
      'Checked rules combine with AND. Enabled entry-protection, now-only, fixed-trailing, staircase and timed cash-out exits can each sell independently.';
    if(disconnected){
      $('guardAction').textContent='Connection lost';$('decisionDot').className='status-dot amber';
      $('guardReason').textContent='Browser disconnected. These are last received readings; backend status is unknown.';
    }
  }
  function chartFloor(){
    const now=state.serverTime,chart=state.nowChart?.ticker===state.market?.ticker?state.nowChart:null;
    const times=[...(chart?.points||[]).map(p=>p.t),...(chart?.sales||[]).flatMap(s=>[s.at,s.buy?.at]),
      state.openTrade?.ticker===state.market?.ticker?state.openTrade?.startedAt:null].filter(Number.isFinite);
    return Math.max(now-900000,Math.min(now,...times));
  }
  function renderNowChart(){
    const scope=`${sessionEpoch}:${state.session?.label}:${state.settings.mode}:${state.market?.ticker}`;
    if(scope!==chartScope){chartScope=scope;chartView={minutes:15,end:null};
      for(const k of ['inspectTime','inspectBuy','inspectSale'])delete $('nowChartPlot').dataset[k];}
    const view=ChartView.range(chartView,state.serverTime,chartFloor());
    chartMinutes=view.minutes;
    for(const minutes of [5,15])$('chart'+minutes+'m').setAttribute('aria-pressed',view.live&&chartMinutes===minutes?'true':'false');
    $('chartZoomIn').disabled=chartMinutes<=ChartView.MIN;
    $('chartZoomOut').disabled=chartMinutes>=ChartView.MAX;
    $('chartEarlier').disabled=!view.canEarlier;
    $('chartLater').disabled=!view.canLater;
    $('chartReset').disabled=view.live&&chartMinutes===15;
    $('chartZoomStatus').textContent=`${ChartView.duration(chartMinutes)} · ${time(view.start)}–${time(view.end)} · `+
      (view.live?'LIVE: follows new samples.':'REVIEW: window held; live protection overlays hidden. Trading is unchanged.');
    $('chartBuyCompatibility').hidden=state.features?.buyChartHistory===true;
    $('chartBuyCompatibility').textContent='Retaining BUY markers after a sale needs approved backend51 activation. Zoom and the open-position BUY marker work now; missing older buys are not reconstructed.';
    const own=state.openTrade?.ticker===state.market?.ticker?state.openTrade:null;
    const side=own?(own.side==='yes'?'UP':'DOWN'):selected;
    const t=own?state.guard?.trailing:null,p=side==='UP'?'up':'down';
    const r=NowEntry.exitRules(state.settings.rules,own?.nowEntryConfig||
      (!own&&state.settings.nowEntry?.enabled?state.settings.nowEntry:null));
    const points=state.nowChart?.ticker===state.market?.ticker?state.nowChart.points:[];
    const buys=ChartView.buys(state);
    const visible=points.filter(p=>p.t>=view.start&&p.t<=view.end);
    const age=visible.length?state.serverTime-visible.at(-1).t:null;
    const coverage=visible.length?Math.max(0,Math.floor((visible.at(-1).t-visible[0].t)/1000)):0;
    const recorded=coverage<60?coverage+'s':Math.floor(coverage/60)+'m '+coverage%60+'s';
    $('chartStatus').textContent=disconnected?'DISCONNECTED · chart frozen; backend status unknown.':
      !view.live?`Reviewing ${recorded} of recorded samples in this window. Gaps are not filled; no earlier prices are invented.`:
      !state.feeds?.ready?'PAUSED · fresh data required; gaps are not filled.':
      age==null?'Collecting observed current-market samples…':
      `${state.feeds?.method?.includes('SYNTHETIC')?'SYNTHETIC QA':'Sampled current market'} · data spans ${recorded} within ${ChartView.duration(chartMinutes)} · last sample ${(age/1000).toFixed(1)}s ago. Gaps = missing or stale samples, not continuous history. Chart history samples at about 1s or slower; live price cards update separately between samples.`;
    $('legendBest').hidden=!view.live||!own||!Number.isFinite(t?.best);
    $('legendExit').hidden=!view.live||!own||!Number.isFinite(t?.level);
    $('legendEntry').hidden=!buys.some(b=>b.at<=view.end);
    $('legendEntry').textContent='BUY line / entry triangles';
    const barrierBuyText=BarrierBuyValue.live(own,state.guard?.staircase);
    $('chartBarrierBuyStatus').textContent=disconnected?
      'Connection lost. Saved BUY and barrier observations only; current protection state unknown.':
      barrierBuyText?(!state.running?'STOPPED · monitor only. ':
        state.guard?.staircase?.action==='PAUSED'?'PAUSED · observations only. ':'')+barrierBuyText:'';
    $('chartBarrierBuyStatus').hidden=!$('chartBarrierBuyStatus').textContent;
    const sales=state.nowChart?.sales||[],rebuy=state.nowChart?.rebuy||{};
    const sold=sales.filter(s=>s.completed&&s.at<=view.end).at(-1);
    $('legendSold').hidden=!Number.isFinite(sold?.now)&&!sales.some(s=>Number.isFinite(s.now)&&s.at>=view.start&&s.at<=view.end);
    $('legendRebuy').hidden=!view.live||!!own||!Object.values(rebuy).some(r=>r.enabled&&Number.isFinite(r.level));
    $('soldPointStatus').textContent=!supportsRebuy()?
      'Sold-point markers and rebuy controls need backend26. Existing trading is unchanged.':
      (sold?(Number.isFinite(sold.now)?`Sold line: ${signed(sold.now)} · latest completed ${sold.side==='yes'?'UP':'DOWN'} sale at ${time(sold.at)}. Moves after each completed sale. `:
      'Latest completed sale has no fresh recorded Now; Sold line unavailable. '):
      'No completed sell recorded in this mode/current market. Historical sell values are not guessed. ')+
      (own?'Sold points are observations at fill confirmation, not contract fill prices.':
      ['UP','DOWN'].map(side=>rebuy[side]?.reason||'').filter(Boolean).join(' '));
    NowChart.draw($('nowChartPlot'),$('chartReadout'),points,
      own,chartMinutes,state.serverTime,t,own?state.guard?.staircase:null,own?state.guard?.entryProtection:null,sales,own?{}:rebuy,buys,view,LineTrailUI.overlay(state));
    $('trailStatus').textContent=t?`${side} fixed trail · ${t.action.replace('_',' ')}`:
      own?`${side} fixed trail · refreshing`:`${side} fixed trail ${r[p+'TrailEnabled']?'enabled · no position':'off'}`;
    $('trailDetail').textContent=t?
      `Best ${signed(t.best)} · Now ${signed(state.feeds?.nowDiff)} · Exit ${signed(t.level)}\n${t.reason}`:
      own?'Waiting for a fresh position evaluation. Best observed Now is retained.':
      `${r[p+'TrailFromEntryEnabled']?`Activate after $${r[p+'TrailFromEntryMove']} favorable from entry`:`Activate ${side==='UP'?'≥':'≤'} ${signed(r[p+'TrailActivation'])}`}; pullback ${r[p+'TrailPercentEnabled']?r[p+'TrailPercent']+'% of absolute entry Now':'$'+r[p+'TrailPullback']}; wait ${r[p+'TrailSeconds']}s. `+
      (r[p+'TrailWarmupEnabled']?`Opening warm-up: ${r[p+'TrailWarmupSeconds']}s from market open, trailing only. `:'Opening warm-up off. ')+
      'Apply rules to save.';
    $('editTrail').textContent=`Edit ${side} trailing exit`;
    if(disconnected)$('trailStatus').textContent='Connection lost · exit state unknown';
    const stair=own?state.guard?.staircase:null;
    $('legendStair').hidden=!view.live||!own||!(Number.isFinite(stair?.level)||points.some(p=>p.position===own.startedAt&&Number.isFinite(p.stair)));
    $('stairStatus').textContent=disconnected?'Connection lost · staircase state unknown':
      stair?`${side} staircase · ${stair.action.replace('_',' ')}`:
      `${side} staircase ${r[p+'StairEnabled']?'enabled · no position':'off'}`;
    $('stairDetail').textContent=stair?
      `Entry Now ${signed(stair.entryNow)} · Best ${signed(stair.best)} · Step $${stair.step} · Barrier ${signed(stair.level)}\n${stair.reason}`:
      `Step ${r[p+'StairPercentEnabled']?r[p+'StairPercent']+'% of absolute entry Now':'$'+r[p+'StairStep']} from entry Now; recovery ${r[p+'StairSeconds']}s. `+
      (r[p+'StairWarmupEnabled']?`Warm-up ${r[p+'StairWarmupSeconds']}s from market open. `:'Opening warm-up off. ')+
      'Independent of the fixed-pullback trail. Apply rules to save.';
    $('editStair').textContent=`Edit ${side} staircase exit`;
    const entry=own?state.guard?.entryProtection:null;
    $('legendEntryStop').hidden=!view.live||!own||!Number.isFinite(entry?.level);
    $('entryProtectionStatus').textContent=disconnected?'Connection lost · entry protection state unknown':
      entry?`${side} entry protection · ${entry.action}`:
      `${side} entry protection ${r[p+'EntryProtectionEnabled']?'enabled · no position':'off'}`;
    $('entryProtectionDetail').textContent=entry?
      `Entry Now ${signed(entry.entryNow)} · Stop ${signed(entry.level)} · Buffer $${entry.buffer} · Now ${signed(state.feeds?.nowDiff)}\n${entry.reason}`:
      `Automatic first-buy anchor; ${side==='UP'?'sell strictly below entry minus':'sell strictly above entry plus'} $${r[p+'EntryProtectionBuffer']??0}. `+
      'Independent of trailing activation, staircase steps and their warm-ups. No extra wait; fresh data and a running bot required. Apply to save.';
    $('editEntryProtection').textContent=`Edit ${side} entry protection`;
  }
  function renderResults() {
    const r = state.results;
    if (!r) return;
    paintValue('resNet', r.net); $('resRate').textContent = r.winRate == null ? '--' : `${r.winRate}%`;
    $('resWins').textContent = r.wins; $('resLosses').textContent = r.losses;
    $('resMode').textContent = '· ' + r.mode.toUpperCase();
    $('resSub').textContent = r.trades ? `${r.trades} closed · fees ${usd(r.fees)} · today ${signed(r.today)}` :
      'No closed trades in this copy. Results appear after an exit or settlement.';
    $('resList').replaceChildren(...r.rows.slice(0,15).map(row => {
      const li = document.createElement('li'), body = document.createElement('div');
      const title = document.createElement('div'); title.className = 'result-title';
      title.textContent = `${row.how.toUpperCase()} · ${row.side === 'yes' ? 'UP' : 'DOWN'} ${row.count} · ${Math.round(row.entry * 100)}¢ → ${Math.round(row.exit * 100)}¢`;
      const meta = document.createElement('div'); meta.className = 'result-meta';
      meta.textContent = `${time(row.at)} · ${row.ticker}`;
      body.append(title,meta);
      if (row.entryProfile) {
        const profile=document.createElement('div');profile.className='result-meta';
        const changed=row.settingsChangedDuringTrade === true;
        profile.textContent='Setup at entry: '+row.entryProfile.name+
          (row.entryProfile.modified?' · modified at entry':'')+(changed?' · edited during trade':'');
        body.append(profile);
      }
      if(row.entryNowChop||row.entryVolatility){
        const v=row.entryVolatility||{},c=row.entryNowChop;
        const detail=document.createElement('div');detail.className='result-meta';
        const left=Object.hasOwn(v,'timeLeftSeconds')?v.timeLeftSeconds:c?.timeLeftSeconds;
        detail.textContent='At entry: '+[
          c&&`Now chop ${observationLabel(c.label)}${c.score==null?'':` (${c.score}/100)`}`,
          v.atr&&`ATR ${observationLabel(v.atr.label)}`,
          Number.isFinite(left)?`${observationTime(left)} left`:
            Object.hasOwn(v,'timeLeftSeconds')?'Time left unavailable':null,
        ].filter(Boolean).join(' · ');
        body.append(detail);
      }
      const pnl = document.createElement('strong'); pnl.className = row.pnl >= 0 ? 'positive' : 'negative'; pnl.textContent = signed(row.pnl);
      li.append(body,pnl); return li;
    }));
  }
  const observationFields={chop:'observeChop',atr:'observeAtr',timeLeft:'observeTimeLeft'};
  const readObservationDraft=()=>Object.fromEntries(Object.entries(observationFields)
    .map(([key,id])=>[key,$(id).checked]));
  const sameObservations=(a,b)=>a&&b&&Object.keys(observationFields).every(k=>a[k]===b[k]);
  const observationLabel=label=>({QUIET_TO_ACTIVE:'Quiet to active',UNAVAILABLE:'Unavailable',
    NORMAL:'Normal',QUIET:'Quiet',CLEAN:'Clean',MIXED:'Mixed',CHOPPY:'Choppy'})[label]||'Unavailable';
  const observationTime=seconds=>`${Math.floor(seconds/60)}:${String(seconds%60).padStart(2,'0')}`;
  let observationBase=null,observationScope='';
  function fillObservations(applied){
    observationBase=applied||null;
    for(const [key,id] of Object.entries(observationFields))$(id).checked=applied?.[key]===true;
  }
  function renderObservations(){
    const mode=state?.settings?.mode;
    const readings=state?.features?.volatilityObservations===true?state.volatilityObservations:null;
    const supported=mode==='paper'||mode==='live',applied=supported?readings?.switches:null;
    const scope=`${sessionEpoch}:${state?.session?.label||''}:${mode}:${!!applied}`;
    if(scope!==observationScope){
      observationScope=scope;fillObservations(applied);feedback('observationsFeedback','');
    }else if(sameObservations(readObservationDraft(),observationBase)||
      sameObservations(readObservationDraft(),applied))fillObservations(applied);
    const dirty=!sameObservations(readObservationDraft(),applied);
    const stale=!sameObservations(observationBase,applied);
    const locked=!applied||pending||disconnected;
    $('observationFields').disabled=locked;
    $('applyObservations').disabled=locked||!dirty||stale;
    $('reloadObservations').disabled=locked||(!dirty&&!stale);
    $('observationCompatibility').textContent=disconnected?'Connection lost. Observation controls are locked.':
      !readings?'A backend update and approved restart are needed to unlock these options.':
      !supported?'Available in Live and Paper, not Demo.':
      `${mode==='live'?'Live':'Paper'} options. Saved separately for this mode and bot session.`;
    const badge=$('categoryVolatilityStatus');
    const count=applied?Object.values(applied).filter(Boolean).length:0;
    if(badge)badge.textContent=disconnected?'Disconnected':!readings?'Backend update required':
      !supported?'Live & Paper only':`${count} of 3 on`;
    const c=readings?.chop,a=readings?.atr,left=readings?.timeLeftSeconds;
    const index=c?.sourceKind==='authenticated_index'?'Kalshi authenticated index':
      c?.sourceKind==='public_chart'?'Kalshi public chart':'Kalshi reference';
    $('observeChopReading').textContent=locked&&!pending?'Unavailable':!c?'Off':
      `${observationLabel(c.label)}${c.score==null?'':` · ${c.score}/100`} · ${index}`+
      ` · ${c.coverageSeconds}s coverage`+(c.reason?` · ${c.reason}`:
        ` · ${c.crossings} crossings${c.efficiency==null?'':` · ${Math.round(c.efficiency*100)}% direct`}`);
    $('observeAtrReading').textContent=locked&&!pending?'Unavailable':!a?'Off':
      `${observationLabel(a.label)} · ${a.reason||`ATR ${usd(a.atrUsd)} · recent baseline ${usd(a.baselineUsd)}`}`;
    $('observeTimeLeftReading').textContent=locked&&!pending?'Unavailable':!applied?.timeLeft?'Off':
      Number.isFinite(left)?`${observationTime(left)} remaining`:'Unavailable · no current market countdown';
    if(applied&&stale)feedback('observationsFeedback','Options changed in another view. Reload before applying.','error');
  }
  for(const id of Object.values(observationFields))$(id).onchange=()=>{
    feedback('observationsFeedback','');renderObservations();
  };
  $('reloadObservations').onclick=()=>{
    fillObservations(state?.volatilityObservations?.switches);
    feedback('observationsFeedback','Applied options reloaded.');renderObservations();
  };
  $('applyObservations').onclick=async()=>{
    if($('applyObservations').disabled)return;
    try{
      const body={mode:state.settings.mode,options:readObservationDraft(),expected:observationBase};
      await perform(()=>api('/api/volatility-observations',body));
      feedback('observationsFeedback','Observation options applied. Trading rules unchanged.','ok');
    }catch(err){feedback('observationsFeedback',err.message,'error');}
  };
  const chopBuyFields={up:'skipChopUp',down:'skipChopDown',requireTwoCrossings:'skipChopTwoCrossings'};
  const supportsChopCrossings=()=>state?.features?.chopBuyCrossings===true;
  const readChopBuy=()=>Object.fromEntries(Object.entries(chopBuyFields)
    .filter(([k])=>k!=='requireTwoCrossings'||supportsChopCrossings()).map(([k,id])=>[k,$(id).checked]));
  const sameChopBuy=(a,b)=>a&&b&&Object.keys(chopBuyFields).every(k=>a[k]===b[k]);
  let chopBuyBase=null,chopBuyScope='';
  function fillChopBuy(applied){
    chopBuyBase=applied||null;
    for(const [key,id] of Object.entries(chopBuyFields))$(id).checked=applied?.[key]===true;
  }
  function renderChopBuy(){
    const mode=state?.settings?.mode, supported=mode==='live'||mode==='paper';
    const data=state?.features?.chopBuyFilter===true?state.chopBuyFilter:null;
    const applied=supported?data?.switches:null;
    const strictSupported=supportsChopCrossings();
    const scope=`${sessionEpoch}:${state?.session?.label||''}:${mode}:${!!applied}:${strictSupported}`;
    if(scope!==chopBuyScope){
      chopBuyScope=scope;fillChopBuy(applied);feedback('chopBuyFeedback','');
    }else if(sameChopBuy(readChopBuy(),chopBuyBase)||sameChopBuy(readChopBuy(),applied))fillChopBuy(applied);
    const dirty=!sameChopBuy(readChopBuy(),applied), stale=!sameChopBuy(chopBuyBase,applied);
    const unsafe=state?.running||state?.armedLive||['BUYING','SELLING','MANUAL'].includes(state?.phase);
    const locked=!applied||pending||disconnected||unsafe;
    $('chopBuyFields').disabled=locked;
    $('skipChopTwoCrossings').disabled=locked||!strictSupported;
    $('applyChopBuy').disabled=locked||!dirty||stale;
    $('reloadChopBuy').disabled=!applied||pending||disconnected||(!dirty&&!stale);
    $('chopBuyCompatibility').textContent=disconnected?'Connection lost. Filter controls are locked.':
      !data?'An approved backend restart is needed to unlock this filter.':
      !supported?'Available in Live and Paper, not Demo.':
      unsafe?'Stop and disarm before changing the buy filter.':
      `${mode==='live'?'Live':'Paper'} filter. Saved for this mode and bot session, separate from profiles.`;
    $('skipChopCrossingNote').textContent=!strictSupported?'The crossing requirement needs an approved backend restart.':
      applied?.requireTwoCrossings?'Applied: Choppy plus 2 or more target crossings for enabled sides.':
      'Applied: score only. Check this to require 2 or more target crossings for enabled sides.';
    for(const key of ['up','down']){
      const id=chopBuyFields[key];
      const d=data?.sides?.[key.toUpperCase()];
      const count=Number.isInteger(d?.crossings)?` · ${d.crossings} target crossing${d.crossings===1?'':'s'}`:'';
      const score=d?.score==null?'':` (${d.score}/100)`;
      $(id+'Reading').textContent=disconnected||!applied?'Unavailable':
        !d?.enabled?'Off':!d.allowed?`Choppy${score}${count} · Would skip a qualifying automatic buy`:
        d.label==='UNAVAILABLE'?'Kalshi Now unavailable · No change to existing buy rules':
        d.label==='CHOPPY'&&d.minCrossings>0?`Choppy${score}${count} · No block (needs ${d.minCrossings} crossings)`:
        `${observationLabel(d.label)}${score}${count} · No filter block`;
    }
    if(applied&&stale)feedback('chopBuyFeedback','Filter changed in another view. Reload before applying.','error');
  }
  for(const id of Object.values(chopBuyFields))$(id).onchange=()=>{
    feedback('chopBuyFeedback','');renderChopBuy();
  };
  $('reloadChopBuy').onclick=()=>{
    fillChopBuy(state?.chopBuyFilter?.switches);
    feedback('chopBuyFeedback','Applied filter reloaded.');renderChopBuy();
  };
  $('applyChopBuy').onclick=async()=>{
    if($('applyChopBuy').disabled)return;
    try{
      const body={mode:state.settings.mode,options:readChopBuy(),expected:chopBuyBase};
      await perform(()=>api('/api/chop-buy-filter',body));
      feedback('chopBuyFeedback','Buy filter applied. No automation started.','ok');
    }catch(err){feedback('chopBuyFeedback',err.message,'error');}
  };
  function renderCoins(unavailable=false){
    const supported=state?.features?.coinWorkspaces===true&&!unavailable;
    $('coinPanel').hidden=!state&&!unavailable;
    $('activeCoinPair').textContent=`${viewedCoin} / USD`;
    $('marketCoinLabel').textContent=`KALSHI · 15-MINUTE ${viewedCoin}`;
    $('coinbaseTitle').textContent=`Coinbase ${viewedCoin}`;
    $('coinbasePair').textContent=`${viewedCoin} / USD · last received trade`;
    $('candleChartTitle').textContent=`${viewedCoin} candle chart`;
    $('candleChartSource').textContent=`Coinbase ${viewedCoin}/USD candles · 1 minute · not Kalshi Now`;
    for(const button of coinButtons){
      const asset=button.dataset.coin,info=state?.coinWorkspaces?.find(v=>v.asset===asset);
      button.setAttribute('aria-pressed',String(asset===viewedCoin));
      button.disabled=pending||(!supported&&asset!=='BTC');
      button.lastElementChild.textContent=info&&supported&&!disconnected?
        `${info.mode.toUpperCase()} · ${info.running?'Running':info.armed?'Armed':info.position?'Holding':info.settling?'Settling':'Stopped'}`:
        ({BTC:'Bitcoin',ETH:'Ethereum',SOL:'Solana'})[asset];
    }
    const message=unavailable?`${invalidCoin?'This coin':viewedCoin} is not available. Return to BTC. No settings or orders changed.`:
      !supported?'ETH and SOL require the coin-workspaces backend update. Your BTC setup is still available.':
      disconnected?'Connection lost. Bot status is unknown.':
      'Switching changes the view only. Any running bot keeps running. Save changes before switching.';
    if($('coinStatus').textContent!==message)$('coinStatus').textContent=message;
    $('coinReview').hidden=!state||unavailable||state.coinReviewed!==false;
    $('coinReviewText').textContent=`${viewedCoin} starts in Paper with its own settings. Review and save your entry, exit and risk rules before enabling new entries. Optional exits are off in the starter setup.`;
    $('confirmCoinSetup').disabled=pending||disconnected;
  }
  for(const button of coinButtons)button.onclick=()=>{
    if(!pending&&(invalidCoin||button.dataset.coin!==viewedCoin)&&!button.disabled)location.assign(coinUrl(button.dataset.coin));
  };
  $('confirmCoinSetup').onclick=async()=>{
    if(pending||disconnected||!state||state.coinReviewed!==false)return;
    if(!await confirmAction(`Confirm ${viewedCoin} settings review?`,
      'Confirm that you reviewed the saved rules for this coin, including how it exits a trade. This unlocks controls but does not start or arm the bot.','Confirm review'))return;
    try{await perform(()=>api('/api/coin-review',{confirm:`REVIEW ${viewedCoin}`}),`${viewedCoin} settings reviewed. Automation is still off.`);}catch{}
  };
  function render() {
    if (!state) return;
    buySound.observe(state,`${sessionEpoch}:${state.session?.label||''}:${state.settings?.mode||''}`,!document.hidden);
    recoveryRequired=false;
    $('sessionReconnectGate').hidden=true;
    $('main').hidden=false;
    renderContractCounter();
    renderSellVolume();
    renderCoins();
    renderSession();
    state=PriceRefresh.merge(state,latestPrices);
    renderProfiles();
    nowEntryUI.render(state,{pending,disconnected});
    buyConditionsUI.render(state,{pending,disconnected});
    nowExitUI.render(state,{pending,disconnected});
    safetyUI.render(state,disconnected,pending);
    followingUI.render(state,disconnected,pending);
    candleUI.render(state,disconnected,pending);
    lineUI.render(state,disconnected,pending);
    globalThis.CompactNavigation?.render(state,disconnected,pending);
    renderObservations();
    renderChopBuy();
    entryWindowUI.render(state,{pending,disconnected});
    for(const p of ['up','down'])for(const mode of ['trail','stair0','stair1'])
      $('legacy-'+p+'-compare-'+mode).disabled=pending||disconnected||state.running||state.settings.mode!=='paper';
    if($('settingsDialog').open)refreshBuySaveState();
    refreshRuleSectionStates();
    renderNowChart();
    for(const side of ['up','down']){
      const supported=!!state.features?.entryRelativeTrailing,relative=$(side+'TrailFromEntryEnabled').checked;
      $(side+'TrailFromEntryEnabled').disabled=pending||disconnected||!supported;
      $(side+'TrailFromEntryMove').disabled=pending||disconnected||!supported||!relative;
      $(side+'TrailActivation').disabled=supported&&relative;
      $(side+'TrailActivation').title=supported&&relative?'Not used: entry-relative activation is selected.':'Absolute signed Now activation.';
    }
    $('downTrailUseMinus').disabled=$('downTrailActivation').disabled;
    refreshPercentageControls();
    $('upgradeStatus').hidden=!!state.features?.ownedPositionGuard;
    $('upgradeStatus').textContent='Reliability update prepared, not active: backend29 restart approval is still required. New entry-relative trailing and protection-required controls are disabled until activation. Existing trading rules remain unchanged.';
    $('openSettings').disabled = false;
    const s = state.settings, own = state.openTrade?.ticker === state.market?.ticker ? state.openTrade : null;
    $('modeChip').textContent = s.mode.toUpperCase(); $('modeChip').className = 'chip ' + s.mode;
    $('tickerName').textContent = state.market?.ticker || `No open ${viewedCoin} market`;
    $('strikePrice').textContent = quoteUsd(state.market?.strike); renderClock(); renderFeeds(); renderGuard(); renderResults();
    const q = state.quote || {};
    $('upAsk').textContent = q.upAsk ?? '--'; $('downAsk').textContent = q.downAsk ?? '--';
    $('upBid').textContent = q.upBid ?? '--'; $('downBid').textContent = q.downBid ?? '--';
    $('heldUp').hidden = own?.side !== 'yes'; $('heldDown').hidden = own?.side !== 'no';
    $('posVal').textContent = own ? `${own.count} ${own.side === 'yes' ? 'UP' : 'DOWN'}` :
      state.position ? `${Math.abs(state.position)} external` : '0';
    $('balLabel').textContent = s.mode === 'paper' ? 'PAPER CASH' : 'CASH BALANCE';
    $('balVal').textContent = s.mode !== 'paper' && !state.hasKey ? 'No key' : usd(state.balance);
    paintValue('pnlVal', state.results?.net);
    $('botBadge').textContent = state.running ? 'RUNNING' : 'STOPPED';
    const entryText = s.nowEntry?.enabled ? ['UP','DOWN'].map(side=>{
      const signal=state.nowEntrySignals?.[side]||NowEntry.evaluate(s.nowEntry,state.feeds,side,state.kalshiIndex);
      return signal.enabled?signal.description:side+': Now buying disabled';
    }).join('\n') :
      s.entryMethod === 'spread' ? ['UP','DOWN'].map(side=>{
      const d = state.entrySignals?.[side], r = s.rules, up = side === 'UP', op = up ? '≥' : '≤';
      const checks = SpreadGuard.entryChecks(r,state.feeds,side).filter(c=>c.enabled);
      return checks.length ? `Buy ${side}: ${checks.map(c=>`${c.name} ${c.op} ${signed(c.threshold)}`).join(', ')} for ${up?r.upSeconds:r.downSeconds}s` +
        (d ? ` (${d.checks.filter(c=>c.enabled && c.passed).length}/${checks.length}; ${(Math.min(d.elapsedMs,d.requiredMs)/1000).toFixed(1)}s)` : '') :
        `Buy ${side}: disabled, no checked spread entry rules`;
    }).join('\n') : `Buy UP: UP ask > ${SignedBuy.priceThreshold(s,'UP')}¢ AND Now ≥ ${signed(s.upBuyNow)}.\nBuy DOWN: DOWN ask > ${SignedBuy.priceThreshold(s,'DOWN')}¢ AND Now ≤ ${signed(s.downBuyNow)}.`;
    $('entrySummary').textContent = `Automatic buying: ${s.nowEntry?.enabled?
      (state.features?.nowEntryConditions?'ONLY checked low/high conditions (also required for manual buys)':'legacy Now-only levels; expanded checkbox/manual-buy enforcement pending activation'):
      s.entryMethod === 'spread' ? 'spread + target signal' : 'separate UP / DOWN contract-price triggers'}.\n${entryText}`;
    $('priceBuyStatus').hidden = s.nowEntry?.enabled || s.entryMethod === 'spread';
    $('priceBuyStatus').textContent = !state.feeds?.ready ? 'Automatic buy checks paused: fresh data required.' :
      `Current Now: ${signed(state.feeds.nowDiff)}\n` + ['UP','DOWN'].map(side => {
        const d = SignedBuy.evaluate(s,q,state.feeds,side);
        return `${side}: price ${d.pricePassed?'PASS':'WAIT'} · Now ${d.nowPassed?'PASS':'WAIT'}`;
      }).join('\n');
    const eligibility = state.entryEligibility;
    $('entryPolicy').textContent = eligibility ? `${eligibility.entries} / ${eligibility.max} entries this market · ` +
      (s.reentryEnabled ? `Re-entry ON · ${s.reentryCooldown}s cooldown. ` : 'Re-entry OFF. ') + eligibility.reason : '';
    const phases = {
      IDLE:['Stopped','Prices are live. No automatic orders.'],
      STARTING:['Starting','Loading current market and checking positions.'],
      NO_MARKET:['No session',`Waiting for an open ${viewedCoin} market.`],
      MONITOR_ENTRY:['Watching entry', state.feeds?.ready ? s.nowEntry?.enabled ?
        ((state.nowEntrySignals?.UP||NowEntry.evaluate(s.nowEntry,state.feeds,'UP',state.kalshiIndex)).ambiguous?'Both directions qualify. No buy until exactly one qualifies.':'Watching checked low/high entry conditions; contract cents are not entry triggers.') : s.entryMethod === 'spread' ?
        (Object.values(state.entrySignals || {}).filter(d=>d.action==='READY').length>1 ? 'Both sides qualify. No trade: adjust overlapping rules.' : 'Waiting for one confirmed spread signal within your market trade limit.') :
        'Waiting for contract price AND the direction’s signed Now buy threshold, within your market trade limit.' : 'Entry paused until price feeds and target are ready.'],
      BUYING:['Buying','Sending order and confirming the fill.'],
      MONITOR_EXIT:['Monitoring exit','Your spread, target and now rules control the exit.'],
      SELLING:['Closing position','Confirming this copy’s position has closed.'],
      WAIT_NEXT:[eligibility?.remainingMs > 0 && eligibility?.entries < eligibility?.max ? 'Re-entry cooldown' :
        eligibility?.allowed && eligibility.entries > 0 ? 'Re-entry ready' : 'Waiting for next market',
        eligibility?.allowed && eligibility.entries === 0 ?
          'Entry attempt did not complete. Waiting for next market; stop/start to retry after reviewing activity.' :
          eligibility?.reason || 'Waiting for the next session.'],
      MANUAL:['Manual order','Processing your order.'],
    };
    const phase = phases[state.phase] || [state.phase,''];
    $('phase').textContent = phase[0]; $('phaseDesc').textContent = phase[1];
    $('runBtn').textContent = viewedCoin==='BTC'?(state.running?'Stop this bot’s automation':`Start ${s.mode} bot`):
      (state.running?`Stop ${viewedCoin} automation`:`Start ${viewedCoin} ${s.mode} bot`);
    $('runBtn').classList.toggle('stop', state.running); $('runBtn').disabled = pending || disconnected||
      (!state.running&&(!state.features?.nowEntryDirection||state.coinReviewed===false));
    for (const [id, side] of [['buyUp','yes'],['buyDown','no']]) {
      const held = own?.side === side;
      const safetyBlocked=state.safety&&(!state.safety.allowed||
        !state.safety.filters?.[side==='yes'?'UP':'DOWN']?.allowed);
      $(id).textContent = `${held ? 'Sell' : 'Buy'} ${side === 'yes' ? 'UP' : 'DOWN'}`;
      $(id).disabled = pending || disconnected || state.running || !state.market || (!held && (state.coinReviewed===false||!state.features?.nowEntryDirection||!state.feeds?.ready || !eligibility?.allowed||safetyBlocked));
      $(id).title=!held&&safetyBlocked?'Safety Controls block this new buy. Review applied checks below.':'';
    }
    const log = state.log || [], sig = log.length + ':' + (log.at(-1)?.t || '');
    if ($('log').dataset.sig !== sig) {
      $('log').dataset.sig = sig;
      $('log').replaceChildren(...log.slice(-12).reverse().map(row => {
        const li = document.createElement('li'), tm = document.createElement('time'), text = document.createElement('span');
        tm.textContent = time(row.t); text.textContent = row.msg; text.className = row.kind;
        li.append(tm,text); return li;
      }));
      if (!log.length) { const li = document.createElement('li'); li.className = 'empty'; li.textContent = 'No activity yet. Start in Paper to test your rules.'; $('log').append(li); }
    }
    $('keyStatus').textContent = state.hasKey ? `Key ${state.keyIdHint} saved for ${state.keyEnv}.` : 'No key saved. Demo and Live require a verified key.';
    $('armArea').hidden = s.mode === 'paper';
    $('armStatus').textContent = state.armedLive ? `${s.mode.toUpperCase()} trading is armed for this runtime.` : 'Trading is not armed.';
    $('armTrading').disabled = state.coinReviewed===false || state.running || !state.hasKey || state.keyEnv !== s.mode || state.armedLive;
    $('armTrading').textContent = `Arm ${viewedCoin==='BTC'?'':viewedCoin+' '}${s.mode} trading`;
    $('lastUpdate').textContent = `Live server · ${state.appVersion||'version unknown'} · updated ${time(state.serverTime)}`;
  }
  function refreshPercentageControls(){
    for(const p of ['up','down'])for(const kind of ['Trail','Stair']){
      const mode=$(p+kind+'PercentEnabled'),supported=state?.features?.percentageExitDistance===true;
      mode.disabled=pending||disconnected||!supported;
      mode.title=supported?'Optional percentage of absolute first-fill Coinbase Now.':'NOT ACTIVE: approved backend restart required. Existing dollar settings remain editable.';
      $(p+kind+'Percent').disabled=mode.disabled||!mode.checked;
      $(p+kind+(kind==='Trail'?'Pullback':'Step')).disabled=mode.checked;
      if(kind==='Stair')$(p+'BarrierBuyPreview').textContent=BarrierBuyValue.preview(
        p.toUpperCase(),state?.openTrade?.ticker===state?.market?.ticker?state.openTrade:null,
        mode.checked,Number($(p+kind+'Percent').value));
    }
  }
  for(const p of ['up','down'])for(const kind of ['Trail','Stair'])
    $(p+kind+'PercentEnabled').addEventListener('input',refreshPercentageControls);
  for(const p of ['up','down'])$(p+'StairPercent').addEventListener('input',refreshPercentageControls);
  function fillRules(rules) { rules = SpreadGuard.migrateRules(rules); for (const key of KEYS) { if ($(key).type === 'checkbox') $(key).checked = rules[key] ?? SpreadGuard.DEFAULT_RULES[key]; else $(key).value = rules[key] ?? SpreadGuard.DEFAULT_RULES[key]; } refreshRuleSectionStates();refreshPercentageControls(); }
  function readRules() {
    const rules=Object.fromEntries(KEYS.map(k => [k,$(k).type === 'checkbox' ? $(k).checked : $(k).value]));
    if(!state?.features?.entryRelativeTrailing&&['up','down'].some(p=>
      rules[p+'TrailFromEntryEnabled']||Number(rules[p+'TrailFromEntryMove'])!==10))
      throw new Error('Entry-relative trailing needs backend29 activation. Existing rules can still be edited.');
    rules.downTrailActivation=SignedDownActivation.read(rules.downTrailActivation);
    const validated=SpreadGuard.validateRules(rules);
    if(!state?.sellContractVolume){
      if(SELL_VOLUME_KEYS.some(key=>validated[key]!==ContractVolume.EXIT_DEFAULTS[key]))
        throw Error('Contract-volume exits need backend activation.');
      for(const key of SELL_VOLUME_KEYS)delete validated[key];
    }
    if(!state?.features?.percentageExitDistance){
      for(const p of ['up','down'])for(const kind of ['Trail','Stair']){
        if(validated[p+kind+'PercentEnabled'])throw Error('Percentage exits need backend activation. Dollar settings remain available.');
        delete validated[p+kind+'PercentEnabled'];delete validated[p+kind+'Percent'];
      }
    }
    return validated;
  }
  $('downTrailUseMinus').onclick=()=>{
    try{
      const input=$('downTrailActivation');
      input.value=SignedDownActivation.makeNegative(input.value);
      input.dispatchEvent(new Event('input',{bubbles:true}));
      feedback('rulesFeedback',`DOWN activation draft set to ${input.value}. Apply UP and DOWN rules to save.`);
      input.focus({preventScroll:true});
    }catch(err){feedback('rulesFeedback',err.message,'error');}
  };
  for(const p of ['up','down']){
    const box=document.createElement('fieldset'),legend=document.createElement('legend'),note=document.createElement('p');
    box.className='trail-settings';legend.textContent=p.toUpperCase()+' Paper comparison drafts';
    note.className='micro-note';note.textContent='Test one Now-following method. Draft only: saves no profile, starts no bot and places no order. Apply UP and DOWN rules to save. Entries, distances, percentage choices and independent exits are unchanged; other exits can sell sooner. Shorter staircase confirmation reacts sooner but may exit on temporary breaches. LOW/HIGH mode uses its own captured plan; use its separate comparison buttons when that mode is ON.';
    box.append(legend,note);
    for(const [mode,label]of [['trail','Trailing only'],['stair0','Staircase only · 0s'],['stair1','Staircase only · 1s']]){
      const button=document.createElement('button');button.type='button';button.className='text-button';
      button.id='legacy-'+p+'-compare-'+mode;button.dataset.testid=button.id;button.textContent='Paper draft: '+label;
      button.disabled=true;
      button.onclick=()=>{
        if(!state||state.running||state.settings.mode!=='paper'||pending||disconnected)return;
        $(p+'TrailEnabled').checked=mode==='trail';$(p+'StairEnabled').checked=mode!=='trail';
        if(mode!=='trail')$(p+'StairSeconds').value=mode==='stair0'?0:1;
        refreshRuleSectionStates();refreshPercentageControls();
        feedback('rulesFeedback',p.toUpperCase()+' Paper comparison draft only. Apply UP and DOWN rules to save; independent exits remain unchanged.');
      };
      box.append(button);
    }
    const target=$(p+'StairEnabled').closest('fieldset');target.before(box);
  }
  function selectSide(side) {
    $('legacyRulesDisclosure').open=true;
    selected = side;
    $('tabUp').setAttribute('aria-selected', side === 'UP'); $('tabDown').setAttribute('aria-selected', side === 'DOWN');
    $('upRules').hidden = side !== 'UP'; $('downRules').hidden = side !== 'DOWN';
    if (state) { renderGuard();renderNowChart(); }
  }
  $('tabUp').onclick = () => selectSide('UP'); $('tabDown').onclick = () => selectSide('DOWN');
  for(const minutes of [5,15])$('chart'+minutes+'m').onclick=()=>{
    if(!state)return;chartView=ChartView.update(chartView,minutes+'m',state.serverTime,chartFloor());renderNowChart();
  };
  for(const [id,action]of [['chartZoomIn','in'],['chartZoomOut','out'],['chartEarlier','earlier'],
    ['chartLater','later'],['chartReset','reset']])$(id).onclick=()=>{
      if(!state)return;chartView=ChartView.update(chartView,action,state.serverTime,chartFloor());
      for(const k of ['inspectTime','inspectBuy','inspectSale'])delete $('nowChartPlot').dataset[k];
      renderNowChart();
    };
  $('editTrail').onclick=()=>{
    if(jumpNowProtection('Trail'))return;
    const own=state?.openTrade?.ticker===state?.market?.ticker?state.openTrade:null;
    const side=own?(own.side==='yes'?'UP':'DOWN'):selected;
    selectSide(side);
    const input=$(side==='UP'?'upTrailEnabled':'downTrailEnabled');
    const section=input.closest('details');if(section)section.open=true;
    reveal(input).scrollIntoView({block:'center'});input.focus({preventScroll:true});
  };
  $('editStair').onclick=()=>{
    if(jumpNowProtection('Stair'))return;
    const own=state?.openTrade?.ticker===state?.market?.ticker?state.openTrade:null;
    const side=own?(own.side==='yes'?'UP':'DOWN'):selected;
    selectSide(side);
    const input=$(side==='UP'?'upStairEnabled':'downStairEnabled');
    input.closest('details').open=true;
    reveal(input).scrollIntoView({block:'center'});input.focus({preventScroll:true});
  };
  $('reviewQualification').onclick=()=>{
    const own=state?.openTrade?.ticker===state?.market?.ticker?state.openTrade:null;
    const side=own?(own.side==='yes'?'UP':'DOWN'):selected;
    selectSide(side);
    const input=$((side==='UP'?'up':'down')+'RequireQualification');
    reveal(input).scrollIntoView({block:'center'});input.focus({preventScroll:true});
    feedback('rulesFeedback','Review only: uncheck “Require spread qualification before selling” to remove the earlier prerequisite, then Apply to save. This does not disable the SELL spread check. No settings changed.');
  };
  function jumpNowProtection(kind){
    if(state?.openTrade?!state.openTrade.nowEntryConfig:!state?.settings?.nowEntry?.enabled)return false;
    const side=state.openTrade?(state.openTrade.side==='yes'?'up':'down'):selected.toLowerCase();
    nowEntryUI.reveal(side);
    const input=$('nw-'+side+kind+'Enabled');
    input.closest('details').open=true;
    reveal(input).scrollIntoView({block:'center'});input.focus({preventScroll:true});
    return true;
  }
  $('editEntryProtection').onclick=()=>{
    const own=state?.openTrade?.ticker===state?.market?.ticker?state.openTrade:null;
    const side=own?(own.side==='yes'?'UP':'DOWN'):selected;
    selectSide(side);
    const input=$((side==='UP'?'up':'down')+'EntryProtectionEnabled');
    input.closest('details').open=true;
    reveal(input).scrollIntoView({block:'center'});input.focus({preventScroll:true});
  };
  window.addEventListener('resize',()=>{if(state)renderNowChart();});
  for (const id of ['tabUp','tabDown']) $(id).onkeydown = e => {
    if (['ArrowLeft','ArrowRight'].includes(e.key)) { e.preventDefault(); selectSide(selected === 'UP' ? 'DOWN':'UP'); $(selected === 'UP' ? 'tabUp':'tabDown').focus(); }
  };
  async function perform(fn, message) {
    if (pending) return;
    pending = true; render();
    try { state = await fn(); disconnected=false; offset = state.serverTime - Date.now(); render(); if (message) toast(message); }
    catch (err) { toast(err.message); throw err; }
    finally { pending = false; render(); }
  }
  async function poll() {
    if(invalidCoin){renderCoins(true);return;}
    if (polling || pending) return;
    polling = true;
    const epoch=sessionEpoch;
    try {
      state = await api('/api/state'); disconnected=false; lastSuccess = Date.now(); offset = state.serverTime - Date.now();
      if (!initialized) { fillRules(state.settings.rules); safetyUI.fill(state.settings.safety); followingUI.fill(state.settings.following); initialized = true; }
      render();
    } catch(err) {
      if(epoch!==sessionEpoch)return;
      if(viewedCoin!=='BTC'&&err.status===404){
        state=null;disconnected=true;$('main').hidden=true;$('openSettings').disabled=true;
        if($('settingsDialog').open)$('settingsDialog').close();
        renderCoins(true);
        return;
      }
      if(err.code==='SESSION_RECONNECT_REQUIRED'){
        enterReconnectGate();
        return;
      }
      if(recoveryRequired){
        disconnected=true;renderSession();
        return;
      }
      disconnected=true;markDisconnectedFeeds();
      renderContractCounter();
      renderSellVolume();
      if(state)renderCoins();
      if(state)renderSession();
      if(state)renderProfiles();
      if(state)renderObservations();
      if(state)renderChopBuy();
      if(state)safetyUI.render(state,true,pending);
      if(state){nowEntryUI.render(state,{pending,disconnected:true});buyConditionsUI.render(state,{pending,disconnected:true});nowExitUI.render(state,{pending,disconnected:true});entryWindowUI.render(state,{pending,disconnected:true});}
      $('lastUpdate').textContent = lastSuccess ? `Disconnected · last update ${time(lastSuccess)}` : 'Disconnected · reconnecting';
      $('guardAction').textContent = 'Connection lost'; $('decisionDot').className = 'status-dot amber';
      $('chartStatus').textContent='DISCONNECTED · chart frozen; server status unknown.';
      $('trailStatus').textContent='Connection lost · exit state unknown';
      $('runBtn').disabled = $('buyUp').disabled = $('buyDown').disabled = true;
    } finally { polling = false; }
  }
  function renderSellVolume(){
    const value=state?.sellContractVolume;
    const locked=!value||pending||disconnected||state.running||state.armedLive||
      state.openTrade||state.position||state.awaitingSettle||state.paper?.pending||
      ['BUYING','SELLING','MANUAL'].includes(state.phase);
    for(const key of SELL_VOLUME_KEYS)$(key).disabled=!!locked;
    for(const side of ['UP','DOWN']){
      const status=$(side.toLowerCase()+'SellVolumeStatus');
      const text=disconnected?'Connection lost.':
        !value?'Available after the contract-volume Sell backend update.':value[side]?.reason||'Waiting for the rule status.';
      if(status.textContent!==text)status.textContent=text;
    }
  }
  function renderContractCounter(){
    const data=state?.contractCounter,input=$('showContractCounter'),visible=data?.enabled===true;
    input.disabled=!data||pending||disconnected;
    input.checked=visible;
    $('contractCounterDisplay').hidden=!visible;
    $('contractCounterFeedback').textContent=disconnected?'Connection lost.':
      !data?'Available after the contract-counter backend update.':
      visible?'Current 15-minute contract · display only':'Off · display only';
    const ready=visible&&!disconnected&&data.status==='ready';
    const empty=visible&&!disconnected&&data.status==='empty';
    const fmt=n=>n.toLocaleString('en-US',{maximumFractionDigits:2});
    const pct=n=>n.toLocaleString('en-US',{maximumFractionDigits:1})+'%';
    $('contractCounterUp').textContent=ready?`${fmt(data.up)} · ${pct(data.upPercent)}`:empty?'0':'--';
    $('contractCounterDown').textContent=ready?`${fmt(data.down)} · ${pct(data.downPercent)}`:empty?'0':'--';
    $('contractCounterUpBar').style.width=ready?`${data.upPercent}%`:'0%';
    $('contractCounterDownBar').style.width=ready?`${data.downPercent}%`:'0%';
    $('contractCounterBar').setAttribute('aria-label',ready?
      `Contract flow: UP ${pct(data.upPercent)}, DOWN ${pct(data.downPercent)}`:'No verified flow split');
    $('contractCounterSummary').textContent=ready?
      `${fmt(data.total)} total · ${data.net===0?'Even flow':`${data.net>0?'UP':'DOWN'} leads by ${fmt(Math.abs(data.net))}`} · as of ${time(data.asOf)}`:
      disconnected?'No current reading while disconnected.':
      ({empty:'No eligible contracts traded yet.',loading:'Counting from this market’s open…',
        'no-market':'Waiting for the current Kalshi market.',
        incomplete:'Too many trades to verify a complete market count. No partial split shown.',
        unavailable:'Trade data unavailable or stale. No split shown.'})[data?.status]||'';
  }
  $('showContractCounter').onchange=async e=>{
    if(!state?.contractCounter||pending||disconnected)return;
    const enabled=e.target.checked,expected=state.contractCounter.enabled;
    try{await perform(()=>api('/api/contract-counter',{enabled,expected}));}
    catch(err){toast(err.message);}
  };
  async function pollPrices(){
    if(pricePolling||!state||pending||document.hidden||disconnected||
      Date.now()-lastSuccess>2500||Date.now()<nextPriceTry)return;
    pricePolling=true;
    const epoch=sessionEpoch;
    const controller=new AbortController();
    const timeout=setTimeout(()=>controller.abort(),1500);
    try{
      const res=await fetch(apiUrl('/api/prices'),{cache:'no-store',signal:controller.signal});
      if(!res.ok)throw new Error('Price channel unavailable');
      const prices=await res.json();
      if(epoch!==sessionEpoch)return;
      if(disconnected||pending||(prices.asset||'BTC')!==viewedCoin||!PriceRefresh.matches(state,prices))return;
      const merged=PriceRefresh.merge(state,prices);
      if(merged!==state){latestPrices=prices;state=merged;}
      priceChannel='fast';renderFeeds();
    }catch{
      priceChannel='standard';nextPriceTry=Date.now()+2000;
      renderPriceRefreshStatus();
    }finally{clearTimeout(timeout);pricePolling=false;}
  }
  async function wake(on) {
    try {
      if (on && 'wakeLock' in navigator && !wakeLock) { wakeLock = await navigator.wakeLock.request('screen'); wakeLock.addEventListener('release',() => wakeLock = null); }
      else if (!on && wakeLock) { await wakeLock.release(); wakeLock = null; }
    } catch {}
  }
  $('runBtn').onclick = async () => {
    if (!state || pending) return;
    try {
      if (state.running) {
        if(state.openTrade&&!await confirmAction('Stop this bot’s automation?',
          'This stops this session’s automatic buys AND all automatic exits, including contract-loss, trailing and entry protection. Your open position remains open and unprotected by this bot. Other sessions are not stopped. To stop only new buys, cancel and use Pause new buys instead.','Stop this bot'))return;
        await perform(() => api('/api/stop',{})); await wake(false);
      }
      else {
        if (state.settings.mode !== 'paper' && !await confirmAction('Start ' + state.settings.mode + ' bot?',
          `This starts automatic buys and your selected exit rules. ${state.settings.mode === 'live' ? 'Real money is at risk.' : 'Demo uses practice funds.'} Enabled now-only, fixed-trailing, staircase or timed cash-out exits can sell independently without the compound-rule wait.`, 'Start bot')) return;
        await perform(() => api('/api/start',{})); if (state.running) await wake(true);
      }
    } catch {}
  };
  $('openSafety').onclick=()=>reveal($('safetySection')).scrollIntoView({behavior:'smooth',block:'start'});
  $('editProfitTrail').onclick=()=>reveal($('safetySection')).scrollIntoView({behavior:'smooth',block:'start'});
  globalThis.addEventListener('spread-guard-stop',async()=>{
    if(!state||pending||disconnected)return;
    if(state.running){await $('runBtn').onclick();return;}
    try{await perform(()=>api('/api/stop',{}));}
    catch(err){toast(err.message);}
  });
  $('applySafety').onclick=async()=>{
    if(!state||pending||disconnected)return;
    try{
      const safety=safetyUI.read();
      const payload=SafetyControls.forBackend(safety,state.features);
      if(safety.requireEntryProtection&&!state.features?.requireEntryProtection)
        throw new Error('Protection-required automatic buys need backend29 activation.');
      if(state.running&&state.openTrade&&(safety.tradeDollarsEnabled||safety.tradePercentEnabled||
          safety.upProfitTrailEnabled||safety.downProfitTrailEnabled)&&
        !await confirmAction('Apply protection to this open trade?',
          'Enabled loss limits may request a sell immediately. Profit-plan changes start a fresh peak observation for the current trade. Other exits remain active. No guaranteed fill, break-even or maximum realized loss.','Apply safety'))return;
      const following=followingUI.payload(state.features);
      await perform(()=>api('/api/settings',{safety:payload,...following,
        expectedSafety:SafetyControls.forBackend(safetyUI.expected(),state.features)}));
      safetyUI.fill(state.settings.safety);followingUI.fill(state.settings.following);safetyUI.render(state,disconnected,pending);followingUI.render(state,disconnected,pending);
      feedback('safetyFeedback','Safety Controls applied. Bot running/arming state was not changed.','success');
    }catch(err){feedback('safetyFeedback',err.message,'error');}
  };
  $('revertSafety').onclick=()=>{
    if(!state)return;safetyUI.fill(state.settings.safety);followingUI.fill(state.settings.following);safetyUI.render(state,disconnected,pending);followingUI.render(state,disconnected,pending);
    feedback('safetyFeedback','Drafts reverted to the applied Safety Controls.');
  };
  $('safetyGroups').addEventListener('input',()=>{if(state)safetyUI.render(state,disconnected,pending);});
  $('followingChoices').addEventListener('input',()=>{if(state)followingUI.render(state,disconnected,pending);});
  $('pauseBuys').onclick=async()=>{
    if(!state||pending||disconnected)return;
    const pauseEntries=!state.settings.safety?.pauseEntries;
    if(!pauseEntries&&!await confirmAction('Resume new buys?',
      'New buys may occur on the next evaluation if all applied entry signals, filters and limits pass. Unsaved drafts are not applied.','Resume new buys'))return;
    try{
      const dirty=safetyUI.dirty(state.settings.safety);
      await perform(()=>api('/api/settings',{safety:{pauseEntries}}));
      if(!dirty)safetyUI.fill(state.settings.safety);
      safetyUI.render(state,disconnected,pending);
      feedback('safetyFeedback',pauseEntries?'New buys paused. Selected exits continue while the bot runs.':
        'New buys resumed, subject to all applied rules.','success');
    }catch(err){feedback('safetyFeedback',err.message,'error');}
  };
  $('exportSafety').onclick=()=>{
    try{
      const a=document.createElement('a'),url=URL.createObjectURL(new Blob([
        JSON.stringify({version:1,safety:safetyUI.read(),following:followingUI.read(),candleReversal:candleUI.read(),lineTrail:lineUI.read()},null,2)],{type:'application/json'}));
      a.href=url;a.download='btc-spread-guard-safety.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
      feedback('safetyFeedback','Safety draft exported. It contains no keys, trades or counters.','success');
    }catch(err){feedback('safetyFeedback',err.message,'error');}
  };
  const safetyFile=document.createElement('input');safetyFile.type='file';safetyFile.accept='.json,application/json';safetyFile.hidden=true;
  $('safetySection').append(safetyFile);
  $('importSafety').onclick=()=>{safetyFile.value='';safetyFile.click();};
  safetyFile.onchange=async()=>{
    try{
      const file=safetyFile.files[0];if(!file)return;
      if(file.size>100000)throw new Error('Safety file is too large.');
      const data=JSON.parse(await file.text());
      if(data.version!==1||!data.safety)throw new Error('Use a version 1 Safety Controls export.');
      const importedSafety=SafetyControls.validate(data.safety);
      const importedFollowing=Object.hasOwn(data,'following')?FollowingTrail.validate(data.following):followingUI.read();
      const importedCandle=Object.hasOwn(data,'candleReversal')?CandleReversal.validate(data.candleReversal):candleUI.read();
      const importedLine=Object.hasOwn(data,'lineTrail')?LineTrail.validate(data.lineTrail):lineUI.read();
      FollowingTrail.assertPlan(importedFollowing,importedSafety);
      safetyUI.fill(importedSafety,state.settings.safety);followingUI.fill(importedFollowing,state.settings.following);safetyUI.render(state,disconnected,pending);followingUI.render(state,disconnected,pending);
      candleUI.fill(importedCandle,state.settings.candleReversal);candleUI.render(state,disconnected,pending);
      lineUI.fill(importedLine,state.settings.lineTrail);lineUI.render(state,disconnected,pending);
      feedback('safetyFeedback','Imported as drafts only. Apply Safety Controls for safety/trails; apply candle and trailing-line settings separately.','success');
    }catch(err){feedback('safetyFeedback',err.message,'error');}
  };
  for (const [id,side] of [['buyUp','UP'],['buyDown','DOWN']]) $(id).onclick = async () => {
    if (!state) return;
    try {
      if (state.settings.mode !== 'paper' && !await confirmAction('Confirm ' + $(id).textContent,
        `${state.settings.mode.toUpperCase()} order. Automatic exits only run while the bot is started.`, 'Place order')) return;
      await perform(() => api('/api/trade',{side}));
    } catch {}
  };
  $('applyRules').onclick = async () => {
    if (!state) return;
    try {
      const rules = readRules(); $('applyRules').disabled = true;
      await perform(() => api('/api/settings',{rules}));
      fillRules(state.settings.rules); feedback('rulesFeedback','UP and DOWN rules saved. Timers restart; trailing best is retained.','success');
    } catch(err) { feedback('rulesFeedback',err.message,'error'); }
    finally { $('applyRules').disabled = false; }
  };
  $('resetRules').onclick = () => { fillRules(state?.profiles?.find(p=>p.id==='factory-baseline')?.config.rules||SpreadGuard.DEFAULT_RULES); feedback('rulesFeedback','Defaults loaded as a draft. Apply to save.'); };
  $('exportRules').onclick = () => {
    try {
      const blob = new Blob([JSON.stringify({app:'Spread Guard',asset:viewedCoin,version:1,rules:readRules()},null,2)],{type:'application/json'});
      const url = URL.createObjectURL(blob), link = document.createElement('a');
      link.href = url; link.download = `${viewedCoin.toLowerCase()}-spread-guard-rules.json`; link.click(); setTimeout(() => URL.revokeObjectURL(url),1000);
      feedback('rulesFeedback','Rule draft exported. No keys or account data included.','success');
    } catch(err) { feedback('rulesFeedback',err.message,'error'); }
  };
  $('importRules').onclick = () => $('rulesFile').click();
  $('rulesFile').onchange = async () => {
    try {
      const file = $('rulesFile').files[0]; if (!file) return;
      if (file.size > 20000) throw new Error('Rule file is too large.');
      const data = JSON.parse(await file.text());
      if((data.asset||'BTC')!==viewedCoin)throw Error('This rule file belongs to a different coin.');
      const rules = SpreadGuard.validateRules(data.rules || data);
      fillRules(rules); feedback('rulesFeedback','Imported as a draft. Apply to save.','success');
    } catch(err) { feedback('rulesFeedback','Invalid rule file: ' + err.message,'error'); }
    finally { $('rulesFile').value = ''; }
  };
  function fillSettings() {
    if (!state) return;
    renderProfiles();
    for (const button of document.querySelectorAll('#modeSeg button')) button.setAttribute('aria-pressed', button.dataset.v === state.settings.mode);
    $('modeHint').textContent = {paper:'Fake funds, real prices. Start here.',demo:'Practice exchange. A matching Demo API key is required.',live:'Real money. Verify a Live key, then explicitly arm trading.'}[state.settings.mode]+
      (viewedCoin!=='BTC'&&state.settings.mode!=='paper'?' This workspace does not move funds between exchange balances.':'');
    $('inUpBuyCents').value = SignedBuy.priceThreshold(state.settings,'UP');
    $('inDownBuyCents').value = SignedBuy.priceThreshold(state.settings,'DOWN');
    $('inDol').value = state.settings.dollars; $('inSlip').value = state.settings.slippage;
    $('inEntryMethod').value = state.settings.entryMethod || 'price';
    $('inEntryMethod').disabled = state.running;
    $('inUpBuyNow').value = state.settings.upBuyNow;
    $('inDownBuyNow').value = state.settings.downBuyNow;
    $('inUpBuyNow').disabled = $('inDownBuyNow').disabled = state.running;
    for(const id of ['inUpBuyCents','inDownBuyCents','inDol','inSlip'])$(id).disabled=state.running;
    $('inReentryEnabled').checked = state.settings.reentryEnabled;
    $('inReentryCooldown').value = state.settings.reentryCooldown;
    $('inMaxTrades').value = state.settings.maxTradesPerMarket;
    for (const id of ['inReentryEnabled','inReentryCooldown','inMaxTrades','saveReentry']) $(id).disabled = state.running;
    for(const [id,[key,value]]of Object.entries(REBUY_FIELDS)){
      if(typeof value==='boolean')$(id).checked=state.settings[key]??value;
      else $(id).value=state.settings[key]??value;
      $(id).disabled=state.running||!supportsRebuy();
    }
    $('soldReentrySettingsStatus').textContent=supportsRebuy()?
      'Save re-entry settings applies these drafts. Markers never turn trading on.':
      'Backend update/restart required. These new controls are disabled; existing rules remain unchanged.';
    renderRebuyPreviews();
    renderEntryDraft();
  }
  function renderEntryDraft() {
    feedback('buySaveFeedback','');
    const spread = $('inEntryMethod').value === 'spread';
    $('priceEntryHelp').hidden = spread; $('spreadEntryHelp').hidden = !spread;
    $('upBuyCentsField').hidden = $('downBuyCentsField').hidden = spread;
    $('upBuyNowField').hidden = $('downBuyNowField').hidden = spread;
    $('entryMethodHelp').textContent = spread ? 'Buy UP and DOWN use their own BUY checkboxes, separate from SELL checkboxes. Numeric signal levels remain shared where labeled; changing those numbers can affect both paths.' :
      'UP and DOWN each have a cents buy trigger AND a separate dollar Now filter. Save below to apply edits.';
    if(state.settings.nowEntry?.enabled)$('entryMethodHelp').textContent='Now-only monitor is ON: this saved price/spread setup is inactive. Disable the Now monitor under Position monitor to use it again. '+$('entryMethodHelp').textContent;
    for (const side of ['UP','DOWN']) {
      const rules = state.settings.rules, up = side === 'UP';
      const checks = SpreadGuard.entryChecks(rules,state.feeds,side).filter(c=>c.enabled);
      const value = $(up?'inUpBuyCents':'inDownBuyCents').value;
      const valid = value !== '' && Number.isFinite(Number(value)) && Number(value) >= 1 && Number(value) <= 99;
      const rawNow = $(up?'inUpBuyNow':'inDownBuyNow').value, nowValue = Number(rawNow);
      const nowValid = rawNow !== '' && Number.isFinite(nowValue) &&
        (up ? nowValue >= 0 && nowValue <= 100000 : nowValue <= 0 && nowValue >= -100000);
      $('settingsBuy'+(up?'Up':'Down')).textContent = spread ?
        checks.length ? checks.map(c=>`${c.name} ${c.op} ${signed(c.threshold)}`).join('\n') +
          `\nAll checked BUY rules for ${up?rules.upSeconds:rules.downSeconds}s (saved rules).` :
          'Automatic spread buying disabled: no checked rules for this direction.' :
        !valid ? `Enter the ${side} buy price trigger from 1 to 99¢.` :
        !nowValid ? `Enter a ${up?'positive or zero':'negative or zero'} signed Now buy threshold.` :
          `Buy ${side} only when BOTH pass:\n${side} ask > ${Number(value)}¢\nAND Now ${up?'≥':'≤'} ${signed(nowValue)}.\nBuy-only filter; does not change sell thresholds.`;
      $('edit'+(up?'Up':'Down')+'BuyRules').textContent = spread ?
        `Edit ${side} spread buy / sell rules` : `View ${side} sell rules`;
    }
    refreshBuySaveState();
  }
  function buyDraftDirty() {
    const fields={inDol:'dollars',inSlip:'slippage',inUpBuyNow:'upBuyNow',inDownBuyNow:'downBuyNow'};
    return Object.entries(fields).some(([id,key])=>$(id).value.trim()===''||Number($(id).value)!==state.settings[key])||
      $('inEntryMethod').value!==state.settings.entryMethod||
      ['UP','DOWN'].some(side=>{const value=$(side==='UP'?'inUpBuyCents':'inDownBuyCents').value;
        return value.trim()===''||Number(value)!==SignedBuy.priceThreshold(state.settings,side);});
  }
  function refreshBuySaveState() {
    if(!state)return;
    for(const id of ['inEntryMethod','inUpBuyCents','inDownBuyCents','inUpBuyNow','inDownBuyNow','inDol','inSlip'])
      $(id).disabled=state.running||pending||disconnected;
    const dirty=buyDraftDirty();
    $('buySaveState').textContent=state.running?'Stop the bot before editing or saving buy settings.':
      dirty?'UNSAVED buy changes. Click Save UP & DOWN buy settings to apply.':
      `SAVED: UP > ${SignedBuy.priceThreshold(state.settings,'UP')}¢; DOWN > ${SignedBuy.priceThreshold(state.settings,'DOWN')}¢. Now filters are separate dollar values.`;
    $('saveEntry').disabled=state.running||pending||disconnected;
  }
  $('inEntryMethod').onchange = renderEntryDraft;
  $('inUpBuyCents').oninput = $('inDownBuyCents').oninput = renderEntryDraft;
  $('inUpBuyNow').oninput = $('inDownBuyNow').oninput = renderEntryDraft;
  $('inDol').oninput = $('inSlip').oninput = renderEntryDraft;
  for (const side of ['UP','DOWN']) {
    $('edit'+(side==='UP'?'Up':'Down')+'BuyRules').onclick = () => {
      $('settingsDialog').close(); selectSide(side);
      reveal(document.querySelector('.rules')).scrollIntoView({block:'start'});
      $(side==='UP'?'tabUp':'tabDown').focus({preventScroll:true});
    };
  }
  let profilesSignature = '', previewSignature = '';
  function renderProfiles() {
    if (!state) return;
    $('profileScope').textContent=viewedCoin!=='BTC'?`Private to this ${viewedCoin} workspace. BTC and other coins keep their own profiles.`:state.profilesShared?
      'Shared profile library · available in every session of this app. Loading is separate; other sessions keep their applied rules.':
      'Session-only profile storage. Backend update required for shared profiles.';
    const profiles = state?.profiles || [], select = $('settingsProfile'), choices = $('profileChoices');
    const signature = JSON.stringify(profiles.map(p => [p.id,p.name,p.updatedAt,p.paperOnly]));
    if (signature !== profilesSignature) {
      const previous = select.value;
      const placeholder=document.createElement('option');
      placeholder.value='';placeholder.textContent='Choose a profile to preview (not applied)';
      select.replaceChildren(placeholder,...profiles.map(p => {
        const option = document.createElement('option');
        option.value = p.id; option.textContent = p.name + (p.paperOnly && !p.builtIn ? ' · Paper-only' : '');
        return option;
      }));
      select.value = profiles.some(p => p.id === previous) ? previous :
        (state.activeProfile?.id || '');
      const scrollTop=choices.scrollTop;
      const focusedId=choices.contains(document.activeElement)?document.activeElement.dataset.profileId:null;
      choices.replaceChildren(...profiles.map(p=>{
        const button=document.createElement('button'),name=document.createElement('span'),meta=document.createElement('span');
        button.type='button';button.className='profile-choice';button.dataset.profileId=p.id;
        name.className='profile-choice-name';name.textContent=p.name;
        meta.className='profile-choice-meta';meta.textContent=p.builtIn?'Built-in preset':p.paperOnly?'Saved profile · Paper-only':'Saved profile';
        button.append(name,meta);
        button.onclick=()=>previewProfile(p.id);
        return button;
      }));
      choices.scrollTop=scrollTop;
      if(focusedId)[...choices.children].find(el=>el.dataset.profileId===focusedId)?.focus({preventScroll:true});
      profilesSignature = signature;
    }
    for(const button of choices.children)
      button.setAttribute('aria-pressed',String(button.dataset.profileId===select.value));
    $('toggleProfileChoices').disabled=!profiles.length;
    $('toggleProfileChoices').textContent=(choices.hidden?'Show':'Hide')+` saved profile list (${profiles.length})`;
    $('toggleProfileChoices').setAttribute('aria-expanded',String(!choices.hidden));
    $('profileBrowseHint').textContent=disconnected?
      'Offline: showing the last loaded profiles. Tap to preview; loading and saving remain disabled until reconnected.':
      'Tap a name below to preview it. Scroll inside the list to see every profile. Selecting never loads or changes settings.';
    const p = profiles.find(x => x.id === select.value);
    const active = state.activeProfile;
    const label = (active ? active.name + (active.modified ? ' · modified' : '') : 'Custom settings') +
      (state.profilePaperOnly ? ' · Paper-only' : '');
    $('activeProfileLabel').textContent = 'Applied: ' + label;
    $('dashboardProfile').textContent = 'Settings profile: ' + label;
    $('profileSummary').textContent = !p ? 'No profile preview selected. Your applied settings above are unchanged.' :
      active?.id===p.id ? (active.modified?'APPLIED, then modified. Preview shows the saved version.':
      'APPLIED to this session. Loading never starts trading.') :
      'NOT APPLIED. Selection is only a preview; use Load selected profile to apply.';
    const nextPreview = JSON.stringify(p)||'none';
    if (nextPreview !== previewSignature) {
      $('profileDescription').textContent = p?.description || '';
      const config = {...p?.config,...EntryWindow.pick(p?.config),upBuyCents:SignedBuy.priceThreshold(p?.config||{},'UP'),downBuyCents:SignedBuy.priceThreshold(p?.config||{},'DOWN')}, labels = {entryMethod:'Entry method',upBuyCents:'UP contract-price trigger (¢)',downBuyCents:'DOWN contract-price trigger (¢)',
        upBuyNow:'UP buy Now ($)',downBuyNow:'DOWN buy Now ($)',dollars:'Buy budget ($)',slippage:'Slippage (¢)',
        entryWindowEnabled:'Entry time window',entryStartMinutes:'Buy start (minutes after open)',
        entryEndAtClose:'Buys until close',entryEndMinutes:'Custom buy end (minutes after open)',
        reentryEnabled:'Re-entry',reentryCooldown:'Re-entry cooldown (s)',maxTradesPerMarket:'Maximum trades per market',
        upRebuyEnabled:'UP sold-point rebuy',upRebuyDirection:'UP movement direction',upRebuyMove:'UP movement ($)',
        downRebuyEnabled:'DOWN sold-point rebuy',downRebuyDirection:'DOWN movement direction',downRebuyMove:'DOWN movement ($)'};
      const entries = p?Object.entries(labels).map(([key,title]) => [title,config[key]]):[];
      for (const [key,value] of Object.entries(p?SpreadGuard.validateRules(config.rules || SpreadGuard.DEFAULT_RULES):{})) {
        const input = $(key), label = document.querySelector(`label[for="${key}"]`) || input?.closest('label');
        const title = label?.textContent.trim().replace(/\s+/g,' ') || key;
        entries.push([(key.startsWith('up')?'UP · ':'DOWN · ')+title,value]);
      }
      for(const [key,value]of Object.entries(p?SafetyControls.validate(config.safety||{}):{}))
        entries.push(['Safety · '+SafetyUI.LABELS[key],value]);
      for(const [key,value]of Object.entries(p?FollowingTrail.validate(config.following):{}))
        entries.push(['Following · '+key.replace(/([A-Z])/g,' $1'),value]);
      for(const [key,value]of Object.entries(p?NowEntry.validate(config.nowEntry):{}))
        entries.push(['Now monitor · '+key.replace(/([A-Z])/g,' $1'),value]);
      if(p)for(const [side,c]of Object.entries(BuyConditions.validate(config.buyConditions))){
        entries.push([side.toUpperCase()+' conditional spread alternative',c.enabled]);
        entries.push([side.toUpperCase()+' condition combination',c.match.toUpperCase()]);
        c.rules.forEach((r,i)=>entries.push([side.toUpperCase()+' condition '+(i+1),
          BuyConditions.describe(r)]));
      }
      for(const [key,value]of Object.entries(p?NowExit.validate(config.nowExit):{}))
        entries.push(['LOW/HIGH SELL · '+key.replace(/([A-Z])/g,' $1'),value]);
      $('profilePreview').replaceChildren(...entries.map(([title,value]) => {
        const row=document.createElement('div'),dt=document.createElement('dt'),dd=document.createElement('dd');
        dt.textContent=title;dd.textContent=typeof value==='boolean'?(value?'ON':'OFF'):String(value??'--');
        row.append(dt,dd);return row;
      }));
      if(p)for(const [key,value]of Object.entries(CandleReversal.validate(config.candleReversal))){
        const row=document.createElement('div'),dt=document.createElement('dt'),dd=document.createElement('dd');
        dt.textContent='Candle exit · '+key.replace(/([A-Z])/g,' $1');
        dd.textContent=typeof value==='boolean'?(value?'ON':'OFF'):String(value);
        row.append(dt,dd);$('profilePreview').append(row);
      }
      if(p)for(const [key,value]of Object.entries(LineTrail.validate(config.lineTrail))){
        const row=document.createElement('div'),dt=document.createElement('dt'),dd=document.createElement('dd');
        dt.textContent='Trailing line · '+key.replace(/([A-Z])/g,' $1');
        dd.textContent=typeof value==='boolean'?(value?'ON':'OFF'):String(value);
        row.append(dt,dd);$('profilePreview').append(row);
      }
      previewSignature=nextPreview;
    }
    const locked = !state || pending || disconnected;
    const unsafe = locked || state.running || state.armedLive || !!state.openTrade ||
      !!state.position || state.awaitingSettle > 0 || state.paper?.pending > 0 ||
      ['BUYING','SELLING','MANUAL'].includes(state.phase);
    $('loadProfile').disabled = unsafe || !p || (p.paperOnly && state.settings.mode !== 'paper');
    $('applyPaperTrial').hidden=viewedCoin!=='BTC';
    $('applyPaperTrial').disabled=viewedCoin!=='BTC'||unsafe||state.settings.mode!=='paper';
    $('restoreProfile').disabled = unsafe || !state.profileUndoAvailable;
    $('saveProfile').disabled = locked;
    $('updateProfile').disabled = locked || !p || p.builtIn;
    $('deleteProfile').disabled = locked || !p || p.builtIn || active?.id === p.id;
    // Browsing cached names is read-only, even while disconnected or busy.
    // All load/save/delete/trial actions retain the safety locks above.
    select.disabled = !profiles.length;
    $('profileLoadHint').textContent = unsafe ?
      (state.armedLive && !state.running ? 'Trading is armed. Use Disarm below, then close any positions before loading.' :
      'Loading locked. Stop/disarm and close positions; wait for orders and settlements.') :
      p?.paperOnly && state.settings.mode !== 'paper' ? 'Select Paper mode below before loading this trial.' :
      'Loading replaces applied settings, never starts trading. Restore reverses the last load.';
    $('disarmForProfiles').hidden = !state.armedLive || state.running;
    $('disarmForProfiles').disabled = locked;
  }
  function assertProfileDraftsSaved() {
    if(lineUI.dirty())throw new Error('Apply or reload your trailing-line draft before saving a settings profile.');
    if(candleUI.dirty())throw new Error('Apply or reload your candle exit draft before saving a settings profile.');
    if(entryWindowUI.dirty())throw new Error('Apply or reload your betting time window draft before saving a profile.');
    if(nowExitUI.dirty())throw new Error('Apply or reload your LOW/HIGH SELL draft before saving a settings profile.');
    if(nowEntryUI.dirty())throw new Error('Apply or reload your Now-monitor draft before saving a settings profile.');
    if(buyConditionsUI.dirty())throw new Error('Apply or reload your conditional buy drafts before saving a settings profile.');
    if(safetyUI.dirty(state.settings.safety))
      throw new Error('Apply or revert your Safety Controls drafts before saving a settings profile.');
    const draft = readRules();
    if (KEYS.some(key => draft[key] !== state.settings.rules[key]))
      throw new Error('Apply your UP/DOWN rule drafts first, then save a settings profile.');
    const fields = {inDol:'dollars',inSlip:'slippage',
      inUpBuyNow:'upBuyNow',inDownBuyNow:'downBuyNow',inReentryCooldown:'reentryCooldown',inMaxTrades:'maxTradesPerMarket'};
    if (buyDraftDirty() || Object.entries(fields).some(([id,key]) => $(id).value.trim() === '' || Number($(id).value) !== state.settings[key]) ||
      $('inEntryMethod').value !== state.settings.entryMethod ||
      $('inReentryEnabled').checked !== state.settings.reentryEnabled || rebuyDirty())
      throw new Error('Save your buy/re-entry edits first, then save a settings profile.');
  }
  async function runProfileAction(body, message, refill = false) {
    await perform(() => api('/api/profiles',body));
    if (refill) { fillRules(state.settings.rules); safetyUI.fill(state.settings.safety); followingUI.fill(state.settings.following); candleUI.fill(state.settings.candleReversal); lineUI.fill(state.settings.lineTrail); fillSettings(); nowEntryUI.reload(); buyConditionsUI.reload(); nowExitUI.reload(); entryWindowUI.reload(); }
    if (state.activeProfile && ['save','update','load','restore','trial'].includes(body.action))
      $('settingsProfile').value = state.activeProfile.id;
    renderProfiles();
    feedback('profileFeedback',message,'success');
  }
  function previewProfile(id){
    $('settingsProfile').value=id;
    renderProfiles();
    if(id)$('profilePreview').closest('details').open=true;
    feedback('profileFeedback','Preview only. Your applied settings have not changed. Use Load selected profile to apply it.');
  }
  $('settingsProfile').onchange = () => previewProfile($('settingsProfile').value);
  $('toggleProfileChoices').onclick=()=>{
    $('profileChoices').hidden=!$('profileChoices').hidden;
    renderProfiles();
  };
  $('applyPaperTrial').onclick=async()=>{
    if(!state||pending)return;
    try{
      assertProfileDraftsSaved();
      if(!await confirmAction('Apply Paper trailing trial?',
        'Enable UP trailing at +$80 / $50 pullback / 2s and DOWN at −$100 / $30 / 2s? Keeps your saved buy prices, Now filters, warm-up and other exits. Creates or replaces “Paper trial with my settings” in the shared library. Other sessions see the saved change but keep their applied rules. Keeps your previous settings for Restore. Unvalidated, not a proven best-profit strategy. Bot remains stopped.','Apply Paper trial'))return;
      await runProfileAction({action:'trial'},'PAPER TRIAL APPLIED. Your buy settings were retained. Bot remains stopped.',true);
    }catch(err){feedback('profileFeedback',err.message,'error');}
  };
  $('disarmForProfiles').onclick = async () => {
    if (!state || pending || !state.armedLive || state.running) return;
    try {
      await perform(() => api('/api/stop',{}));
      fillSettings();feedback('profileFeedback','Trading disarmed. No positions closed and no orders sent.','success');
    } catch (err) { feedback('profileFeedback',err.message,'error'); }
  };
  $('saveProfile').onclick = async () => {
    if (!state || pending) return;
    try {
      assertProfileDraftsSaved();
      await runProfileAction({action:'save',name:$('profileName').value},'Profile saved. No trading started.');
      $('profileName').value = '';
    } catch (err) { feedback('profileFeedback',err.message,'error'); }
  };
  $('updateProfile').onclick = async () => {
    const p = state?.profiles.find(x => x.id === $('settingsProfile').value);
    if (!p || p.builtIn || pending) return;
    try {
      assertProfileDraftsSaved();
      if (!await confirmAction('Replace saved profile?',`Replace “${p.name}” in the shared library with all currently applied settings? Other sessions see the saved change but keep their applied rules. No trading starts.`,'Replace profile')) return;
      await runProfileAction({action:'update',id:p.id,expectedUpdatedAt:p.updatedAt},'Shared profile replaced. Other sessions keep their applied rules. No trading started.');
    } catch (err) { feedback('profileFeedback',err.message,'error'); }
  };
  $('loadProfile').onclick = async () => {
    const p = state?.profiles.find(x => x.id === $('settingsProfile').value);
    if (!p || pending) return;
    try {
      if (!await confirmAction('Load settings profile?',`Load “${p.name}”? Replaces all applied strategy settings and discards unsaved form drafts. Previous applied settings are kept for Restore. Mode, keys, results and market counts stay unchanged. Bot stays stopped.${p.paperOnly?' This is an unvalidated Paper-only trial, not a proven profitable strategy.':''}`,'Load profile')) return;
      await runProfileAction({action:'load',id:p.id},'Profile loaded. Bot stays stopped; review settings before starting.',true);
    } catch (err) { feedback('profileFeedback',err.message,'error'); }
  };
  $('restoreProfile').onclick = async () => {
    if (!state || pending) return;
    try {
      if (!await confirmAction('Restore previous settings?','Restore applied settings from before the last profile load? Unsaved drafts will be discarded. Mode, keys, results and trade limits stay unchanged. The bot stays stopped.','Restore settings')) return;
      await runProfileAction({action:'restore'},'Previous settings restored. Bot remains stopped.',true);
    } catch (err) { feedback('profileFeedback',err.message,'error'); }
  };
  $('deleteProfile').onclick = async () => {
    const p = state?.profiles.find(x => x.id === $('settingsProfile').value);
    if (!p || p.builtIn || pending) return;
    try {
      if (!await confirmAction('Delete saved profile?',`Delete “${p.name}” from the shared library for every session of this app? Applied settings, results and trades will not be removed.`,'Delete profile')) return;
      await runProfileAction({action:'delete',id:p.id,expectedUpdatedAt:p.updatedAt},'Shared profile deleted. Applied settings unchanged.');
    } catch (err) { feedback('profileFeedback',err.message,'error'); }
  };
  $('openSettings').onclick = () => { fillSettings(); $('settingsDialog').showModal(); };
  $('editEntryWindow').onclick=()=>{
    fillSettings();$('settingsDialog').showModal();
    reveal($('entryWindowSettings')).scrollIntoView({block:'start'});
    $('ew-entryWindowEnabled').focus({preventScroll:true});
  };
  $('editSoldReentry').onclick=()=>{
    $('openSettings').click();
    reveal($('inReentryEnabled').closest('fieldset')).scrollIntoView({block:'start'});
    $('inReentryEnabled').focus({preventScroll:true});
  };
  for(const id of [...Object.keys(REBUY_FIELDS),'inReentryEnabled'])$(id).addEventListener('input',renderRebuyPreviews);
  $('closeSettings').onclick = async () => {
    if(pending)return;
    if(state&&buyDraftDirty()&&!await confirmAction('Buy changes are not saved',
      'Cancel to keep editing, then use Save UP & DOWN buy settings. Discard closes Settings without applying these buy changes.','Discard changes'))return;
    $('settingsDialog').close();
  };
  $('settingsDialog').addEventListener('cancel',event=>{event.preventDefault();$('closeSettings').click();});
  $('modeSeg').onclick = async e => {
    const mode = e.target.closest('button')?.dataset.v; if (!mode || !state) return;
    try { await perform(() => api('/api/settings',{mode})); fillSettings(); feedback('settingsFeedback','Mode saved. Trading remains stopped.','success'); }
    catch(err) { feedback('settingsFeedback',err.message,'error'); }
  };
  $('saveEntry').onclick = async () => {
    try {
      await perform(() => api('/api/settings',{entryMethod:$('inEntryMethod').value,upBuyCents:$('inUpBuyCents').value,downBuyCents:$('inDownBuyCents').value,
        upBuyNow:$('inUpBuyNow').value,downBuyNow:$('inDownBuyNow').value,
        dollars:$('inDol').value,slippage:$('inSlip').value}));
      fillSettings();
      const message=`Buy settings saved: UP > ${SignedBuy.priceThreshold(state.settings,'UP')}¢; DOWN > ${SignedBuy.priceThreshold(state.settings,'DOWN')}¢.`;
      feedback('buySaveFeedback',message,'success');feedback('settingsFeedback',message,'success');
    } catch(err) { feedback('buySaveFeedback',err.message,'error');feedback('settingsFeedback',err.message,'error'); }
  };
  $('saveReentry').onclick = async () => {
    try {
      await perform(() => api('/api/settings', {
        reentryEnabled: $('inReentryEnabled').checked,
        reentryCooldown: $('inReentryCooldown').value,
        maxTradesPerMarket: $('inMaxTrades').value,
        ...rebuyDraft(),
      }));
      renderEntryDraft();renderRebuyPreviews(); feedback('settingsFeedback','Re-entry settings saved. Existing market counts are preserved; any buy drafts are still unsaved.','success');
      toast('Re-entry settings saved');
    } catch(err) { feedback('settingsFeedback',err.message,'error'); }
  };
  $('saveKey').onclick = async () => {
    $('saveKey').disabled = true; $('saveKey').textContent = 'Verifying…';
    try {
      await perform(() => api('/api/keys',{keyId:$('inKeyId').value,privateKey:$('inKey').value}));
      feedback('settingsFeedback','Key verified. Review your rules before arming trading.','success');
    } catch(err) { feedback('settingsFeedback',err.message,'error'); }
    finally { $('inKey').value = ''; $('saveKey').disabled = false; $('saveKey').textContent = 'Verify & save key'; }
  };
  $('clearKey').onclick = async () => {
    try {
      if (!await confirmAction('Remove this copy’s key?','The old app’s key is unaffected.')) return;
      await perform(() => api('/api/keys',{clear:true}), 'Key removed');
    } catch(err) { feedback('settingsFeedback',err.message,'error'); }
  };
  $('armTrading').onclick = async () => {
    try {
      if (!await confirmAction('Arm ' + state.settings.mode + ' trading?',
        'Enables order placement in this runtime. Live uses real money. Starting the bot and each manual order still require confirmation. Stop or restart disarms trading.','Arm trading')) return;
      await perform(() => api('/api/arm',{confirm:'ARM TRADING'})); feedback('settingsFeedback','Trading armed for this runtime.','success');
    } catch(err) { feedback('settingsFeedback',err.message,'error'); }
  };
  $('resetPaper').onclick = async () => {
    try {
      if (!await confirmAction('Reset paper cash?','Resets this copy’s fake cash to $1,000. Close positions and stop first. No real account changes.')) return;
      await perform(() => api('/api/paper/reset',{}),'Paper cash reset');
    } catch(err) { feedback('settingsFeedback',err.message,'error'); }
  };
  $('clearResults').onclick = async () => {
    try {
      if (!await confirmAction('Reset these results?','Clears this copy’s result history for the selected mode. Does not change cash, positions, or the old app.')) return;
      await perform(() => api('/api/results/clear',{}),'Results reset');
    } catch {}
  };
  $('clearLog').onclick = async () => { try { await perform(() => api('/api/log/clear',{})); } catch {} };
  document.addEventListener('visibilitychange',() => { if (!document.hidden) { poll(); if (state?.running) wake(true); } });
  function refreshRuleSectionStates(){
    for(const section of document.querySelectorAll('.rule-section')){
      const id=section.dataset.ruleToggle,input=$(id),badge=section.querySelector('.section-state');
      if(!input||!badge)continue;
      const saved=state?.settings?.rules?.[id]??SpreadGuard.DEFAULT_RULES[id];
      badge.textContent=(input.checked?'ON':'OFF')+(input.checked!==saved?' · draft':'');
      badge.classList.toggle('positive',input.checked);
    }
  }
  function prepareOptionHelp() {
    function openHelp(title,paragraphs){
      $('optionHelpTitle').textContent=title;
      $('optionHelpBody').replaceChildren(...paragraphs.map(text=>{
        const p=document.createElement('p');p.textContent=text;return p;
      }));
      $('optionHelpDialog').showModal();
      $('optionHelpBody').scrollTop=0;
    }
    const help={...SpreadGuardHelp.build(SpreadGuard.DEFAULT_RULES),...SafetyUI.help(SafetyControls.DEFAULTS),
      ...NowEntryExamples.build(NowEntry.DEFAULTS),...NowExitHelp.build(NowExit.DEFAULTS),...FollowingTrailUI.help()};
    for(const side of ['up','down']){
      const panel=$(side+'Rules');
      const buy=$(side+'BuyUseSpread').closest('fieldset'),sell=$(side+'UseSpread').closest('fieldset');
      buy.classList.add('buy-selection');sell.classList.add('sell-selection');
      buy.querySelector('p').textContent='Spread-signal buys only. All checked BUY conditions must agree. Uncheck all to disable this side’s spread auto-entry.';
      sell.querySelector('p.muted').textContent='Regular exits only. All checked SELL conditions must agree. Independent exits below can still sell when enabled.';
      // Keep decisions first; advanced exit paths are opt-in, expandable sections.
      for(const field of [buy,sell,$(side+'Spread').closest('fieldset'),$(side+'Target').closest('fieldset')])panel.append(field);
      for(const id of [side+'VolumeEnabled',side+'SellVolumeEnabled',side+'NowOnlyEnabled',side+'EntryProtectionEnabled',side+'TrailEnabled',side+'StairEnabled',side+'CashoutEnabled']){
        const field=$(id).closest('fieldset'),details=document.createElement('details'),summary=document.createElement('summary');
        details.className='rule-section';details.dataset.ruleToggle=id;
        summary.textContent=field.querySelector('legend').textContent;
        const badge=document.createElement('span');badge.className='section-state';summary.append(badge);
        $(id).addEventListener('change',refreshRuleSectionStates);
        details.append(summary,field);
        if(id===side+'VolumeEnabled')buy.after(details);
        else if(id===side+'SellVolumeEnabled')sell.after(details);
        else panel.append(details);
      }
    }
    for(const [id,description]of Object.entries(help)){
      const input=$(id);if(!input)continue;
      const label=document.querySelector(`label[for="${id}"]`)||input.closest('label');
      let target,title;
      if(label){
        title=label.textContent.trim();target=document.createElement('div');
        target.className=input.type==='checkbox'?'option-control':'option-label';
        label.before(target);target.append(label);
      }else{
        target=input.closest('.sold-line-actions')||input.closest('fieldset')?.querySelector('legend')||input.parentElement;
        title=id==='modeSeg'?'Trading mode':input.textContent.trim();
      }
      const example=id.startsWith('nw-')||id.startsWith('nx-');
      if(example)title='Examples: '+description.split('\n\n')[0];
      const body=example?description.split('\n\n').slice(1).join('\n\n'):description;
      const button=document.createElement('button');button.type='button';button.className='option-info';
      button.dataset.testid='help-'+id;button.setAttribute('aria-label','Explain '+title);
      button.setAttribute('aria-haspopup','dialog');button.setAttribute('aria-controls','optionHelpDialog');
      button.onclick=()=>openHelp(title,body.split('\n\n'));
      target.append(button);
    }
    for(const side of ['up','down'])for(const topic of NowEntryExamples.walkthroughs(side))
      $(topic.id).onclick=()=>openHelp(topic.title,topic.paragraphs);
    $('closeOptionHelp').onclick=()=>$('optionHelpDialog').close();
    refreshRuleSectionStates();
  }
  function enterReconnectGate(){
    buySound.reset();
    if(!recoveryRequired){
      sessionEpoch++;
      clearSessionSecrets();
      for(const id of ['settingsDialog','confirmDialog','optionHelpDialog'])if($(id).open)$(id).close();
      dialogResolve?.(false);dialogResolve=null;
    }
    recoveryRequired=true;state=undefined;initialized=false;latestPrices=null;disconnected=false;
    $('main').hidden=true;$('sessionReconnectGate').hidden=false;
    $('openSettings').disabled=true;$('modeChip').textContent='RECONNECT';
    $('modeChip').className='chip';$('dashboardProfile').textContent='Settings profile: reconnect to view your saved settings.';
    $('runBtn').disabled=$('buyUp').disabled=$('buyDown').disabled=true;
    $('lastUpdate').textContent='Reconnect required. No new bot was created.';
    renderSession();
  }
  function renderSession(){
    const supported=!!state?.features?.sessionReconnect||recoveryRequired,s=state?.session;
    const connected=!disconnected&&(!!state||recoveryRequired);
    const status=state?.running?'RUNNING':state?'STOPPED':'UNKNOWN';
    const armed=state?.armedLive?'armed':'disarmed';
    const label=s?.label||'Session recovery update pending';
    $('sessionStatus').textContent=recoveryRequired?
      (disconnected?'Reconnect view is offline. Saved bot trading state is unknown.':
        'Reconnect required. No new bot was created. Saved bots may still be running.'):
      disconnected?
      `${label} · Connection lost; server trading state unknown.`:
      `${label} · This view: ${state.settings.mode.toUpperCase()} · ${status} · ${armed}`+
      (!supported?' · Other sessions may still be trading.':
        s&&!s.known&&!state.running?' · New session view. Your older bot may still be trading.':'');
    $('sessionDetail').textContent=$('sessionStatus').textContent;
    $('sessionPending').hidden=supported;
    for(const id of ['createSessionCode','findSessions','connectSessionCode'])
      $(id).disabled=!supported||!connected||pending||sessionBusy;
    if(!state)$('createSessionCode').disabled=true;
    for(const id of ['sessionCodeInput','recoverEnv','recoverKeyId','recoverPrivateKey'])
      $(id).disabled=!supported||!connected||pending||sessionBusy;
    $('recoveredSessions').disabled=!supported||pending||sessionBusy||!recoveredSessions.length;
    $('connectRecovered').disabled=!supported||!connected||pending||sessionBusy||!recoveredSessions.length;
  }
  $('openSession').onclick=()=>{
    $('sessionCodeOutput').value='';
    renderSession();
    $('sessionDialog').showModal();
  };
  $('reconnectGateButton').onclick=()=>$('openSession').click();
  function clearSessionSecrets(){
    for(const id of ['sessionCodeOutput','sessionCodeInput','recoverKeyId','recoverPrivateKey'])$(id).value='';
    recoveredSessions=[];
    $('recoveredSessions').replaceChildren(new Option('Verify your key first',''));
    $('recoveredSessions').disabled=true;
    if(state||recoveryRequired)renderSession();
  }
  $('closeSession').onclick=()=>$('sessionDialog').close();
  $('sessionDialog').addEventListener('close',clearSessionSecrets);
  async function sessionAction(action){
    if(pending||sessionBusy)return;
    sessionBusy=true;pending=true;if(state)render();else renderSession();
    feedback('sessionFeedback','Working…');
    try{await action();}
    catch(e){feedback('sessionFeedback',e.message,'error');}
    finally{
      sessionBusy=false;pending=false;
      if(!$('sessionDialog').open)clearSessionSecrets();
      if(state)render();else renderSession();
    }
  }
  $('createSessionCode').onclick=()=>sessionAction(async()=>{
    const result=await api('/api/session/code',{});
    $('sessionCodeOutput').value=result.code;
    feedback('sessionFeedback','Private recovery code created for '+result.label+'. Save it privately. No trading state changed.','success');
  });
  async function reconnectSession(code){
    if(!code)throw Error('Enter a recovery code or verify your original Kalshi key.');
    if(!await confirmAction('Reconnect this view?',
      'Connect to the selected existing session? Its bot may already be trading. No settings will be loaded, no positions closed, and no bot started or stopped.','Reconnect'))return;
    sessionEpoch++;
    await api('/api/session/connect',{code});
    // Discard the old view and any stale in-flight responses/drafts. The server
    // has durably bound this hosting identity to the verified target session.
    window.location.reload();
  }
  $('connectSessionCode').onclick=()=>sessionAction(()=>reconnectSession($('sessionCodeInput').value.trim()));
  $('findSessions').onclick=()=>sessionAction(async()=>{
    recoveredSessions=[];
    $('recoveredSessions').replaceChildren(new Option('Verifying…',''));
    $('recoveredSessions').disabled=true;
    const body={env:$('recoverEnv').value,keyId:$('recoverKeyId').value.trim(),privateKey:$('recoverPrivateKey').value};
    // Clear sensitive form fields immediately, including failed proofs.
    $('recoverPrivateKey').value='';$('recoverKeyId').value='';
    let result;
    try{result=await api('/api/session/find',body);}
    finally{body.privateKey='';body.keyId='';}
    recoveredSessions=result.sessions;
    $('recoveredSessions').replaceChildren(...result.sessions.map((s,i)=>new Option(
      `${s.label} · ${String(s.mode).toUpperCase()} · ${s.running?'RUNNING':'STOPPED'} · ${s.profile}`,String(i))));
    $('recoveredSessions').disabled=!result.sessions.length;
    feedback('sessionFeedback','Matching sessions found. Select the original and choose Reconnect. Nothing has been started or stopped.','success');
  });
  $('connectRecovered').onclick=()=>sessionAction(()=>reconnectSession(recoveredSessions[Number($('recoveredSessions').value)]?.code));
  prepareOptionHelp();
  poll(); setInterval(poll,1000); setInterval(pollPrices,250); setInterval(renderClock,250);
  document.addEventListener('visibilitychange',()=>{
    if(!document.hidden){nextPriceTry=0;poll();pollPrices();}
  });
})();
