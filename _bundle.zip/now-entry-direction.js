(function(root,factory){
  const api=factory(typeof module==='object'&&module.exports?require('./now-entry-engine'):root.NowEntry);
  if(typeof module==='object'&&module.exports)module.exports=api;else root.NowEntryDirection=api;
})(globalThis,function(E){
  'use strict';
  const MAX_GAP=2500;
  const key=(c,market,conditions='')=>String(market)+':'+JSON.stringify(c)+conditions;
  function observe(previous,config,metrics,index,market,now,eligible=true,alternatives=null,conditions=''){
    const c=E.validate(config),id=key(c,market,conditions);
    if(!eligible||!market||!c.enabled||!Number.isFinite(now))return null;
    const valid=previous?.key===id&&now>=previous.last&&now-previous.last<=MAX_GAP;
    const state={key:id,last:now,tracks:{},sides:{}};
    for(const side of ['UP','DOWN']){
      const p=side.toLowerCase(),sign=side==='UP'?1:-1;
      const base=E.evaluate(c,metrics,side,index,null,alternatives),groups=[];
      for(const group of base.groups){
        if(!c[p+'Enabled']||!c[p+'DirectionEnabled']||!group.enabled)continue;
        const trackKey=p+group.kind,checks=group.checks.filter(x=>x.enabled);
        if(!base.ready||!checks.length){
          groups.push({kind:group.kind,confirmed:false,reason:'Selected buy data is missing or stale.'});
          continue;
        }
        const values=Object.fromEntries(checks.map(x=>[x.key,x.value]));
        const old=valid?previous.tracks[trackKey]:null,last=old?.samples.at(-1);
        const adverse=last&&checks.some(x=>sign*(x.value-last.values[x.key])<0);
        let since=old?.since??now,samples=old?.samples.slice()||[];
        if(!last||adverse){since=now;samples=[];}
        // A same-time reversal still resets. Duplicate reads cannot earn time.
        if(!samples.length||now>samples.at(-1).at)samples.push({at:now,values});
        else samples[samples.length-1]={at:now,values};
        const requiredMs=c[p+'DirectionSeconds']*1000,cutoff=now-requiredMs;
        while(samples.length>1&&samples[1].at<=cutoff)samples.shift();
        // Conservative actual sample at/after the window boundary, not an
        // interpolation or an older large move outside the requested window.
        const anchor=samples[0]?.at<cutoff&&samples.length>1?samples[1]:samples[0];
        const moves=checks.map(x=>({source:x.name,move:sign*(x.value-anchor.values[x.key])}));
        const elapsedMs=now-since,move=Math.min(...moves.map(x=>x.move));
        const confirmed=samples.length>=2&&elapsedMs>=requiredMs&&move+1e-9>=c[p+'DirectionMove'];
        state.tracks[trackKey]={since,samples};
        groups.push({kind:group.kind,confirmed,elapsedMs,requiredMs,move,moves,
          reason:adverse?'Adverse selected-source move; confirmation restarted.':
            confirmed?'Movement confirmed.':'Waiting for favorable movement and continuous sampled confirmation.'});
      }
      const matching=base.groups.filter(g=>g.enabled&&g.passed).map(g=>g.kind);
      const passed=groups.some(g=>g.confirmed&&matching.includes(g.kind));
      state.sides[side]={groups,passed,reason:passed?side+' movement confirmed.':
        side+': require every checked source in one qualifying group to move '+
        (side==='UP'?'UP':'DOWN')+' by at least $'+c[p+'DirectionMove']+
        ' within the recent '+c[p+'DirectionSeconds']+'s sampled window; any adverse sample restarts confirmation.'};
    }
    return state;
  }
  function inspect(state,config,market,now,conditions=''){
    const c=E.validate(config);
    if(!state||state.key!==key(c,market,conditions)||now<state.last||now-state.last>MAX_GAP)return {};
    return state.sides;
  }
  return {MAX_GAP,observe,inspect};
});
