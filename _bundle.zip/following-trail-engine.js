(function(root,factory){
  if(typeof module==='object'&&module.exports)module.exports=factory(require('./safety-engine'));
  else root.FollowingTrail=factory(root.SafetyControls);
})(typeof globalThis!=='undefined'?globalThis:this,function(Safety){
  'use strict';
  const DEFAULTS=Object.freeze(Object.fromEntries(['up','down'].flatMap(p=>[
    [p+'Mode','current'],[p+'StageAt',1.5],[p+'StagePullback',.25],
    [p+'ActivationAtr',2],[p+'AtrMultiplier',1.5],
    [p+'MinimumDistance',10],[p+'MaximumDistance',40],[p+'ConfirmationSeconds',1],
  ])));
  function validate(input={}){
    if(!input||typeof input!=='object'||Array.isArray(input))throw Error('Following options must be an object.');
    for(const k of Object.keys(input))if(!Object.hasOwn(DEFAULTS,k))throw Error('Unknown following option: '+k);
    const out={...DEFAULTS,...input};
    for(const [k,v]of Object.entries(out)){
      if(k.endsWith('Mode')){
        if(!['current','staged','volatility'].includes(v))throw Error('Choose Current, Staged or Volatility.');
      }else{
        const n=Number(v),low=k.endsWith('ConfirmationSeconds')?0:.01;
        const high=k.endsWith('ConfirmationSeconds')?300:100000;
        if(!['number','string'].includes(typeof v)||String(v).trim()===''||
          !Number.isFinite(n)||n<low||n>high)throw Error(k+': enter '+low+' to '+high+'.');
        out[k]=n;
      }
    }
    for(const p of ['up','down'])if(out[p+'MinimumDistance']>out[p+'MaximumDistance'])
      throw Error(p.toUpperCase()+': minimum BTC distance must not exceed maximum distance.');
    return out;
  }
  function assertPlan(config,safety){
    const c=validate(config);
    for(const p of ['up','down'])if(c[p+'Mode']==='staged'&&
      (c[p+'StageAt']<safety[p+'ProfitTrailActivation']||
       c[p+'StagePullback']>safety[p+'ProfitTrailPullback']))
      throw Error(p.toUpperCase()+': staged tightening profit must be at/above activation, and its pullback must be at/below the initial pullback.');
    return c;
  }
  // Simple-mean 14 true ranges, NOT Wilder smoothing; closed one-minute bars only.
  function closedAtr(candles,at){
    if(!Number.isFinite(at))return null;
    const b=(candles||[]).filter(x=>Number.isFinite(x.endAt)&&x.endAt<=at)
      .sort((a,b)=>a.endAt-b.endAt).slice(-15);
    if(b.length!==15||at-b[14].endAt>90000)return null;
    let sum=0;
    for(let i=0;i<b.length;i++){
      const x=b[i];
      if(![x.startAt,x.endAt,x.high,x.low,x.close].every(Number.isFinite)||
        x.low<=0||x.high<x.low||x.close<x.low||x.close>x.high||
        x.endAt-x.startAt!==60000||(i&&x.endAt-b[i-1].endAt!==60000))return null;
      if(i)sum+=Math.max(x.high-x.low,Math.abs(x.high-b[i-1].close),Math.abs(x.low-b[i-1].close));
    }
    return sum>0?sum/14:null;
  }
  function needsCandles(c,s){
    c=validate(c);return ['up','down'].some(p=>c[p+'Mode']==='volatility'&&s[p+'ProfitTrailEnabled']);
  }
  function evaluate(config,s,open,mark,metrics,candles,at,running){
    const c=validate(config),p=open?.side==='no'?'down':'up',kind=c[p+'Mode'];
    if(kind==='current')return {...Safety.profitExit(s,open,mark,running),kind};
    if(kind==='staged'){
      const tag=JSON.stringify([kind,c[p+'StageAt'],c[p+'StagePullback']]);
      const owned=open?.profitTrail?.followingTag===tag?open.profitTrail:null;
      const d=Safety.profitExit(s,{...open,profitTrail:owned},mark,running);
      const tightened=d.active&&d.best>=c[p+'StageAt']-1e-9;
      const pullback=tightened?c[p+'StagePullback']:d.pullback;
      let level=d.active?Math.max(d.best-pullback,d.floor??-Infinity):null;
      if(level!==null&&owned?.key===d.state.key&&Number.isFinite(owned.stagedLevel))
        level=Math.max(level,owned.stagedLevel);
      const latched=d.state.latched||!!(d.enabled&&running&&mark&&d.active&&mark.pnl<=level+1e-9);
      const action=!d.enabled?'OFF':!running?'STOPPED':!mark?'PAUSED':
        latched&&!mark.executable?'NO_BID':latched?'SELL':d.active?'TRACKING':'WAIT_ACTIVATION';
      return {...d,kind,level,pullback,tightened,latched,action,
        state:{...d.state,latched,followingTag:tag,stagedLevel:level},
        reason:`${p.toUpperCase()} staged profit trail · ${action}. `+
          (level===null?d.reason:`Best $${d.best.toFixed(2)}; threshold $${level.toFixed(2)}; pullback $${pullback.toFixed(2)}. `)+
          'Other exits remain active; no fill or break-even guarantee.'};
    }
    const enabled=s[p+'ProfitTrailEnabled']===true,entry=open?.followingEntry;
    const key=JSON.stringify([kind,open?.tradeId||open?.startedAt,open?.ticker,open?.side,c,entry]);
    const state=open?.profitTrail?.key===key?{...open.profitTrail}:
      {key,best:null,level:null,active:false,since:null,last:null,latched:false};
    const anchored=Number.isFinite(entry?.atr)&&entry.atr>0&&Number.isFinite(open?.entryNow);
    const atr=closedAtr(candles,at),ready=metrics?.ready===true&&Number.isFinite(metrics.nowDiff);
    const continuous=state.last!==null&&at>state.last&&at-state.last<=3500;
    if(!enabled||!running||!ready||atr===null||!anchored||!continuous)state.since=null;
    state.last=enabled&&running&&ready&&atr!==null&&anchored?at:null;
    const distance=atr===null?null:Math.min(c[p+'MaximumDistance'],
      Math.max(c[p+'MinimumDistance'],atr*c[p+'AtrMultiplier']));
    const up=open?.side!=='no',value=metrics?.nowDiff;
    if(enabled&&running&&ready&&atr!==null&&anchored){
      state.best=state.best===null?value:up?Math.max(state.best,value):Math.min(state.best,value);
      if((up?state.best-open.entryNow:open.entryNow-state.best)>=c[p+'ActivationAtr']*entry.atr-1e-9)
        state.active=true;
      if(state.active){
        const candidate=state.best+(up?-distance:distance);
        state.level=state.level===null?candidate:up?Math.max(state.level,candidate):Math.min(state.level,candidate);
        if(up?value<=state.level:value>=state.level){
          if(state.since===null)state.since=at;
          if(at-state.since>=c[p+'ConfirmationSeconds']*1000)state.latched=true;
        }else state.since=null;
      }
    }
    const action=!enabled?'OFF':!running?'STOPPED':
      state.latched?mark?.executable?'SELL':'NO_BID':
      !anchored?'UNAVAILABLE':!ready||atr===null?'PAUSED':
      !state.active?'WAIT_ACTIVATION':state.since!==null?'EXIT_WAIT':'TRACKING';
    return {kind,state,enabled,action,active:state.active,latched:state.latched,
      best:state.best,level:state.level,atr,distance,entryAtr:entry?.atr??null,mark,
      reason:`${p.toUpperCase()} volatility trail · ${action}. `+
        (!anchored?'Entry Now/ATR unavailable; this trail is unavailable for this trade. ':
        atr===null?'Waiting for 15 consecutive fresh closed Coinbase one-minute candles. ':
        `BTC Now barrier ${state.level===null?'not active':state.level.toFixed(2)}; ATR ${atr.toFixed(2)}; distance ${distance.toFixed(2)} BTC dollars. `)+
        'Not a dollar-profit floor. Other exits remain active.'};
  }
  return {DEFAULTS,validate,assertPlan,closedAtr,needsCandles,evaluate};
});
