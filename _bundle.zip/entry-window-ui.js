(function(root){
  'use strict';
  root.EntryWindowUI={create(save){
    const W=root.EntryWindow,$=id=>document.getElementById(id);
    let state,snapshot=W.pick(),signature='',pending=false,offline=false,saving=false,conflict=false;
    const raw=()=>Object.fromEntries(W.KEYS.map(k=>[k,typeof W.DEFAULTS[k]==='boolean'?$('ew-'+k).checked:$('ew-'+k).value]));
    function dirty(){
      try{return JSON.stringify(W.validate(raw()))!==JSON.stringify(snapshot);}
      catch{return true;}
    }
    function fill(value){
      snapshot=W.pick(value);signature=JSON.stringify(snapshot);conflict=false;
      for(const k of W.KEYS)if(typeof W.DEFAULTS[k]==='boolean')$('ew-'+k).checked=snapshot[k];
      else $('ew-'+k).value=snapshot[k];
    }
    function update(){
      const supported=state?.features?.entryTimeWindow===true;
      const locked=!supported||pending||offline||!!state?.running;
      for(const k of W.KEYS)$('ew-'+k).disabled=locked;
      for(const k of ['entryStartMinutes','entryEndAtClose','entryEndMinutes'])
        $('ew-'+k).disabled=locked||!$('ew-entryWindowEnabled').checked;
      $('ew-entryEndMinutes').disabled||=$('ew-entryEndAtClose').checked;
      $('applyEntryWindow').disabled=locked||conflict;
      $('reloadEntryWindow').disabled=pending||!state;
      $('entryWindowCompatibility').hidden=supported;
      $('entryWindowCompatibility').textContent='NOT ACTIVE: this new entry-time option needs an approved backend restart. Existing rules and settings are unchanged.';
      try{$('entryWindowExample').textContent=W.example(W.validate(raw()));}
      catch(e){$('entryWindowExample').textContent=e.message;}
      const live=state?.entryWindow||W.evaluate(state?.settings,state?.market,state?.serverTime);
      const status=!supported?'Entry time window NOT ACTIVE; backend update pending.':
        offline?'Connection lost. Entry window state unknown.':
        (!state?.running?'STOPPED · no automatic orders. ':'')+live.reason;
      $('entryWindowLive').textContent=status;$('entryWindowDashboard').textContent=status;
      $('entryWindowSaveState').textContent=offline?'Offline: changes disabled.':
        conflict?'Window settings changed elsewhere. Draft retained; Reload saved before applying.':
        state?.running?'Stop the bot before changing this entry-only window.':
        dirty()?'Unsaved entry-window draft. Apply to save; trading is unchanged.':
        'Saved. Applies to buys only; never starts or arms trading.';
    }
    fill();
    $('entryWindowSettings').addEventListener('input',()=>{$('entryWindowFeedback').textContent='';update();});
    $('reloadEntryWindow').onclick=()=>{fill(state?.settings);update();$('entryWindowFeedback').textContent='Saved entry window reloaded. No trading changed.';};
    $('applyEntryWindow').onclick=async()=>{
      try{
        const config=W.validate(raw());saving=true;
        await save({...config,expectedEntryWindow:snapshot});
        $('entryWindowFeedback').textContent='Entry time window saved for UP and DOWN buys. Exits unchanged. No bot started or armed.';
      }catch(e){$('entryWindowFeedback').textContent=e.message;}
      finally{saving=false;update();}
    };
    return {dirty,reload(){fill(state?.settings);if(state)update();},
      render(next,flags={}){
        state=next;pending=!!flags.pending;offline=!!flags.disconnected;
        const value=W.pick(state.settings),nextSignature=JSON.stringify(value);
        if(!signature||nextSignature!==signature){
          if(!saving&&dirty())conflict=true;else fill(value);
        }
        update();
      }};
  }};
})(globalThis);
