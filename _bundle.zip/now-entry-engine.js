(function(root,factory){
  const api=factory(typeof module==='object'&&module.exports?require('./low-high-spread'):root.LowHighSpread);
  if(typeof module==='object'&&module.exports)module.exports=api;
  else root.NowEntry=api;
})(typeof globalThis!=='undefined'?globalThis:this,function(Spread){
  'use strict';
  const DEFAULTS={enabled:false};
  for(const p of ['up','down'])Object.assign(DEFAULTS,{
    [p+'Enabled']:true,[p+'LowEnabled']:p==='down',[p+'LowLevel']:-40,
    [p+'HighEnabled']:p==='up',[p+'HighLevel']:40,
    [p+'TrailEnabled']:false,[p+'TrailMove']:20,[p+'TrailPullback']:20,[p+'TrailSeconds']:0,
    [p+'StairEnabled']:false,[p+'StairStep']:20,[p+'StairSeconds']:0,
    [p+'TrailPercentEnabled']:false,[p+'TrailPercent']:35,
    [p+'StairPercentEnabled']:false,[p+'StairPercent']:35,
    [p+'DirectionEnabled']:false,[p+'DirectionMove']:5,[p+'DirectionSeconds']:3,
  });
  for(const p of ['up','down'])for(const kind of ['Low','High'])Object.assign(DEFAULTS,{
    [p+kind+'UseNow']:true,[p+kind+'UseTarget']:false,
    [p+kind+'TargetLevel']:kind==='Low'?-40:40,
    [p+kind+'UseKalshi']:false,[p+kind+'KalshiLevel']:kind==='Low'?70000:100000,
    [p+kind+'KalshiNowLevel']:null,
  });
  Object.assign(DEFAULTS,Spread.DEFAULTS);
  Object.freeze(DEFAULTS);
  // Keep the four former full-price values for lossless saved-profile roundtrips.
  // They are no longer entry conditions and are not silently converted.
  const FIELDS=Object.freeze(Object.keys(DEFAULTS).filter(k=>!k.endsWith('KalshiLevel')));
  function number(raw){
    if(!['number','string'].includes(typeof raw)||String(raw).trim()==='')return NaN;
    const text=String(raw).trim().replace(/^[\u2212\u2013\u2014\uFE63\uFF0D]/,'-');
    return /^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:e[+-]?\d+)?$/i.test(text)?Number(text):NaN;
  }
  function validate(input={}){
    if(!input||typeof input!=='object'||Array.isArray(input))throw Error('Now monitor settings must be an object.');
    for(const k of Object.keys(input))if(!Object.hasOwn(DEFAULTS,k))throw Error('Unknown Now monitor option: '+k);
    const out={};
    for(const [k,fallback]of Object.entries(DEFAULTS)){
      const raw=Object.hasOwn(input,k)?input[k]:fallback;
      if((k.endsWith('KalshiNowLevel')||k.endsWith('SpreadLevel'))&&(raw==null||raw==='')){
        out[k]=null;continue;
      }
      if(typeof fallback==='boolean'){
        if(typeof raw!=='boolean')throw Error(k+': use checked or unchecked.');
        out[k]=raw;
      }else if(typeof fallback==='string'){
        if(!['above','below'].includes(raw))throw Error(k+': choose at/above or at/below.');
        out[k]=raw;
      }else{
        const lo=k.endsWith('DirectionSeconds')?0.1:k.endsWith('KalshiLevel')?0.01:k.endsWith('Level')?-100000:k.endsWith('Seconds')?0:0.01;
        const hi=k.endsWith('Percent')?100:k.endsWith('KalshiLevel')?100000000:k.endsWith('Seconds')?300:100000,n=number(raw);
        if(!Number.isFinite(n)||n<lo||n>hi)throw Error(k+`: enter a number from ${lo} to ${hi}.`);
        out[k]=n;
      }
    }
    if(out.enabled&&!out.upEnabled&&!out.downEnabled)throw Error('Enable at least one Now buy direction, or turn the monitor off.');
    for(const p of ['up','down']){
      if(out.enabled&&out[p+'Enabled']&&!out[p+'LowEnabled']&&!out[p+'HighEnabled'])
        throw Error(p.toUpperCase()+': enable a low or high Now trigger.');
      for(const kind of ['Low','High'])
        if(out.enabled&&out[p+'Enabled']&&out[p+kind+'Enabled']&&
          !['Now','Target','Kalshi','Spread'].some(s=>out[p+kind+'Use'+s]))
          throw Error(p.toUpperCase()+' '+kind+': check at least one entry condition.');
      for(const [source,suffix]of [['Now','Level'],['Target','TargetLevel'],['Kalshi','KalshiNowLevel'],['Spread','SpreadLevel']])
        if(out[p+'LowEnabled']&&out[p+'HighEnabled']&&out[p+'LowUse'+source]&&out[p+'HighUse'+source]&&
          Number.isFinite(out[p+'Low'+suffix])&&Number.isFinite(out[p+'High'+suffix])&&
          out[p+'Low'+suffix]>=out[p+'High'+suffix])
          throw Error(p.toUpperCase()+': the low '+source+' level must be below the high level.');
    }
    return out;
  }
  function missingKalshiLevels(c){
    return ['up','down'].flatMap(p=>['Low','High'].filter(kind=>
      c[p+'Enabled']&&c[p+kind+'Enabled']&&c[p+kind+'UseKalshi']&&
      !Number.isFinite(number(c[p+kind+'KalshiNowLevel']))).map(kind=>p.toUpperCase()+' '+kind.toUpperCase()));
  }
  function validateForApply(input){
    const c=validate(input),missing=missingKalshiLevels(c);
    if(c.enabled)for(const p of ['up','down'])for(const kind of ['Low','High'])
      if(c[p+'Enabled']&&c[p+kind+'Enabled']&&c[p+kind+'UseSpread']&&!Number.isFinite(c[p+kind+'SpreadLevel']))
        throw Error(p.toUpperCase()+' '+kind.toUpperCase()+': enter a signed Exchange spread level.');
    if(c.enabled&&missing.length)throw Error(missing.join(', ')+
      ': enter a signed Kalshi Now value (for example -26.90), not the full BTC price. Previous full-price thresholds are retained but not used.');
    return c;
  }
  function needsKalshi(config){
    const c=validate(config);
    return c.enabled&&['up','down'].some(p=>c[p+'Enabled']&&
      ['Low','High'].some(k=>c[p+k+'Enabled']&&c[p+k+'UseKalshi']));
  }
  function evaluate(config,metrics,side,index=null,direction=null,alternatives=null){
    const c=validate(config),p=side==='UP'?'up':'down',now=metrics?.nowDiff;
    // The Kalshi Now card shows dollar cents. Match that displayed precision,
    // including floating-point subtraction such as 69973.10 - 70000.
    const kalshiNow=Number.isFinite(index?.nowDiff)?
      Math.sign(index.nowDiff)*Math.round((Math.abs(index.nowDiff)+Number.EPSILON)*100)/100:null;
    const kalshiReady=index?.fresh===true&&index?.status==='live'&&
      ['authenticated_index','public_chart'].includes(index.sourceKind)&&
      Number.isFinite(index.price)&&index.price>0&&Number.isFinite(index.nowDiff)&&Number.isFinite(index.sourceTime)&&
      Date.now()-index.sourceTime<=5000&&index.sourceTime-Date.now()<=1000;
    const groups=k=>['Low','High'].map(kind=>{
      const alternative=alternatives?.[k];
      const checks=[
        ['Now','Now vs target',now,c[k+kind+'Level'],Number.isFinite(now)],
        ['Target','All vs target',metrics?.targetDiff,c[k+kind+'TargetLevel'],Number.isFinite(metrics?.targetDiff)],
        ['Kalshi','Kalshi Now vs target',kalshiNow,c[k+kind+'KalshiNowLevel'],
          kalshiReady&&Number.isFinite(c[k+kind+'KalshiNowLevel'])],
        ['Spread','Exchange spread',metrics?.spread,c[k+kind+'SpreadLevel'],
          metrics?.ready===true&&Number.isFinite(metrics?.spread)&&Number.isFinite(c[k+kind+'SpreadLevel'])],
      ].map(([key,name,value,threshold,fresh])=>({key,name,value,threshold,
        enabled:c[k+kind+'Use'+key],ready:fresh,op:kind==='Low'?'≤':'≥',
        passed:fresh&&(kind==='Low'?value<=threshold:value>=threshold)}));
      const active=checks.filter(x=>x.enabled);
      const spread=active.find(x=>x.key==='Spread');
      const substituted=!!(spread?.ready&&!spread.passed&&alternative?.enabled&&alternative.ready===true&&alternative.passed);
      if(spread){
        spread.substituted=substituted;
        if(alternative?.enabled)spread.alternativeDescription=alternative.description;
      }
      return {kind,enabled:c[k+kind+'Enabled'],checks,
        ready:active.length>0&&active.every(x=>x.ready),
        passed:active.length>0&&active.every(x=>x.passed||(x.key==='Spread'&&substituted))};
    });
    const all=Object.fromEntries(['up','down'].map(k=>[k,groups(k)]));
    // Unknown alternative data must not hide a possible opposite-side match.
    const ready=metrics?.ready===true&&['up','down'].every(k=>!c[k+'Enabled']||
      (all[k].filter(g=>g.enabled).every(g=>g.ready)&&
       (!alternatives?.[k]?.enabled||alternatives[k].ready===true)));
    const hits=k=>ready?all[k].filter(g=>g.enabled&&g.passed).map(g=>g.kind.toLowerCase()):[];
    const matches=['UP','DOWN'].filter(s=>{
      const k=s==='UP'?'up':'down';
      return c[k+'Enabled']&&hits(k).length>0;
    });
    const ambiguous=c.enabled&&matches.length>1;
    const directionEnabled=c[p+'DirectionEnabled'];
    const directionPassed=!directionEnabled||direction?.groups?.some(g=>
      g.confirmed&&all[p].some(x=>x.enabled&&x.passed&&x.kind===g.kind));
    const passed=c.enabled&&ready&&!ambiguous&&matches[0]===side&&directionPassed;
    const description=side+' '+all[p].filter(g=>g.enabled).map(g=>g.kind+': '+
      g.checks.filter(x=>x.enabled).map(x=>{
        const normal=x.name+' '+x.op+' '+(x.threshold??'[enter signed value]');
        return x.alternativeDescription?'('+normal+' OR ['+x.alternativeDescription+'])'+
          (x.substituted?' [alternative met]':''):normal;
      }).join(' AND ')).join(' OR ');
    const missing=missingKalshiLevels(c);
    return {side,now,hits:hits(p),enabled:c.enabled&&c[p+'Enabled'],
      ready,ambiguous,passed,description,groups:all[p],
      direction:directionEnabled?direction||{groups:[],reason:'Waiting for server-observed '+(p==='up'?'rising':'falling')+' confirmation.'}:null,
      reason:!c.enabled?'Low/high buying is off.':
        !c[p+'Enabled']?side+' low/high buying is disabled.':missing.length?
          'Entry blocked: enter and Apply signed Kalshi Now levels for '+missing.join(', ')+'. Old full BTC thresholds are not used.':
        !ready?'Entry blocked: fresh data for every checked condition is required.':
        ambiguous?'Both Now buy levels match. No buy until exactly one direction qualifies.':
        directionEnabled&&matches[0]===side&&!directionPassed?
          (direction?.reason||'Entry blocked: waiting for server-observed '+(p==='up'?'rising':'falling')+' confirmation.') :
        passed?description+' qualifies. Contract cents are not an entry trigger.':description+' is not met.'};
  }
  function exitRules(rules,config){
    if(!config)return rules;
    const c=validate(config),out={...rules};
    for(const p of ['up','down'])Object.assign(out,{
      [p+'TrailEnabled']:c[p+'TrailEnabled'],[p+'TrailFromEntryEnabled']:true,
      [p+'TrailFromEntryMove']:c[p+'TrailMove'],[p+'TrailPullback']:c[p+'TrailPullback'],
      [p+'TrailSeconds']:c[p+'TrailSeconds'],[p+'TrailWarmupEnabled']:false,
      [p+'StairEnabled']:c[p+'StairEnabled'],[p+'StairStep']:c[p+'StairStep'],
      [p+'StairSeconds']:c[p+'StairSeconds'],[p+'StairWarmupEnabled']:false,
      [p+'TrailPercentEnabled']:c[p+'TrailPercentEnabled'],[p+'TrailPercent']:c[p+'TrailPercent'],
      [p+'StairPercentEnabled']:c[p+'StairPercentEnabled'],[p+'StairPercent']:c[p+'StairPercent'],
    });
    return out;
  }
  return {DEFAULTS,FIELDS,number,validate,validateForApply,evaluate,exitRules,needsKalshi,missingKalshiLevels};
});
