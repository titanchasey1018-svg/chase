(function(root){
  'use strict';
  const $=id=>document.getElementById(id);
  function overlay(state){
    const own=state?.openTrade,p=own?.side==='no'?'down':'up';
    if(state?.features?.lineTrail!==true||!own||own.ticker!==state.market?.ticker||
      !state.settings.lineTrail?.[p+'Enabled'])return null;
    const saved=state.guard?.lineTrail||own.lineTrail;
    if(!Number.isFinite(saved?.level))return null;
    const strike=saved.strike??saved.state?.strike??own.lineTarget;
    if(Number.isFinite(strike)&&strike!==state.market.strike)return null;
    return {level:saved.level,side:p.toUpperCase(),startedAt:own.startedAt,
      btcLevel:Number.isFinite(state.market.strike)?state.market.strike+saved.level:null,
      action:state.guard?.lineTrail?.action||'WATCHING'};
  }
  function create(engine,apply){
    let expected=engine.validate(),latest=null,ready=false;
    const labels={Enabled:'Enable trailing-line sell',Distance:'Distance behind best BTC price ($)',
      Seconds:'Continuous touch confirmation (seconds)',ProfitRequired:'Require minimum estimated net profit',
      MinProfit:'Minimum whole-trade net profit ($)'};
    for(const p of ['up','down']){
      const details=document.createElement('details');details.className='safety-group';
      const summary=document.createElement('summary');summary.id='line_'+p+'Summary';
      const field=document.createElement('fieldset');field.id='line_'+p+'Fields';
      const legend=document.createElement('legend');legend.textContent=p.toUpperCase()+' trailing-line sell';field.append(legend);
      const note=document.createElement('p');note.className='small muted';
      note.textContent=p==='up'?'UP: trail below the highest observed Now; sell on a confirmed touch from above.':
        'DOWN: trail above the lowest observed Now; sell on a confirmed touch from below.';
      field.append(note);
      for(const [suffix,label]of Object.entries(labels)){
        const key=p+suffix,row=document.createElement('div'),l=document.createElement('label'),input=document.createElement('input');
        row.className='field-row';input.id=l.htmlFor='line_'+key;l.textContent=label;
        input.type=typeof engine.DEFAULTS[key]==='boolean'?'checkbox':'number';
        if(input.type==='number'){input.step='.01';input.min=suffix==='Distance'?'.01':'0';
          input.max=suffix==='Seconds'?'300':'100000';input.inputMode='decimal';}
        row.append(l,input);field.append(row);
      }
      details.append(summary,field);$('lineTrailFields').append(details);
    }
    function read(){return engine.validate(Object.fromEntries(Object.keys(engine.DEFAULTS).map(k=>{
      const input=$('line_'+k);return [k,input.type==='checkbox'?input.checked:input.value];
    })));}
    function dirty(){try{return JSON.stringify(read())!==JSON.stringify(expected);}catch{return true;}}
    function fill(config,applied=config){
      expected=engine.validate(applied);
      for(const [k,v]of Object.entries(engine.validate(config))){
        const input=$('line_'+k);if(input.type==='checkbox')input.checked=v;else input.value=v;
      }
      ready=true;
    }
    function render(state,disconnected,pending){
      if(!state)return;latest={state,disconnected,pending};
      const saved=engine.validate(state.settings.lineTrail),supported=state.features?.lineTrail===true;
      if(!ready||!dirty())fill(saved);
      const unsafe=disconnected||pending||state.running||state.armedLive||!!state.openTrade||
        !!state.position||state.awaitingSettle>0||state.paper?.pending>0||
        ['BUYING','SELLING','MANUAL'].includes(state.phase);
      const changed=JSON.stringify(saved)!==JSON.stringify(expected);
      $('lineTrailCompatibility').hidden=supported;
      $('applyLineTrail').disabled=!supported||unsafe||changed;
      $('reloadLineTrail').disabled=disconnected||pending;
      for(const p of ['up','down']){
        $('line_'+p+'Fields').disabled=!supported||unsafe;
        $('line_'+p+'MinProfit').disabled=!supported||unsafe||!$('line_'+p+'ProfitRequired').checked;
        $('line_'+p+'Summary').textContent=p.toUpperCase()+' trailing line · '+(saved[p+'Enabled']?'ON':'OFF')+(dirty()?' · draft':'');
      }
      const line=overlay(state),decision=state.guard?.lineTrail;
      const text=!supported?'Trailing-line sell awaits approved backend55 activation.':
        disconnected?'Disconnected: last observed line only; backend status unknown.':
        !state.running?'Stopped: trailing-line automatic sells inactive.':
        decision?.reason||'No owned position. The line appears after enabling and buying.';
      $('lineTrailStatus').textContent='Applied: UP '+(saved.upEnabled?'ON':'OFF')+' · DOWN '+
        (saved.downEnabled?'ON':'OFF')+'. '+text+(changed?' Saved settings changed elsewhere; reload first.':dirty()?' Unsaved draft.':'');
      $('lineTrailChartStatus').textContent=line?
        line.side+' trailing line: Now '+(line.level>=0?'+':'−')+'$'+Math.abs(line.level).toFixed(2)+
          (Number.isFinite(line.btcLevel)?' · BTC $'+line.btcLevel.toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2}):'')+
          '. '+text:text;
    }
    $('lineTrailFields').addEventListener('input',()=>{if(latest)render(latest.state,latest.disconnected,latest.pending);});
    $('applyLineTrail').onclick=async()=>{
      try{
        if(!latest||latest.state.features?.lineTrail!==true)throw Error('Approved backend55 activation required.');
        await apply({lineTrail:read(),expectedLineTrail:expected});
        fill(latest.state.settings.lineTrail);render(latest.state,latest.disconnected,latest.pending);
        $('lineTrailFeedback').textContent='Trailing-line settings applied. No bot started or armed.';
      }catch(e){$('lineTrailFeedback').textContent=e.message;}
    };
    $('reloadLineTrail').onclick=()=>{
      if(latest){fill(latest.state.settings.lineTrail);render(latest.state,latest.disconnected,latest.pending);
        $('lineTrailFeedback').textContent='Reloaded applied trailing-line settings. No trading changed.';}
    };
    fill();ready=false;return {read,dirty,fill,render};
  }
  root.LineTrailUI={create,overlay};
})(globalThis);
