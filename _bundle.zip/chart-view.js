(function(root,factory){
  const api=factory();
  if(typeof module==='object'&&module.exports)module.exports=api;
  else root.ChartView=api;
})(typeof globalThis!=='undefined'?globalThis:this,function(){
  'use strict';
  const MIN=.5,MAX=15;
  function range(view={},now,oldest){
    const minutes=Math.max(MIN,Math.min(MAX,Number.isFinite(view.minutes)?view.minutes:MAX));
    const duration=minutes*60000,earliest=Math.max(now-MAX*60000,Number.isFinite(oldest)?Math.min(now,oldest):now-MAX*60000);
    const end=Number.isFinite(view.end)?Math.max(Math.min(now,earliest+duration),Math.min(now,view.end)):now;
    return {minutes,start:end-duration,end,live:!Number.isFinite(view.end),
      canEarlier:end-duration>earliest+1,canLater:end<now-1};
  }
  function update(view,action,now,oldest){
    const r=range(view,now,oldest);
    let minutes=r.minutes,end=r.live?null:r.end;
    if(action==='in')minutes=Math.max(MIN,minutes/2);
    else if(action==='out')minutes=Math.min(MAX,minutes*2);
    else if(action==='earlier')end=r.end-r.minutes*30000;
    else if(action==='later')end=r.end+r.minutes*30000>=now?null:r.end+r.minutes*30000;
    else if(action==='5m'||action==='15m'||action==='reset'){
      minutes=action==='5m'?5:MAX;end=null;
    }
    if(minutes===MAX)end=null;
    const bounded=range({minutes,end},now,oldest);
    return {minutes:bounded.minutes,end:end===null?null:bounded.end};
  }
  function duration(minutes){
    const seconds=Math.round(minutes*60);
    return seconds<60?`${seconds}s`:seconds%60?`${Math.floor(seconds/60)}m ${seconds%60}s`:`${seconds/60}m`;
  }
  function buys(state){
    const mode=state.settings?.mode,ticker=state.market?.ticker;
    const map=new Map();
    const add=b=>{
      if(!b||b.mode!==mode||b.ticker!==ticker||!['yes','no'].includes(b.side)||
        !Number.isFinite(b.now)||!Number.isFinite(b.at)||b.at>state.serverTime)return;
      const id=b.id||`${mode}:${ticker}:${b.side}:${b.at}`;
      map.set(id,{...b,id});
    };
    for(const s of state.nowChart?.sales||[])add(s.buy);
    const o=state.openTrade;
    if(o&&o.count>0)add({id:o.tradeId,mode:o.mode||mode,ticker:o.ticker,side:o.side,
      at:o.startedAt,now:o.entryNow,price:o.avg});
    return [...map.values()].sort((a,b)=>a.at-b.at);
  }
  return {MIN,MAX,range,update,duration,buys};
});
