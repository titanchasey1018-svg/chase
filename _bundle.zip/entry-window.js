(function(root,factory){
  const api=factory();
  if(typeof module==='object'&&module.exports)module.exports=api;
  else root.EntryWindow=api;
})(globalThis,function(){
  'use strict';
  const DEFAULTS={entryWindowEnabled:false,entryStartMinutes:2,
    entryEndAtClose:true,entryEndMinutes:12};
  const KEYS=Object.keys(DEFAULTS);
  const pick=s=>Object.fromEntries(KEYS.map(k=>[k,s?.[k]??DEFAULTS[k]]));
  function validate(input={},settings=DEFAULTS,running=false){
    const out=pick(settings);
    for(const k of KEYS){
      if(!Object.hasOwn(input,k))continue;
      const v=input[k];
      if(typeof DEFAULTS[k]==='boolean'){
        if(typeof v!=='boolean')throw Error(k+': use checked or unchecked.');
        out[k]=v;
      }else{
        const lo=k==='entryStartMinutes'?0:0.01,hi=k==='entryStartMinutes'?14.99:15;
        if(!['number','string'].includes(typeof v)||String(v).trim()===''||
          !Number.isFinite(Number(v))||Number(v)<lo||Number(v)>hi)
          throw Error(`${k}: enter minutes from ${lo} to ${hi}.`);
        out[k]=Number(v);
      }
      if(running&&out[k]!==pick(settings)[k])throw Error('Stop the bot before changing the entry time window.');
    }
    if(!out.entryEndAtClose&&out.entryEndMinutes<=out.entryStartMinutes)
      throw Error('The custom ending time must be later than the starting time.');
    return out;
  }
  function evaluate(settings,market,now){
    const s=pick(settings),base={enabled:s.entryWindowEnabled===true,allowed:true,state:'OFF',
      startAt:null,endAt:null,remainingMs:0};
    if(!base.enabled)return {...base,reason:'Entry time window OFF. Other entry rules still apply.'};
    try{validate(s);}catch{return {...base,allowed:false,state:'UNKNOWN',reason:'Entry time window blocked: invalid saved timing settings.'};}
    const open=market?.openTime,close=market?.closeTime;
    if(!Number.isFinite(now)||!Number.isFinite(open)||!Number.isFinite(close)||open<=0||close<=open)
      return {...base,allowed:false,state:'UNKNOWN',reason:'Entry time window blocked: verified market opening/closing times are required.'};
    const startAt=open+s.entryStartMinutes*60000;
    // "Until close" never overrides the existing final-five-second prohibition.
    const endAt=Math.min(close-5000,s.entryEndAtClose?close:open+s.entryEndMinutes*60000);
    const result={...base,startAt,endAt};
    if(startAt>=endAt)return {...result,allowed:false,state:'CLOSED',
      reason:'No entry window remains before the market cutoff. Waiting for the next market.'};
    if(now<startAt)return {...result,allowed:false,state:'WAITING',remainingMs:startAt-now,
      reason:`Entry time window: wait ${Math.ceil((startAt-now)/1000)}s before new buys. Exits remain independent.`};
    if(now>=endAt)return {...result,allowed:false,state:'CLOSED',
      reason:'Entry time window ended. No new buys this market; existing positions still follow their exits.'};
    return {...result,state:'OPEN',remainingMs:endAt-now,
      reason:`Entry time window OPEN: ${Math.ceil((endAt-now)/1000)}s left for new buys. All other entry rules must pass.`};
  }
  function example(settings){
    const s=pick(settings);
    return `Each market: wait ${s.entryStartMinutes} minutes after opening; then allow buys until `+
      (s.entryEndAtClose?'market close (last 5 seconds still blocked).':
        `${s.entryEndMinutes} minutes after opening, or the last-5-second cutoff, whichever comes first.`)+
      ' Example: a 9:00 market with start 2 and custom end 12 allows buys from 9:02 up to, but not including, 9:12. Applies to UP/DOWN and manual buys. Exits are not delayed. Waiting does not guarantee a better entry or prevent losses.';
  }
  return {DEFAULTS,KEYS,pick,validate,evaluate,example};
});
