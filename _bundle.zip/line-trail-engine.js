(function(root,factory){
  if(typeof module==='object'&&module.exports)module.exports=factory();
  else root.LineTrail=factory();
})(typeof globalThis!=='undefined'?globalThis:this,function(){
  'use strict';
  const DEFAULTS=Object.freeze(Object.fromEntries(['up','down'].flatMap(p=>[
    [p+'Enabled',false],[p+'Distance',20],[p+'Seconds',2],
    [p+'ProfitRequired',true],[p+'MinProfit',.5],
  ])));
  function validate(input={}){
    if(!input||typeof input!=='object'||Array.isArray(input))throw Error('Trailing-line settings must be an object.');
    if(Object.keys(input).some(k=>!Object.hasOwn(DEFAULTS,k)))throw Error('Unknown trailing-line setting.');
    const out={};
    for(const [k,d]of Object.entries(DEFAULTS)){
      const v=Object.hasOwn(input,k)?input[k]:d;
      if(typeof d==='boolean'){
        if(typeof v!=='boolean')throw Error(k+': use a checkbox.');out[k]=v;
      }else{
        const n=Number(v),min=k.endsWith('Distance')?.01:0,max=k.endsWith('Seconds')?300:100000;
        if(!['number','string'].includes(typeof v)||String(v).trim()===''||!Number.isFinite(n)||n<min||n>max)
          throw Error(k+': enter '+min+' to '+max+'.');
        out[k]=n;
      }
    }
    return out;
  }
  function evaluate(config,open,mark,frame,now,running,previous){
    const c=validate(config),p=open?.side==='no'?'down':'up',up=p==='up';
    const key=JSON.stringify([open?.tradeId||open?.startedAt,open?.ticker,open?.side,c]);
    let state=previous?.key===key?{...previous}:{key,best:null,level:null,since:null,
      last:null,sourceAt:null,observedAt:null,sequence:null,monitorAt:now,strike:open?.lineTarget??null};
    const enabled=c[p+'Enabled'],requiredMs=c[p+'Seconds']*1000;
    const finish=(action,reason)=>({state,enabled,action,reason,requiredMs,
      elapsedMs:state.since==null?0:Math.max(0,now-state.since),
      active:enabled&&Number.isFinite(state.level),best:state.best,level:state.level,
      pnl:mark?.pnl??null,profitRequired:c[p+'ProfitRequired'],minProfit:c[p+'MinProfit'],
      basis:'Coinbase minus current Kalshi target',side:up?'UP':'DOWN',strike:state.strike});
    if(!enabled||!open||!['yes','no'].includes(open.side)||!(open.count>0)){
      state={key,best:null,level:null,since:null,last:null,sourceAt:null,observedAt:null,sequence:null,monitorAt:now,strike:open?.lineTarget??null};
      return finish(!enabled?'OFF':'NO_POSITION',!enabled?p.toUpperCase()+' trailing-line exit OFF.':'No matching owned position.');
    }
    // The entry anchor is the recorded first-fill Now, never reconstructed.
    if(state.best===null&&Number.isFinite(open.entryNow))state.best=open.entryNow;
    if(Number.isFinite(state.best))state.level=state.best+(up?-1:1)*c[p+'Distance'];
    const pause=()=>{state.since=null;state.last=null;state.sourceAt=null;state.observedAt=null;
      state.monitorAt=now;state.sequence=Number.isInteger(frame?.sequence)?frame.sequence:null;};
    if(!running){pause();return finish('STOPPED','Stopped: trailing-line automatic sells inactive.');}
    if(Number.isFinite(state.strike)&&Number.isFinite(frame?.strike)&&state.strike!==frame.strike){
      pause();return finish('PAUSED','Trailing line paused: market target changed; old and new price bases must not be mixed.');
    }
    if(!Number.isFinite(now)||!Number.isFinite(open.startedAt)||frame?.ticker!==open.ticker||
      !Number.isFinite(frame?.strike)||!frame?.fresh||!Number.isFinite(frame.sourceAt)||
      !Number.isInteger(frame.sequence)||frame.sequence<0||
      !Number.isFinite(frame.observedAt)||now-frame.sourceAt>3000||frame.sourceAt>now+250||
      now-frame.observedAt>3000||now<frame.observedAt||frame.sourceAt<open.startedAt){
      pause();return finish('PAUSED','Trailing line paused: fresh matching Coinbase observations required (maximum age 3s).');
    }
    if(!Number.isFinite(state.strike))state.strike=frame.strike;
    const ticks=Array.isArray(frame.ticks)?frame.ticks:[];
    const gap=state.last!=null&&(now<state.last||now-state.last>3000)||
      state.sequence==null&&ticks.length&&ticks[0].observedAt-state.monitorAt>3000||
      state.sequence!=null&&(frame.sequence<state.sequence||
        ticks.length&&ticks[0].sequence>state.sequence+1);
    if(gap){
      state.since=null;state.monitorAt=now;state.sourceAt=null;state.observedAt=null;
      if(frame.sequence<state.sequence)state.sequence=null;
    }
    state.last=now;
    for(const tick of ticks){
      if(state.sequence!=null&&tick.sequence<=state.sequence)continue;
      if(!Number.isInteger(tick.sequence)||!Number.isFinite(tick.price)||tick.price<=0||
        !Number.isFinite(tick.sourceAt)||!Number.isFinite(tick.observedAt)||
        tick.sourceAt>now+250||tick.observedAt>now||tick.sourceAt>tick.observedAt+250||
        tick.observedAt-tick.sourceAt>3000||
        state.sourceAt!=null&&tick.sourceAt<state.sourceAt||
        state.observedAt!=null&&tick.observedAt<state.observedAt)continue;
      state.sequence=tick.sequence;
      if(tick.sourceAt<open.startedAt||tick.observedAt<state.monitorAt)continue;
      if(tick.continuous===false||state.sourceAt!=null&&
        (tick.sourceAt-state.sourceAt>3000||tick.observedAt-state.observedAt>3000))
        state.since=null;
      const value=tick.price-frame.strike;
      state.best=state.best===null?value:up?Math.max(state.best,value):Math.min(state.best,value);
      state.level=state.best+(up?-1:1)*c[p+'Distance'];
      const breached=up?value<=state.level:value>=state.level;
      if(!breached)state.since=null;
      else if(state.since===null)state.since=Math.max(tick.observedAt,state.monitorAt,open.startedAt);
      state.sourceAt=tick.sourceAt;state.observedAt=tick.observedAt;
    }
    if(!Number.isFinite(state.level)||state.observedAt===null||
      now-state.observedAt>3000||now-state.sourceAt>3000)
      return finish('WATCHING','Waiting for a fresh observation after monitoring starts.');
    if(!mark||!mark.executable||!Number.isFinite(mark.pnl)){
      state.since=null;return finish('NO_BID','Trailing line waits for a fresh executable Kalshi bid and whole-trade profit estimate.');
    }
    if(state.since===null)return finish('WATCHING','Following the best observed Now; the line never loosens on a pullback.');
    if(now-state.since<requiredMs)return finish('EXIT_WAIT','Price touched the trailing line; waiting for continuous confirmation.');
    if(c[p+'ProfitRequired']&&mark.pnl<c[p+'MinProfit']-1e-9)
      return finish('PROFIT_WAIT','Line confirmed, but estimated whole-trade net profit is below the minimum. Other exits remain available.');
    return finish('SELL',p.toUpperCase()+' trailing line touched and confirmed'+
      (c[p+'ProfitRequired']?'; estimated whole-trade net profit meets $'+c[p+'MinProfit'].toFixed(2):'')+
      '. Not a guaranteed fill or profit.');
  }
  return {DEFAULTS,validate,evaluate};
});
