(function(root,factory){
  const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.NowExitHelp=api;
})(globalThis,function(){
  'use strict';
  function build(defaults){
    const h={},put=(key,title,text)=>{h['nx-'+key]=title+'\n\n'+text+
      '\n\nApply saves SELL settings for current and future positions, but never starts, arms or sends an order. The bot must be running to sell automatically. Stop disables automatic buys AND sells and keeps your position. Examples are explanations, not recommended settings or guarantees.';};
    put('enabled','LOW/HIGH SELL master switch',
      'OFF: your original regular sell rules remain in use. ON: for each enabled side, one complete LOW or HIGH sell group can replace that side’s old regular checks. Other sides keep their original rules. Buy rules and manual selling do not change.\n\nExample: enable UP, select UP LOW Coinbase Now ≤ −20 and UP HIGH Coinbase Now ≥ +80. Holding UP, Now −20 or +80 can sell; Now +30 cannot. Holding DOWN cannot use UP’s groups. Independent loss, timed cash-out, entry protection, Now-only, trailing and staircase exits can still sell sooner.');
    for(const p of ['up','down']){
      const side=p.toUpperCase();
      put(p+'Enabled',side+' LOW/HIGH SELL side switch',
        `Example: hold ${side}, master ON and this side ON. Its selected LOW/HIGH group can sell this position. Switch this side OFF and its original regular checks return; the other side’s groups cannot sell it. At least one group with a selected source and a level is required when applying an enabled side.`);
      for(const kind of ['Low','High']){
        const k=p+kind,low=kind==='Low',level=low?'−20':'+80',pass=low?'−25':'+85',fail=low?'−15':'+75',op=low?'≤':'≥';
        const intro=`${side} ${kind.toUpperCase()} SELL`;
        put(k+'Enabled',intro+' group switch',
          `Example: check this group and Coinbase Now, enter ${level}. ${side} can sell when Now ${op} ${level}, including equality. ${pass} passes; ${fail} fails. If both LOW and HIGH are enabled, either complete group can sell. All selected sources inside the winning group must pass together for its own confirmation time.\n\nA stale Kalshi source blocks a group that selected Kalshi, but does not block a different group that only needs fresh Coinbase. The two groups do not share confirmation time.`);
        put(k+'Seconds',intro+' confirmation seconds',
          `Example: set 3 seconds and a Coinbase level ${level}. Once Now ${op} ${level}, a continuous 3-second qualifying run is required. At 2 seconds it waits. If Now becomes ${fail}, data becomes stale, monitoring stops, the position/market changes or settings change, that group’s timer resets. Zero means act on the next fresh evaluation, not wait three seconds.\n\nEach group has its own timer. Two seconds in LOW followed by one second in HIGH does not count as three seconds. A gap of more than 3.5 seconds between evaluations also resets confirmation. The sell signal is checked again before submitting an automatic order; actual fills are not guaranteed.`);
        put(k+'Cooldown',intro+' extra cooldown seconds',
          `Optional second timer, separate from the confirmation seconds above. Zero (the default) keeps the existing behavior. Example: confirmation 3s plus cooldown 5s means the checked ${side} ${kind.toUpperCase()} conditions must stay met continuously for about 8 seconds total, with fresh source values still required at the end, before an automatic sell is decided.\n\nThe cooldown begins only after the confirmation time finishes. If any checked condition becomes ${fail}, a selected source goes stale, the bot is stopped, monitoring gaps exceed 3.5 seconds, the held side or market changes, or settings are applied again, the cooldown restarts. It only applies to this LOW/HIGH sell group; contract-loss, timed cash-out, entry protection, Now-only, trailing, staircase and manual sells are not delayed by it. It cannot predict whether the price will reverse, and no profitability or reduced-loss guarantee applies.`);
        for(const source of ['Target','Kalshi','Now','Spread']){
          const name={Target:'All vs target',Kalshi:'signed Kalshi Now',Now:'Coinbase Now',Spread:'Exchange spread'}[source];
          const definition=source==='Target'?'All vs target is the aggregate exchange price minus the market target.':
            source==='Kalshi'?'Use the signed Now value shown by Kalshi, not the full BTC price or contract cents. Red ▼ $26.90 means enter −26.90; green +$26.90 means +26.90. It must come from fresh Kalshi index/reference data; Coinbase is never substituted.':
            source==='Spread'?'Exchange spread is the existing equal-weight aggregate of fresh exchange prices (including Coinbase) MINUS Coinbase. Example aggregate $70,060, Coinbase $70,045 gives +15; aggregate $70,030 gives −15. It is not All vs target, contract cents or the Kalshi bid/ask gap. Default OFF with a blank signed level; no strategy is enabled automatically.':
            'Coinbase Now is Coinbase BTC price minus the market target, not the full BTC price or contract cents.';
          const example=`${definition}\n\nExample: enter ${level} and check this source. ${name} ${pass} passes ${op} ${level}; ${fail} fails; equality passes. Signed ordering matters: −30 is below −20, whereas +30 is above −20. Leave the checkbox unchecked to ignore this source; entering a level alone does not enable it. Checked blank values cannot be applied.\n\nIf you also check another source, BOTH must pass at once. One passing source does not override another failing or stale selected source. Unchecked sources do not block a sell. Only the ${side} position can use this group, with the master, side and group enabled.`;
          put(k+'Use'+source,intro+' require '+name,example);
          put(k+source+'Level',intro+' '+name+' level',example);
        }
      }
    }
    for(const k of Object.keys(defaults))if(!h['nx-'+k])throw Error('Missing SELL help: '+k);
    return h;
  }
  return {build};
});
