(function(root,factory){
  if(typeof module==='object'&&module.exports)module.exports=factory();
  else root.SafetyControls=factory();
})(typeof globalThis!=='undefined'?globalThis:this,function(){
  'use strict';
  const DEFAULTS=Object.freeze({
    tradeDollarsEnabled:false,tradeDollars:5,
    tradePercentEnabled:false,tradePercent:20,
    tradeLossCooldown:0,
    pauseEntries:false,
    marketLossEnabled:false,marketLoss:10,
    dayLossEnabled:false,dayLoss:25,
    losingTradesEnabled:false,losingTrades:3,
    spreadEnabled:false,maxSpread:5,
    depthEnabled:false,depthCoverage:1,depthTolerance:2,
    feedEnabled:false,maxFeedAge:3,maxVenueGap:50,
    confirmEnabled:false,confirmSeconds:5,
    freshReentryEnabled:false,requireEntryProtection:false,
    blockNowOnlyEntry:false,
    upProfitTrailEnabled:false,upProfitTrailActivation:2,upProfitTrailPullback:1,
    upProfitFloorEnabled:false,upProfitFloor:0,
    downProfitTrailEnabled:false,downProfitTrailActivation:2,downProfitTrailPullback:1,
    downProfitFloorEnabled:false,downProfitFloor:0,
  });
  const LIMITS={
    tradeDollars:[.01,100000],tradePercent:[.01,100],tradeLossCooldown:[0,300],
    marketLoss:[.01,100000],dayLoss:[.01,100000],
    losingTrades:[1,1000],maxSpread:[.01,99],
    depthCoverage:[1,20],depthTolerance:[0,20],
    maxFeedAge:[1,15],maxVenueGap:[0,100000],confirmSeconds:[0,300],
    upProfitTrailActivation:[.01,100000],upProfitTrailPullback:[.01,100000],upProfitFloor:[0,100000],
    downProfitTrailActivation:[.01,100000],downProfitTrailPullback:[.01,100000],downProfitFloor:[0,100000],
  };
  const NEW_KEYS=Object.freeze(Object.keys(DEFAULTS).filter(k=>k==='blockNowOnlyEntry'||k.includes('Profit')));
  function validate(input={}){
    if(!input||typeof input!=='object'||Array.isArray(input))throw new Error('Safety settings must be an object.');
    const out={};
    for(const [key,def]of Object.entries(DEFAULTS)){
      const raw=Object.hasOwn(input,key)?input[key]:def;
      if(typeof def==='boolean'){
        if(typeof raw!=='boolean')throw new Error(`${key}: check or uncheck this safety option.`);
        out[key]=raw;continue;
      }
      const [lo,hi]=LIMITS[key],n=Number(raw);
      if(!['number','string'].includes(typeof raw)||String(raw).trim()===''||
        !Number.isFinite(n)||n<lo||n>hi||(key==='losingTrades'&&!Number.isInteger(n)))
        throw new Error(`${key}: enter ${lo} to ${hi}${key==='losingTrades'?' as a whole number':''}.`);
      out[key]=n;
    }
    for(const p of ['up','down'])if(out[p+'ProfitFloorEnabled']&&
      out[p+'ProfitFloor']>out[p+'ProfitTrailActivation'])
      throw new Error(`${p.toUpperCase()} profit floor must be at or below profit-trail activation.`);
    return out;
  }
  function forBackend(input,features){
    const out=validate(input);
    if(features?.stopLossCooldown!==true){
      if(out.tradeLossCooldown!==0)
        throw new Error('Stop-loss cooldown needs approved backend49 activation. Existing safety controls remain available.');
      delete out.tradeLossCooldown;
    }
    if(features?.profitProtection!==true){
      if(NEW_KEYS.some(k=>out[k]!==DEFAULTS[k]))
        throw new Error('Profit protection and Now-only entry guard need approved backend44 activation. Existing safety controls remain available.');
      for(const k of NEW_KEYS)delete out[k];
    }
    return out;
  }
  function nowOnlyEntry(s,rules,m,side){
    const p=side==='UP'?'up':'down',enabled=s.blockNowOnlyEntry===true&&rules[p+'NowOnlyEnabled']===true;
    const value=m?.nowDiff,threshold=rules[p+'NowOnlyThreshold'],direction=rules[p+'NowOnlyDirection'];
    const ready=m?.ready===true&&Number.isFinite(value)&&Number.isFinite(threshold)&&['above','below'].includes(direction);
    const conflict=ready&&(direction==='below'?value<threshold:value>threshold);
    const allowed=!enabled||ready&&!conflict;
    return {enabled,allowed,conflict,value,threshold,direction,reason:!enabled?
      'Now-only conflict guard off or this side’s Now-only exit disabled.':!ready?
      `New ${side} buy blocked: fresh Coinbase Now and valid Now-only sell settings required.`:conflict?
      `New ${side} buy blocked: Coinbase Now ${value.toFixed(2)} is already ${direction} ${threshold}; its Now-only exit is true.`:
      `${side} Now-only exit is not currently true. Other entry checks still apply.`};
  }
  // An independent money-based trail, not a Coinbase-reference trail.
  // Configuration is part of the key: applying a different plan starts fresh.
  function profitExit(s,open,mtm,running){
    const p=open?.side==='no'?'down':'up';
    const config=[s[p+'ProfitTrailEnabled']===true,s[p+'ProfitTrailActivation'],
      s[p+'ProfitTrailPullback'],s[p+'ProfitFloorEnabled']===true,s[p+'ProfitFloor']];
    const [enabled,activation,pullback,floorEnabled,floor]=config;
    const key=JSON.stringify([open?.tradeId||open?.startedAt,open?.ticker,open?.side,config]);
    const old=open?.profitTrail;
    const state=old?.key===key?{...old}:{key,best:null,active:false,latched:false};
    const valid=!!mtm&&Number.isFinite(mtm.pnl);
    if(enabled&&running&&valid){
      if(mtm.executable){
        state.best=Number.isFinite(state.best)?Math.max(state.best,mtm.pnl):mtm.pnl;
        if(state.best>=activation-1e-9)state.active=true;
      }
    }
    const level=state.active?Math.max(state.best-pullback,floorEnabled?floor:-Infinity):null;
    if(enabled&&running&&valid&&state.active&&mtm.pnl<=level+1e-9)state.latched=true;
    const action=!enabled?'OFF':!running?'STOPPED':!valid?'PAUSED':
      state.latched&&!mtm.executable?'NO_BID':state.latched?'SELL':state.active?'TRACKING':'WAIT_ACTIVATION';
    const money=n=>(n<0?'−':'')+'$'+Math.abs(n).toFixed(2);
    const reason=!enabled?`${p.toUpperCase()} contract-profit trail OFF.`:!running?
      'STOPPED: no profit-trail observations or automatic exits.':!valid?
      'Profit trail paused: fresh matching Kalshi bid and recorded position required.':
      state.latched&&!mtm.executable?'Profit exit latched; waiting for a fresh executable sell bid.':
      state.latched?`Contract-profit exit: estimated whole-trade P&L ${money(mtm.pnl)}; breached threshold ${money(level)}. Exit attempt latched.`:
      state.active?`Tracking contract profit: current ${money(mtm.pnl)}, best ${money(state.best)}, exit at/below ${money(level)}.`:
      `Profit trail not active: estimated P&L ${money(mtm.pnl)}; needs ${money(activation)}. Separate loss protection is still needed.`;
    return {state,enabled,action,reason,active:state.active,latched:state.latched,best:state.best,level,
      activation,pullback,floor:floorEnabled?floor:null,mark:mtm};
  }
  const dayFormatter=new Intl.DateTimeFormat('en-US',{timeZone:'America/New_York',
    year:'numeric',month:'2-digit',day:'2-digit'});
  function dayKey(now){
    const parts=dayFormatter.formatToParts(now);
    return ['year','month','day'].map(k=>parts.find(p=>p.type===k).value).join('-');
  }
  const stats=()=>({pnl:0,losers:0,completed:0,lossLocked:false,losersLocked:false});
  function totals(ledger,history,mode,ticker,now){
    ledger.days||={};ledger.markets||={};
    const day=dayKey(now),dk=mode+':'+day,mk=mode+':'+ticker;
    const seed=rows=>{
      const s=stats();s.seededFromRetainedHistory=true;
      for(const r of rows){
        s.pnl+=Number.isFinite(r.pnl)?r.pnl:0;
        if(r.completed!==false){s.completed++;if((r.tradePnl??r.pnl)<0)s.losers++;}
      }
      return s;
    };
    ledger.days[dk]||=seed(history.filter(r=>r.mode===mode&&Number.isFinite(r.at)&&dayKey(r.at)===day));
    ledger.markets[mk]||=seed(history.filter(r=>r.mode===mode&&r.ticker===ticker));
    return {day,dayStats:ledger.days[dk],marketStats:ledger.markets[mk]};
  }
  function recordResult(ledger,history,row){
    const t=totals(ledger,history,row.mode,row.ticker,row.at);
    for(const s of [t.dayStats,t.marketStats]){
      s.pnl+=row.pnl;
      if(row.completed!==false){s.completed++;if((row.tradePnl??row.pnl)<0)s.losers++;}
    }
  }
  function hydrate(ledger,history,now){
    const seen=new Set();
    for(const row of history){
      const key=row.mode+':'+row.ticker;
      if(seen.has(key)||!row.mode||!row.ticker)continue;
      seen.add(key);totals(ledger,history,row.mode,row.ticker,now);
    }
    return ledger;
  }
  function quoteFresh(q,market,now){
    return !!q&&Number.isFinite(q.ts)&&now>=q.ts&&now-q.ts<=10000&&
      (!q.ticker||q.ticker===market?.ticker)&&!!market&&now<market.closeTime&&
      (!q.status||['open','active'].includes(q.status));
  }
  function mark(open,q,market,mode,now,estimateFee){
    if(!open||open.ticker!==market?.ticker||(open.mode&&open.mode!==mode)||
      !(open.count>0)||!Number.isFinite(open.avg)||!quoteFresh(q,market,now))return null;
    const bid=open.side==='yes'?q.upBid:q.downBid;
    if(!Number.isFinite(bid)||bid<0||bid>100)return null;
    const cost=open.avg*open.count+(Number(open.fee)||0);
    const exitFee=mode==='paper'?0:estimateFee(open.count,bid/100);
    const remainingPnl=bid/100*open.count-cost-exitFee;
    const pnl=remainingPnl+(Number(open.realizedPnl)||0);
    const basis=Number.isFinite(open.entryCostTotal)&&open.entryCostTotal>0?open.entryCostTotal:cost;
    return {bid,remainingPnl,pnl,basis,lossPercent:basis>0?-pnl/basis*100:null,
      exitFee,executable:bid>0&&bid<100};
  }
  function lossExit(s,open,mtm,running,now=Date.now(),previous=null){
    const enabled=s.tradeDollarsEnabled||s.tradePercentEnabled;
    const requiredMs=(s.tradeLossCooldown||0)*1000;
    const key=JSON.stringify([open?.tradeId||open?.startedAt,open?.ticker,open?.side,open?.mode,
      s.tradeDollarsEnabled,s.tradeDollars,s.tradePercentEnabled,s.tradePercent,requiredMs]);
    // Pending timers are runtime-only. Confirmed latches remain on the owned
    // trade for retry safety; adding a cooldown must not delay an existing latch.
    const state=previous?.key===key?{...previous}:{key,since:null,last:null};
    if(state.last==null||now<state.last||now-state.last>3500)state.since=null;
    state.last=now;
    const dollarHit=s.tradeDollarsEnabled&&running&&!!mtm&&mtm.pnl<=-s.tradeDollars+1e-9;
    const percentHit=s.tradePercentEnabled&&running&&!!mtm&&
      Number.isFinite(mtm.lossPercent)&&mtm.lossPercent>=s.tradePercent-1e-9;
    const triggered=!!(dollarHit||percentHit);
    if(!enabled||!running||!mtm||!triggered)state.since=null;
    else if(state.since==null)state.since=now;
    const elapsedMs=state.since==null?0:Math.max(0,now-state.since);
    const confirmed=triggered&&elapsedMs>=requiredMs;
    const old=open?.safetyStop||{},dollars=s.tradeDollarsEnabled&&
      (old.dollars===true||confirmed&&dollarHit);
    const percent=s.tradePercentEnabled&&(old.percent===true||confirmed&&percentHit);
    const latched={...old,dollars:old.dollars===true||dollars,percent:old.percent===true||percent};
    const breached=dollars||percent;
    const action=!enabled?'OFF':!running?'STOPPED':!mtm?'PAUSED':
      breached&&!mtm.executable?'NO_BID':breached?'SELL':triggered?'EXIT_WAIT':'HOLD';
    const reason=!enabled?'Trade-loss protection off.':!running?'All automation is stopped.':
      !mtm?'Waiting for a fresh Kalshi sell quote and owned position.':
      breached&&!mtm.executable?'Loss stop latched; waiting for an executable sell bid.':
      breached?`Contract-loss exit: ${dollars?'dollar':'percentage'} limit reached. Bid-based estimated trade P&L $${mtm.pnl.toFixed(2)}.`:
      triggered?`Stop-loss cooldown ${(elapsedMs/1000).toFixed(1)} / ${requiredMs/1000}s. Estimated trade P&L $${mtm.pnl.toFixed(2)}. Waiting can increase losses; other exits remain active.`:
      `Bid-based estimated trade P&L $${mtm.pnl.toFixed(2)}. No enabled loss limit reached.`;
    return {action,reason,latched,breached,triggered,mark:mtm,dollars,percent,
      state,elapsedMs,requiredMs};
  }
  function limits(s,t,mtm=null){
    const unrealized=mtm?.remainingPnl||0,marketPnl=t.marketStats.pnl+unrealized,dayPnl=t.dayStats.pnl+unrealized;
    const marketHit=s.marketLossEnabled&&(t.marketStats.lossLocked||marketPnl<=-s.marketLoss+1e-9);
    const dayHit=s.dayLossEnabled&&(t.dayStats.lossLocked||dayPnl<=-s.dayLoss+1e-9);
    const losingHit=s.losingTradesEnabled&&(t.dayStats.losersLocked||t.dayStats.losers>=s.losingTrades);
    const blockers=[];
    if(s.pauseEntries)blockers.push('New buys paused. Selected exits still run while the bot is started.');
    if(marketHit)blockers.push('Market loss limit locked. No new buys until the next market or this rule is disabled.');
    if(dayHit)blockers.push('Trading-day loss limit locked. No new buys until New York midnight or this rule is disabled.');
    if(losingHit)blockers.push('Daily losing-trade limit locked. No new buys until New York midnight or this rule is disabled.');
    return {day:t.day,marketPnl,dayPnl,realizedMarket:t.marketStats.pnl,realizedDay:t.dayStats.pnl,
      losers:t.dayStats.losers,completed:t.dayStats.completed,marketHit:!!marketHit,dayHit:!!dayHit,
      losingHit:!!losingHit,blockers,allowed:!blockers.length};
  }
  // Event books contain YES/NO bids. The opposite bid implies the ask.
  // API arrays may be ascending or descending: never rely on their order.
  function parseBook(data,ticker,ts){
    const source=data?.orderbook_fp;
    if(!source||!Array.isArray(source.yes_dollars)||!Array.isArray(source.no_dollars))
      throw new Error('Fixed-point event orderbook unavailable.');
    const parse=rows=>rows.map(row=>{
      if(!Array.isArray(row)||row.length<2)throw new Error('Invalid depth level.');
      const price=Number(row[0])*100,qty=Number(row[1]);
      if(!Number.isFinite(price)||price<=0||price>=100||!Number.isFinite(qty)||qty<=0)
        throw new Error('Invalid depth price or quantity.');
      return {price,qty};
    }).sort((a,b)=>b.price-a.price);
    return {ticker,ts,yes:parse(source.yes_dollars),no:parse(source.no_dollars),error:null};
  }
  function entryFilters(s,q,m,book,side,count,market,now){
    const checks=[],up=side==='UP',ask=up?q?.upAsk:q?.downAsk,bid=up?q?.upBid:q?.downBid;
    const spread=Number.isFinite(ask)&&Number.isFinite(bid)?ask-bid:null;
    checks.push({name:'Bid–ask spread',enabled:s.spreadEnabled,
      passed:quoteFresh(q,market,now)&&spread!==null&&spread>=0&&spread<=s.maxSpread+1e-9,
      detail:spread===null?'No bid/ask quote.':`${spread.toFixed(2)}¢ / maximum ${s.maxSpread}¢`});
    const validBook=!!book&&!!market&&book.ticker===market.ticker&&Number.isFinite(book.ts)&&now>=book.ts&&now-book.ts<=5000&&!book.error;
    const bids=validBook?(up?book.yes:book.no):[],opp=validBook?(up?book.no:book.yes):[];
    const asks=opp.map(x=>({price:100-x.price,qty:x.qty})).sort((a,b)=>a.price-b.price);
    const bestBid=bids[0]?.price,bestAsk=asks[0]?.price;
    // Cover the actual order's tolerance as well as the editable depth range.
    const buyMax=Math.min(ask+s.depthTolerance,ask+(q?._buySlippage??s.depthTolerance));
    const sellMin=Math.max(bid-s.depthTolerance,bid-(q?._buySlippage??s.depthTolerance));
    const buyDepth=asks.filter(x=>x.price<=buyMax+1e-9).reduce((n,x)=>n+x.qty,0);
    const sellDepth=bids.filter(x=>x.price>=sellMin-1e-9).reduce((n,x)=>n+x.qty,0);
    const need=count*s.depthCoverage;
    const depthPassed=validBook&&Number.isFinite(bestBid)&&Number.isFinite(bestAsk)&&
      bestAsk>=bestBid&&Math.abs(bestAsk-ask)<=1.01&&Math.abs(bestBid-bid)<=1.01&&
      count>0&&buyDepth+1e-9>=need&&sellDepth+1e-9>=need;
    checks.push({name:'Displayed depth',enabled:s.depthEnabled,passed:!!depthPassed,
      detail:!validBook?(book?.error||'Fresh matching orderbook required.'):
        `Buy ${buyDepth.toFixed(2)} / sell ${sellDepth.toFixed(2)} contracts; need ${need.toFixed(2)} each.`,
      buyDepth,sellDepth,required:need});
    const venues=(m?.venues||[]).filter(v=>v.fresh&&Number.isFinite(v.price)&&
      Number.isFinite(v.ageMs)&&v.ageMs>=0&&v.ageMs<=s.maxFeedAge*1000);
    const cb=venues.find(v=>v.name==='Coinbase');
    const gap=venues.length>=2?Math.max(...venues.map(v=>v.price))-Math.min(...venues.map(v=>v.price)):null;
    checks.push({name:'Feed age / disagreement',enabled:s.feedEnabled,
      passed:m?.ready===true&&!!cb&&venues.length>=2&&gap<=s.maxVenueGap+1e-9&&
        quoteFresh(q,market,now)&&now-q.ts<=s.maxFeedAge*1000,
      detail:gap===null?'Need Coinbase and another venue within the age limit.':
        `${venues.length} recent venues; price range $${gap.toFixed(2)} / maximum $${s.maxVenueGap}.`});
    return {side,checks,allowed:checks.every(c=>!c.enabled||c.passed),
      blockers:checks.filter(c=>c.enabled&&!c.passed).map(c=>`${c.name}: ${c.detail}`)};
  }
  function confirm(previous,s,{key,now,rawPassed,filtersPassed,eligible,lastSellAt,running}){
    const state=previous?.key===key&&previous.afterSellAt===lastSellAt?
      {...previous}:{key,afterSellAt:lastSellAt,since:null,last:null,resetSeen:false};
    const continuity=state.last!=null&&now>=state.last&&now-state.last<=3500;
    if(!continuity){state.since=null;state.resetSeen=false;}
    state.last=now;
    if(!running||!eligible){state.since=null;state.resetSeen=false;}
    else if(!rawPassed){state.resetSeen=true;state.since=null;}
    const freshRequired=s.freshReentryEnabled&&lastSellAt!=null;
    const readyCross=!freshRequired||state.resetSeen;
    if(!running||!eligible||!rawPassed||!filtersPassed||!readyCross)state.since=null;
    else if(state.since==null)state.since=now;
    const requiredMs=s.confirmEnabled?s.confirmSeconds*1000:0;
    const elapsedMs=state.since==null?0:Math.max(0,now-state.since);
    const passed=running&&eligible&&rawPassed&&filtersPassed&&readyCross&&elapsedMs>=requiredMs;
    return {state,passed,elapsedMs,requiredMs,waitingForReset:!!(freshRequired&&!readyCross),
      reason:!running?'Bot stopped.':!eligible?'Entry eligibility or safety limit blocked.':
        !rawPassed?'Waiting for the selected buy signal.':!filtersPassed?'Entry filter blocked.':
        !readyCross?'After cooldown, waiting for the old signal to turn off before a new signal.':
        !passed?`Entry confirmation ${(elapsedMs/1000).toFixed(1)} / ${requiredMs/1000}s.`:'Safety entry requirements pass.'};
  }
  return {DEFAULTS,LIMITS,NEW_KEYS,validate,forBackend,nowOnlyEntry,profitExit,dayKey,totals,recordResult,hydrate,quoteFresh,mark,lossExit,limits,parseBook,entryFilters,confirm};
});
