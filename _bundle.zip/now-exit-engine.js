(function(root,factory){
  const api=factory(typeof module==='object'&&module.exports?require('./low-high-spread'):root.LowHighSpread);
  if(typeof module==='object'&&module.exports)module.exports=api;
  else root.NowExit=api;
})(typeof globalThis!=='undefined'?globalThis:this,function(Spread){
  'use strict';
  const DEFAULTS={enabled:false};
  for(const p of ['up','down']){
    DEFAULTS[p+'Enabled']=false;
    for(const kind of ['Low','High']){
      const k=p+kind;
      Object.assign(DEFAULTS,{[k+'Enabled']:false,[k+'Seconds']:0,[k+'Cooldown']:0});
      for(const source of ['Target','Kalshi','Now','Spread'])
        Object.assign(DEFAULTS,{[k+'Use'+source]:false,[k+source+'Level']:null});
    }
  }
  Object.freeze(DEFAULTS);
  const number=raw=>{
    if(!['number','string'].includes(typeof raw)||String(raw).trim()==='')return NaN;
    const text=String(raw).trim().replace(/^[\u2212\u2013\u2014\uFE63\uFF0D]/,'-');
    return /^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:e[+-]?\d+)?$/i.test(text)?Number(text):NaN;
  };
  function validate(input={},forApply=false){
    if(!input||typeof input!=='object'||Array.isArray(input))throw Error('Sell monitor settings must be an object.');
    for(const k of Object.keys(input))if(!Object.hasOwn(DEFAULTS,k))throw Error('Unknown sell monitor option: '+k);
    const c={};
    for(const [k,fallback]of Object.entries(DEFAULTS)){
      const v=Object.hasOwn(input,k)?input[k]:fallback;
      if(typeof fallback==='boolean'){
        if(typeof v!=='boolean')throw Error(k+': use checked or unchecked.');
        c[k]=v;
      }else if(k.endsWith('Level')&&(v==null||v===''))c[k]=null;
      else{
        const n=number(v),lo=k.endsWith('Seconds')||k.endsWith('Cooldown')?0:-100000,
          hi=k.endsWith('Seconds')||k.endsWith('Cooldown')?300:100000;
        if(!Number.isFinite(n)||n<lo||n>hi)throw Error(k+`: enter a number from ${lo} to ${hi}.`);
        c[k]=n;
      }
    }
    if(forApply&&c.enabled){
      if(!c.upEnabled&&!c.downEnabled)throw Error('Choose at least one side for LOW/HIGH selling, or turn the sell monitor off.');
      for(const p of ['up','down'])if(c[p+'Enabled']){
        if(!c[p+'LowEnabled']&&!c[p+'HighEnabled'])throw Error(p.toUpperCase()+': enable a LOW or HIGH sell group.');
        for(const kind of ['Low','High'])if(c[p+kind+'Enabled']){
          const sources=['Target','Kalshi','Now','Spread'].filter(s=>c[p+kind+'Use'+s]);
          if(!sources.length)throw Error(p.toUpperCase()+' '+kind.toUpperCase()+': check at least one SELL condition.');
          for(const s of sources)if(!Number.isFinite(c[p+kind+s+'Level']))
            throw Error(p.toUpperCase()+' '+kind.toUpperCase()+': enter a signed '+s+' SELL level.');
        }
      }
    }
    for(const p of ['up','down'])for(const s of ['Target','Kalshi','Now','Spread'])
      if(c[p+'LowEnabled']&&c[p+'HighEnabled']&&c[p+'LowUse'+s]&&c[p+'HighUse'+s]&&
        Number.isFinite(c[p+'Low'+s+'Level'])&&Number.isFinite(c[p+'High'+s+'Level'])&&
        c[p+'Low'+s+'Level']>=c[p+'High'+s+'Level'])
        throw Error(p.toUpperCase()+': LOW '+s+' SELL level must be below HIGH.');
    return c;
  }
  function evaluate(previous,config,m,side,key,now,running,index=null){
    const c=validate(config),p=side==='UP'?'up':'down',enabled=c.enabled&&c[p+'Enabled'];
    const identity=key+':'+side+':'+JSON.stringify(c);
    const state=previous?.key===identity?structuredClone(previous):{key:identity,last:null,low:null,high:null};
    if(!running||state.last==null||now<state.last||now-state.last>3500)
      for(const k of Object.keys(state))if(k!=='key'&&k!=='last')state[k]=null;
    state.last=now;
    const kalshiReady=index?.fresh===true&&index?.status==='live'&&
      ['authenticated_index','public_chart'].includes(index.sourceKind)&&
      Number.isFinite(index.price)&&index.price>0&&Number.isFinite(index.nowDiff)&&
      Number.isFinite(index.sourceTime)&&now-index.sourceTime<=5000&&index.sourceTime-now<=1000;
    const kalshi=kalshiReady?Math.sign(index.nowDiff)*Math.round((Math.abs(index.nowDiff)+Number.EPSILON)*100)/100:null;
    const groups=['Low','High'].map(kind=>{
      const k=p+kind,slot=kind.toLowerCase(),low=kind==='Low';
      const checks=[
        ['Target','All vs target',m?.targetDiff,m?.ready===true],
        ['Kalshi','Kalshi Now vs target',kalshi,kalshiReady],
        ['Now','Coinbase Now vs target',m?.nowDiff,m?.ready===true],
        ['Spread','Exchange spread',m?.spread,m?.ready===true],
      ].map(([source,name,value,fresh])=>{
        const threshold=c[k+source+'Level'],ready=fresh&&Number.isFinite(value)&&Number.isFinite(threshold);
        return {source,name,value,threshold,enabled:c[k+'Use'+source],ready,op:low?'≤':'≥',
          passed:ready&&(low?value<=threshold:value>=threshold)};
      });
      const selected=checks.filter(x=>x.enabled),passed=c[k+'Enabled']&&selected.length>0&&selected.every(x=>x.passed);
      if(!enabled||!running||!passed)state[slot]=null;
      else if(state[slot]==null)state[slot]=now;
      const elapsedMs=state[slot]==null?0:Math.max(0,now-state[slot]),requiredMs=c[k+'Seconds']*1000;
      const cooldownMs=Math.max(0,c[k+'Cooldown']*1000);
      if(!enabled||!running||!passed||elapsedMs<requiredMs)state[k+'Cooldown']=null;
      else if(state[k+'Cooldown']==null)state[k+'Cooldown']=now;
      const cooldownElapsedMs=state[k+'Cooldown']==null?0:Math.max(0,now-state[k+'Cooldown']);
      const cooldownConfirmed=cooldownMs===0?passed:passed&&cooldownElapsedMs>=cooldownMs;
      const freshNow=checks.filter(x=>x.enabled).every(x=>x.ready);
      return {kind,enabled:c[k+'Enabled'],checks,passed,ready:selected.length>0&&selected.every(x=>x.ready),
        elapsedMs,requiredMs,cooldownMs,cooldownElapsedMs,freshNow,
        confirmed:enabled&&running&&passed&&elapsedMs>=requiredMs&&cooldownConfirmed&&freshNow};
    });
    const confirmed=groups.find(g=>g.confirmed),waiting=groups.find(g=>g.passed&&g.enabled);
    const action=!enabled?'INACTIVE':!running?'STOPPED':confirmed?'SELL':waiting?'EXIT_WAIT':'HOLD';
    const reason=!enabled?side+' uses its original regular sell rules.':!running?
      'Bot stopped: LOW/HIGH automatic sells are OFF. Your position remains open.':
      confirmed?side+' '+confirmed.kind.toUpperCase()+' SELL: every checked condition held for '+confirmed.requiredMs/1000+
        (confirmed.cooldownMs>0?'s plus a fresh '+confirmed.cooldownMs/1000+'s cooldown.':'s.') :
      waiting?side+' '+waiting.kind.toUpperCase()+' sell confirmation '+(waiting.elapsedMs/1000).toFixed(1)+
        ' / '+waiting.requiredMs/1000+'s'+(waiting.cooldownMs>0?', then cooldown '+
        (Math.max(0,waiting.cooldownMs-waiting.cooldownElapsedMs)/1000).toFixed(1)+'s left':'')+'.':
      'Waiting for a complete LOW or HIGH '+side+' SELL group. Missing data blocks only the group needing it.';
    return {state,enabled,side,groups,action,reason,exitKind:confirmed?'low-high':null};
  }
  return {DEFAULTS,number,validate,evaluate,forBackend:Spread.forBackend};
});
