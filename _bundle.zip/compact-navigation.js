(function(root){
  'use strict';
  const $=id=>document.getElementById(id),main=$('main');
  function reveal(el){
    for(let p=el?.parentElement;p;p=p.parentElement)if(p.tagName==='DETAILS')p.open=true;
    return el;
  }
  function category(id,title,description,nodes){
    const d=document.createElement('details');d.id=id;d.className='nav-category panel';
    const summary=document.createElement('summary'),heading=document.createElement('span');
    heading.textContent=title;summary.append(heading);
    const badge=document.createElement('span');badge.className='category-status';badge.id=id+'Status';summary.append(badge);
    const content=document.createElement('div');content.className='category-body';
    const note=document.createElement('p');note.className='small muted';note.textContent=description;content.append(note);
    for(const node of nodes.filter(Boolean))content.append(node);
    d.append(summary,content);main.append(d);return d;
  }
  const lowHigh=document.querySelector('.low-high-sell'),entry=document.querySelector('.now-entry-monitor');
  const workspace=document.querySelector('.workspace'),trading=document.querySelector('.trading'),decision=document.querySelector('.decision');
  const overview=document.createElement('div');overview.className='control-overview';
  if(trading)overview.append(trading);if(decision)overview.append(decision);
  main.insertBefore(overview,workspace);
  category('categoryEntries','Entry settings','LOW/HIGH sources, signed thresholds and conditional buys.',[entry]);
  category('categoryExits','Exit settings','Independent UP/DOWN LOW/HIGH, trailing-line and candle exits.',[lowHigh,$('lineTrailSection'),$('candleReversalSection')]);
  const legacy=$('legacyRulesDisclosure');
  if(legacy){legacy.classList.add('nav-category');main.append(legacy);}
  category('categoryRisk','Risk & profit trails','Current, Staged, Volatility, loss limits, sizing and buy filters.',[$('safetySection')]);
  category('categoryVolatility','Volatility observations','The three observation switches only display and log readings. The separate Skip choppy buys filter below can affect automatic entries when enabled.',[$('volatilityObservations'),$('chopBuyFilter')]);
  category('categoryHistory','Results & activity','Recorded trades and the activity log. Clearing displays does not reset risk limits.',
    [document.querySelector('.results'),document.querySelector('.activity')]);
  if(workspace&&!workspace.querySelector('input,button,select'))workspace.remove();
  const checks=$('legacySellChecks');
  if(checks){
    const d=document.createElement('details'),s=document.createElement('summary');
    d.className='monitor-details';s.textContent='Checked-rule exit details';checks.before(d);d.append(s,checks);
  }
  const chart=document.querySelector('.now-chart'),summaries=[...chart.querySelectorAll('.trailing-summary')];
  if(summaries.length){
    const d=document.createElement('details'),s=document.createElement('summary');
    d.className='monitor-details';s.textContent='Chart overlays & exit status';summaries[0].before(d);d.append(s,...summaries);
    const note=chart.querySelector(':scope > .micro-note');if(note)d.append(note);
  }
  for(const field of [...document.querySelectorAll('#settingsDialog .dialog-body > fieldset')]){
    const d=document.createElement('details'),s=document.createElement('summary');
    d.className='settings-category';s.textContent=field.querySelector('legend')?.textContent||'Settings';
    d.open=field.classList.contains('profile-box');field.before(d);d.append(s,field);
  }
  const nav=document.createElement('nav');nav.className='quick-nav';nav.setAttribute('aria-label','Dashboard categories');
  for(const [id,label]of [['nowChartPlot','Charts'],['categoryEntries','Entries'],['categoryExits','Exits'],
    ['categoryRisk','Risk'],['categoryVolatility','Volatility'],['categoryHistory','History']]){
    const b=document.createElement('button');b.type='button';b.textContent=label;
    b.onclick=()=>{const el=id==='nowChartPlot'?$(id).closest('.now-chart'):$(id);
      reveal(el);if(el.tagName==='DETAILS')el.open=true;el.scrollIntoView({behavior:'smooth',block:'start'});};
    nav.append(b);
  }
  const stop=document.createElement('button');stop.id='quickStop';stop.type='button';stop.className='quick-stop';
  stop.textContent='Stop automation';stop.disabled=true;
  stop.onclick=()=>root.dispatchEvent(new Event('spread-guard-stop'));
  nav.append(stop);document.querySelector('.top').after(nav);
  function render(state,disconnected,pending){
    if(!state)return;
    stop.disabled=disconnected||pending;
    const c=state.settings.candleReversal||{},s=state.settings.safety||{},l=state.settings.lineTrail||{};
    $('categoryEntriesStatus').textContent=state.settings.nowEntry?.enabled?'LOW/HIGH ON':'Configured';
    $('categoryExitsStatus').textContent='Line UP '+(l.upEnabled?'ON':'OFF')+' / DOWN '+(l.downEnabled?'ON':'OFF')+
      ' · Candles UP '+(c.upEnabled?'ON':'OFF')+' / DOWN '+(c.downEnabled?'ON':'OFF');
    $('categoryRiskStatus').textContent='Trail UP '+(s.upProfitTrailEnabled?'ON':'OFF')+' / DOWN '+(s.downProfitTrailEnabled?'ON':'OFF');
    const count=state.results?.trades??state.results?.count??0;
    $('categoryHistoryStatus').textContent=count+(count===1?' trade':' trades');
  }
  root.CompactNavigation={reveal,render};
})(globalThis);
