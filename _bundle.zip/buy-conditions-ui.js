(function(root){
  'use strict';
  root.BuyConditionsUI={create(save){
    const C=root.BuyConditions,$=id=>document.getElementById(id),sides=['up','down'];
    let saved=null,drafts=null,state=null,applying=null,locks=true,offline=false;
    const conflict={up:false,down:false};
    const clone=x=>JSON.parse(JSON.stringify(x));
    const escape=x=>String(x).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
    const same=(a,b)=>{try{return JSON.stringify(C.validate({up:a}).up)===JSON.stringify(C.validate({up:b}).up);}catch{return JSON.stringify(a)===JSON.stringify(b);}};
    function message(p,text,error=false){
      $('bc-'+p+'-feedback').textContent=text;
      $('bc-'+p+'-feedback').className='feedback '+(error?'error':'success');
    }
    function draw(p){
      const d=drafts[p],prefix='bc-'+p+'-',side=p.toUpperCase();
      $('buyConditions-'+p).innerHTML=
        `<h3>${side} conditional spread alternative</h3>`+
        `<p class="micro-note">Optional: normal Exchange spread passes OR these conditions pass. All other checked entry sources and existing movement, freshness, volume, timing and risk guards still apply. Requires saved low/high mode and a checked Exchange spread for this side. Not used for price-trigger buying.</p>`+
        `<details class="buy-walkthroughs"><summary>How to use ${side} conditions</summary>`+
        `<p class="micro-note">First save your normal ${side} low/high buy settings with Exchange spread checked. Then Add condition, choose a source and ≤ or ≥, type a signed dollar value, enable this alternative and Apply ${side} conditions. Nothing starts automatically.</p>`+
        `<p class="micro-note">${p==='up'?'Example: normal spread requires ≥ +40 but is +25. Add All vs target ≥ +100. At +100 or higher, this alternative can satisfy the spread requirement; below +100 it cannot.':'Example: normal spread requires ≤ -40 but is -25. Add All vs target ≤ -100. At -100 or lower, this alternative can satisfy the spread requirement; at -99 it cannot.'} Every other checked condition must still pass.</p>`+
        `<p class="micro-note">Time example: choose Match ALL, add All vs target ${p==='up'?'≥ 100':'≤ -100'} AND Time left in market ≤ 5 minutes. Both must pass for this alternative. Use ≥ 2 as another row to require at least 2 minutes left; with ≤ 5 this makes a 2-to-5-minute window. Decimal minutes are allowed: 0.5 = 30 seconds. Missing, not-yet-open or expired market time blocks the alternative even with ANY. ANY lets a passing time row satisfy the alternative by itself. Time rows limit only this alternative: the normal spread path can still qualify outside them. Use the separate entry time window to restrict every buy path. Final-five-second, timed cash-out and all other existing guards still apply; exits are unchanged.</p>`+
        `<p class="micro-note">ALL needs every row; ANY needs at least one. Every listed source in every enabled alternative must have fresh data, even if normal spread passes. Missing data blocks buying in both directions so an unknown opposite-side signal cannot hide ambiguity. With fresh data, the normal spread path remains available. ≤ includes equality and lower signed values; ≥ includes equality and higher values. These are comparison levels, not crossing detectors. Up to 10 rows per side. Delete removes a draft row; Apply saves it. Reload discards only this side's conditional draft. Disable and Apply before removing all rows or switching away from low/high buying. No profitability or low-risk claim is established.</p></details>`+
        `<p id="${prefix}compatibility" class="notice small" hidden>NOT ACTIVE. An approved backend restart is required; these controls are locked.</p>`+
        `<p id="${prefix}time-compatibility" class="notice small" hidden>Time left in market is NOT ACTIVE until an approved backend restart. Existing price-source conditions remain available.</p>`+
        `<label class="rule-toggle"><input id="${prefix}enabled" type="checkbox"${d.enabled?' checked':''}>Enable ${side} conditional alternative</label>`+
        `<label class="field-row" for="${prefix}match">Combine conditions<select id="${prefix}match"><option value="all"${d.match==='all'?' selected':''}>Match ALL conditions (AND)</option><option value="any"${d.match==='any'?' selected':''}>Match ANY condition (OR)</option></select></label>`+
        `<div id="${prefix}rows">${d.rules.map((r,i)=>`<div class="buy-condition-row" data-row="${i}">`+
          `<label>If<select id="${prefix}${i}-source" data-field="source" aria-label="${side} condition ${i+1} source">`+
          Object.entries(C.SOURCES).map(([k,v])=>`<option value="${k}"${r.source===k?' selected':''}>${v}</option>`).join('')+`</select></label>`+
          `<label>Comparison<select id="${prefix}${i}-op" data-field="op" aria-label="${side} condition ${i+1} comparison"><option value="lte"${r.op==='lte'?' selected':''}>Less than or equal to (≤)</option><option value="gte"${r.op==='gte'?' selected':''}>Greater than or equal to (≥)</option></select></label>`+
          `<label><span data-value-label>Signed value ($)</span><input id="${prefix}${i}-value" data-field="value" type="text" inputmode="text" autocomplete="off" value="${escape(r.value)}" placeholder="e.g. -100" aria-label="${side} condition ${i+1} signed value"></label>`+
          `<button type="button" data-delete="${i}" aria-label="Delete ${side} condition ${i+1}">Delete</button></div>`).join('')}</div>`+
        `<div class="rules-tools"><button type="button" id="${prefix}add">Add condition</button><button type="button" id="${prefix}apply">Apply ${side} conditions</button><button type="button" id="${prefix}reload">Reload ${side} conditions</button></div>`+
        `<p id="${prefix}status" class="micro-note" role="status"></p><p id="${prefix}live" class="micro-note" role="status"></p><p id="${prefix}time-live" class="micro-note" role="status" hidden></p><p id="${prefix}feedback" class="feedback" role="status"></p>`;
      update();
    }
    function update(){
      if(!saved)return;
      for(const p of sides){
        if(!$('bc-'+p+'-status'))continue;
        const supported=state?.features?.conditionalSpreadBuys===true,node=$('buyConditions-'+p);
        const timeSupported=state?.features?.marketTimeBuyConditions===true;
        const hasTime=[...drafts[p].rules,...saved[p].rules].some(r=>r.source==='TimeLeft');
        node.querySelectorAll('input,select,button').forEach(n=>n.disabled=locks||!!applying);
        node.querySelectorAll('option[value="TimeLeft"]').forEach(n=>n.disabled=!timeSupported);
        node.querySelectorAll('[data-row]').forEach(row=>{
          const i=Number(row.dataset.row),isTime=drafts[p].rules[i]?.source==='TimeLeft';
          row.querySelector('[data-value-label]').textContent=isTime?'Time left (minutes)':'Signed value ($)';
          const input=row.querySelector('[data-field="value"]');
          input.inputMode=isTime?'decimal':'text';
          input.placeholder=isTime?'e.g. 5 or 0.5':'e.g. -100';
          input.setAttribute('aria-label',p.toUpperCase()+' condition '+(i+1)+(isTime?' minutes remaining':' signed value'));
        });
        $('bc-'+p+'-compatibility').hidden=supported;
        $('bc-'+p+'-time-compatibility').hidden=timeSupported;
        $('bc-'+p+'-add').disabled=locks||!!applying||drafts[p].rules.length>=10;
        $('bc-'+p+'-apply').disabled=locks||!!applying||conflict[p]||same(saved[p],drafts[p])||hasTime&&!timeSupported;
        $('bc-'+p+'-status').textContent=conflict[p]?'Saved conditions changed elsewhere. Reload this side; its draft is preserved until then.':
          (same(saved[p],drafts[p])?'Saved · ':'Unsaved draft · ')+(saved[p].enabled?'alternative ON':'alternative OFF');
        const serverNow=Number.isFinite(state?.serverTime)?state.serverTime:NaN;
        const result=C.evaluate(saved,state?.feeds,state?.kalshiIndex,p.toUpperCase(),serverNow,state?.market);
        const timeResult=C.evaluate({[p]:{enabled:true,match:'all',rules:[{source:'TimeLeft',op:'gte',value:0}]}},
          state?.feeds,state?.kalshiIndex,p.toUpperCase(),serverNow,state?.market);
        const timeCheck=timeResult.checks[0];
        $('bc-'+p+'-time-live').hidden=!hasTime;
        $('bc-'+p+'-time-live').textContent=offline||!timeCheck?.ready?'Market time unknown or unavailable.':
          'Last server-observed time left: '+timeCheck.actual.toFixed(3)+' minutes. Units here are minutes, not dollars.';
        $('bc-'+p+'-live').textContent=offline?'Connection lost. Conditional signal state and freshness are unknown.':
          !supported?'Preview only; the running backend cannot use this alternative.':
          !saved[p].enabled?'Saved alternative is OFF.':
          (result.ready?(result.passed?'Saved alternative: MET. ':'Saved alternative: NOT MET. '):'Saved alternative: waiting for fresh data. ')+
          result.description+'. This is not buy permission; every remaining guard must pass.';
      }
    }
    for(const p of sides){
      const node=$('buyConditions-'+p);
      node.addEventListener('input',e=>{
        if(!drafts||locks||applying)return;
        const field=e.target.dataset.field,row=e.target.closest('[data-row]');
        if(field&&row)drafts[p].rules[Number(row.dataset.row)][field]=e.target.value;
        else if(e.target.id==='bc-'+p+'-enabled')drafts[p].enabled=e.target.checked;
        else if(e.target.id==='bc-'+p+'-match')drafts[p].match=e.target.value;
        update();
      });
      node.addEventListener('click',async e=>{
        const target=e.target.closest('button');if(!target||locks||applying||!drafts)return;
        const id=target.id;
        if(target.hasAttribute('data-delete')){drafts[p].rules.splice(Number(target.dataset.delete),1);draw(p);$('bc-'+p+'-add').focus();}
        else if(id==='bc-'+p+'-add'){
          if(drafts[p].rules.length>=10)return;
          drafts[p].rules.push({source:'Target',op:p==='up'?'gte':'lte',value:''});draw(p);
          $('bc-'+p+'-'+(drafts[p].rules.length-1)+'-value').focus();
        }else if(id==='bc-'+p+'-reload'){drafts[p]=clone(saved[p]);conflict[p]=false;draw(p);message(p,'Reloaded saved '+p.toUpperCase()+' conditions.');}
        else if(id==='bc-'+p+'-apply'){
          try{
            const next=C.assertUsage({...saved,[p]:drafts[p]},state.settings.nowEntry),expected=clone(saved);
            applying=p;update();await save(next,expected);
            drafts[p]=clone(next[p]);saved[p]=clone(next[p]);conflict[p]=false;draw(p);
            message(p,'Saved '+p.toUpperCase()+' conditions. Other-side drafts kept. Trading was not started.');
          }catch(err){message(p,err.message,true);}
          finally{applying=null;update();}
        }
      });
    }
    return {
      render(next,{pending=false,disconnected=false}={}){
        state=next;
        offline=disconnected;
        locks=!!(pending||disconnected||next.running||next.armedLive||next.busy||
          ['BUYING','SELLING','MANUAL'].includes(next.phase)||!next.features?.conditionalSpreadBuys);
        const incoming=C.validate(next.settings.buyConditions);
        if(!saved){saved=incoming;drafts=clone(saved);for(const p of sides)draw(p);}
        else{
          const redraw=[];
          for(const p of sides)if(!same(saved[p],incoming[p])){
            if(applying===p||same(saved[p],drafts[p])){drafts[p]=clone(incoming[p]);redraw.push(p);}
            else conflict[p]=true;
          }
          saved=incoming;for(const p of redraw)draw(p);
        }
        update();
      },
      dirty:()=>!!saved&&sides.some(p=>!same(saved[p],drafts[p])),
      reload(){if(saved){drafts=clone(saved);for(const p of sides){conflict[p]=false;draw(p);}}}
    };
  }};
})(globalThis);
