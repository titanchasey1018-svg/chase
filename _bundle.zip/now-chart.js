(function(root){
  'use strict';
  const NS='http://www.w3.org/2000/svg';
  const money=n=>Number.isFinite(n)?`${n>=0?'+':'−'}$${Math.abs(n).toFixed(2)}`:'—';
  function el(name,attrs={},text){
    const n=document.createElementNS(NS,name);
    for(const[k,v]of Object.entries(attrs))n.setAttribute(k,String(v));
    if(text!=null)n.textContent=text;return n;
  }
  function draw(container,readout,points,own,minutes,now,trailing,staircase,entryProtection,salePoints=[],rebuy={},buyPoints=[],view=null,lineTrail=null){
    const bounded=view&&Number.isFinite(view.start)&&Number.isFinite(view.end)&&
      view.end>view.start&&view.end<=now;
    const windowStart=bounded?view.start:now-minutes*60000,windowEnd=bounded?view.end:now;
    const overlays=!(bounded&&!view.live);
    if(own&&Number.isFinite(own.startedAt)&&own.startedAt>windowEnd)own=null;
    if(bounded&&!view.live){trailing=null;staircase=null;entryProtection=null;lineTrail=null;rebuy={};}
    const data=(points||[]).filter(p=>p.t>=windowStart&&p.t<=windowEnd);
    const sales=salePoints.filter(s=>Number.isFinite(s.now)&&s.at>=windowStart&&s.at<=windowEnd);
    // The latest completed sale is the reference, not the last visible marker.
    // A missing fresh Now on that sale must not expose an older false anchor.
    const lastCompleted=salePoints.filter(s=>s.completed&&s.at<=windowEnd).at(-1);
    const sold=Number.isFinite(lastCompleted?.now)?lastCompleted:null;
    const buysByPoint=new Map();
    for(const b of buyPoints)if(Number.isFinite(b.now)&&Number.isFinite(b.at)&&
      b.at>=windowStart&&b.at<=windowEnd)buysByPoint.set(`${b.at}:${b.side}`,b);
    if(Number.isFinite(own?.entryNow)&&Number.isFinite(own.startedAt)){
      const key=`${own.startedAt}:${own.side}`;
      buysByPoint.set(key,{...buysByPoint.get(key),id:own.tradeId||buysByPoint.get(key)?.id||key,
        at:own.startedAt,now:own.entryNow,side:own.side,price:own.avg,active:true});
    }
    const buys=[...buysByPoint.values()].sort((a,b)=>a.at-b.at);
    const referenceBuy=own?(Number.isFinite(own.entryNow)?{now:own.entryNow}:null):
      Number.isFinite(lastCompleted?.buy?.now)?lastCompleted.buy:null;
    const levels=Object.entries(rebuy).filter(([,r])=>r.enabled&&Number.isFinite(r.level));
    const activeSale=document.activeElement?.getAttribute('data-sale-at');
    const activeBuy=document.activeElement?.getAttribute('data-buy-id');
    const w=Math.max(300,container.clientWidth||900),h=260,L=70,R=w-14,T=16,B=224;
    const svg=el('svg',{viewBox:`0 0 ${w} ${h}`,role:'img',tabindex:0,
      ...(bounded?{'data-window-start':windowStart,'data-window-end':windowEnd}:{}),
      'aria-label':`Now versus target over ${minutes} minutes${bounded&&!view.live?', historical review':''}. Arrow keys inspect observed readings. BUY triangles and SOLD diamonds are selectable.`});
    svg.append(el('title',{},'Observed Now with recorded BUY and SOLD markers, optional rebuy levels and position exit levels'));
    const focused=document.activeElement===container.firstElementChild;
    container.replaceChildren(svg);
    if(focused)svg.focus({preventScroll:true});
    const numbers=data.flatMap(p=>[p.now,...(overlays&&own&&p.position===own.startedAt?[p.best,p.exit,p.stair,p.entryStop,p.line]:[])]).filter(Number.isFinite);
    numbers.push(...sales.map(s=>s.now),...levels.map(([,r])=>r.level));
    numbers.push(...buys.map(b=>b.now));
    if(referenceBuy)numbers.push(referenceBuy.now);
    if(sold)numbers.push(sold.now);
    if(Number.isFinite(own?.entryNow))numbers.push(own.entryNow);
    if(own&&trailing)numbers.push(...[trailing.best,trailing.level].filter(Number.isFinite));
    if(own&&staircase)numbers.push(...[staircase.level].filter(Number.isFinite));
    if(own&&entryProtection)numbers.push(...[entryProtection.level].filter(Number.isFinite));
    if(own&&lineTrail)numbers.push(...[lineTrail.level].filter(Number.isFinite));
    if(!data.some(p=>Number.isFinite(p.now))&&!sales.length&&!sold&&!buys.length&&!referenceBuy){
      svg.append(el('text',{x:w/2,y:125,'text-anchor':'middle',class:'chart-label'},'Waiting for fresh observed prices'));
      readout.textContent='No chart data yet. Samples begin when prices are ready.';return;
    }
    const min=Math.min(0,...numbers),max=Math.max(0,...numbers),pad=Math.max(5,(max-min)*.12);
    const lo=min-pad,hi=max+pad;
    const start=bounded?windowStart:Math.max(windowStart,Math.min(data[0]?.t??now,...sales.map(s=>s.at),...buys.filter(b=>!b.active).map(b=>b.at))-1000);
    const end=bounded?windowEnd:Math.max(start+1000,now);
    const x=t=>L+(t-start)/(end-start)*(R-L),y=v=>B-(v-lo)/(hi-lo)*(B-T);
    for(let i=0;i<=4;i++){
      const v=lo+(hi-lo)*i/4,yy=y(v);
      svg.append(el('line',{x1:L,x2:R,y1:yy,y2:yy,class:'chart-grid'}));
      svg.append(el('text',{x:L-8,y:yy+4,'text-anchor':'end',class:'chart-label'},
        `${v>=0?'+':'−'}${Math.abs(v).toFixed(0)}`));
    }
    svg.append(el('line',{x1:L,x2:R,y1:y(0),y2:y(0),class:'chart-zero'}));
    for(const [t,anchor]of [[start,'start'],[(start+end)/2,'middle'],[end,'end']])
      svg.append(el('text',{x:x(t),y:247,'text-anchor':anchor,class:'chart-label'},
        new Date(t).toLocaleTimeString([],{hour12:false,hour:'2-digit',minute:'2-digit',second:'2-digit'})));
    for(const [key,cls]of [['now','chart-now'],['best','chart-best'],['exit','chart-exit'],['stair','chart-stair'],['entryStop','chart-entry-stop'],['line','chart-line-trail']]){
      let path='',prev=null;
      for(const p of data){
        const v=key==='now'||overlays&&own&&p.position===own.startedAt?p[key]:null;
        if(!Number.isFinite(v)){prev=null;continue;}
        const continuous=prev&&p.t-prev.t<=3500;
        path+=continuous&&['stair','entryStop','line'].includes(key)?`H${x(p.t).toFixed(2)} V${y(v).toFixed(2)} `:
          `${continuous?'L':'M'}${x(p.t).toFixed(2)},${y(v).toFixed(2)} `;
        if(!continuous)svg.append(el('circle',{cx:x(p.t),cy:y(v),r:2,class:cls}));
        prev=p;
      }
      svg.append(el('path',{d:path,fill:'none',class:cls,'stroke-width':key==='now'?2.5:1.5,
        ...(key==='entryStop'?{'stroke-dasharray':'8 5'}:{})}));
    }
    if(referenceBuy){
      svg.append(el('line',{x1:L,x2:R,y1:y(referenceBuy.now),y2:y(referenceBuy.now),
        class:'chart-entry','stroke-dasharray':'3 5','data-testid':'buy-line','data-buy-now':referenceBuy.now}));
    }
    if(own&&trailing){
      for(const [v,cls]of [[trailing.best,'chart-best'],[trailing.level,'chart-exit']]){
        if(Number.isFinite(v))svg.append(el('line',{x1:x(Math.max(start,Number.isFinite(own.startedAt)?own.startedAt:start)),x2:R,
          y1:y(v),y2:y(v),class:cls,'stroke-width':1,opacity:.8}));
      }
    }
    if(own&&Number.isFinite(staircase?.level)){
      const last=data.filter(p=>p.position===own.startedAt&&Number.isFinite(p.stair)).at(-1);
      svg.append(el('line',{x1:x(last?.stair===staircase.level?last.t:now),x2:R,y1:y(staircase.level),y2:y(staircase.level),
        class:'chart-stair','stroke-width':1.5}));
      svg.append(el('circle',{cx:R,cy:y(staircase.level),r:2.5,class:'chart-stair'}));
    }
    if(own&&Number.isFinite(entryProtection?.level)){
      const last=data.filter(p=>p.position===own.startedAt&&Number.isFinite(p.entryStop)).at(-1);
      svg.append(el('line',{x1:x(last?.entryStop===entryProtection.level?last.t:now),x2:R,
        y1:y(entryProtection.level),y2:y(entryProtection.level),class:'chart-entry-stop',
        'stroke-width':2,'stroke-dasharray':'8 5','data-testid':'chart-entry-stop'}));
    }
    const labelYs=[];
    const levelLabel=(value,text,cls)=>{
      const yy=y(value),preferred=yy-6;
      const labelY=[preferred,yy+16,yy-24,yy+34,yy-42,yy+52,yy-60,yy+70]
        .find(v=>v>=T+12&&v<=B-3&&labelYs.every(other=>Math.abs(v-other)>=16))??T+12;
      labelYs.push(labelY);
      if(Math.abs(labelY-yy)>20)svg.append(el('line',{x1:R-8,x2:R-8,
        y1:yy,y2:labelY+3,class:cls,'stroke-width':.8}));
      svg.append(el('text',{x:R-4,y:labelY,'text-anchor':'end',class:cls+'-label'},text));
    };
    if(referenceBuy)levelLabel(referenceBuy.now,`BUY ${money(referenceBuy.now)}`,'chart-entry');
    if(own&&Number.isFinite(lineTrail?.level)){
      const last=data.filter(p=>p.position===own.startedAt&&Number.isFinite(p.line)).at(-1);
      svg.append(el('line',{x1:x(Math.max(start,last?.t??now)),x2:R,
        y1:y(lineTrail.level),y2:y(lineTrail.level),class:'chart-line-trail',
        'stroke-width':2,'stroke-dasharray':'6 4','data-testid':'trailing-line',
        'data-now-level':lineTrail.level}));
      svg.append(el('circle',{cx:R,cy:y(lineTrail.level),r:3,class:'chart-line-trail'}));
      levelLabel(lineTrail.level,`${lineTrail.side} LINE ${money(lineTrail.level)}`,'chart-line-trail');
    }
    const buyText=b=>`${new Date(b.at).toLocaleTimeString([],{hour12:false})} · BUY ${b.side==='yes'?'UP':'DOWN'} · recorded Now ${money(b.now)} at first-fill confirmation.`+
      (Number.isFinite(b.price)?` Entry average ${(b.price*100).toFixed(2)}¢.`:'')+
      ' Now is Coinbase minus target, not contract cost.'+(b.at<start?' Entry predates this window; point pinned at left edge.':'');
    for(const b of buys){
      const text=buyText(b),id=b.id||`${b.at}:${b.side}`;
      const buy=el('g',{tabindex:0,role:'button','aria-label':text,'data-testid':'buy-point','data-buy-id':id});
      buy.append(el('title',{},text));
      // When entry predates the selected range, keep its level inspectable.
      const xx=x(Math.max(start,Math.min(end,b.at))),yy=y(b.now);
      buy.append(el('circle',{cx:xx,cy:yy,r:14,fill:'transparent'}));
      buy.append(el('path',{d:`M${xx},${yy-7} L${xx+7},${yy+6} L${xx-7},${yy+6} Z`,class:'chart-buy-marker'}));
      const inspectBuy=()=>{delete container.dataset.inspectSale;delete container.dataset.inspectTime;
        container.dataset.inspectBuy=id;readout.textContent=text;};
      buy.addEventListener('click',inspectBuy);buy.addEventListener('focus',inspectBuy);
      buy.addEventListener('keydown',e=>{if(['Enter',' '].includes(e.key)){e.preventDefault();e.stopPropagation();inspectBuy();}});
      svg.append(buy);
      if(activeBuy===String(id))buy.focus({preventScroll:true});
    }
    if(!buys.length)delete container.dataset.inspectBuy;
    if(own&&Number.isFinite(staircase?.level))
      levelLabel(staircase.level,`BARRIER ${money(staircase.level)}`,'chart-stair');
    if(sold){
      svg.append(el('line',{x1:L,x2:R,y1:y(sold.now),y2:y(sold.now),class:'chart-sold',
        'stroke-width':1.8,'data-testid':'sold-line','data-sold-now':sold.now,'data-sale-at':sold.at}));
      levelLabel(sold.now,`SOLD ${money(sold.now)}`,'chart-sold');
    }
    for(const [side,r]of levels){
      svg.append(el('line',{x1:L,x2:R,y1:y(r.level),y2:y(r.level),class:'chart-rebuy','stroke-dasharray':side==='UP'?'8 4':'2 4',
        'data-testid':'rebuy-level-'+side}));
      levelLabel(r.level,`${side} rebuy ${r.direction==='above'?'≥':'≤'} ${money(r.level)}`,'chart-rebuy');
    }
    const saleText=s=>`${new Date(s.at).toLocaleTimeString([],{hour12:false})} · ${s.completed?'SOLD':'PARTIAL SELL'} ${s.side==='yes'?'UP':'DOWN'} ${s.count} · observed Now ${money(s.now)} · contract fill ${(s.price*100).toFixed(2)}¢. Recorded at confirmation, not exchange-time BTC.`;
    for(const s of sales){
      const exactX=x(s.at),exactY=y(s.now);
      const overlaps=buys.some(b=>Math.abs(x(Math.max(start,b.at))-exactX)<18&&Math.abs(y(b.now)-exactY)<18);
      const xx=overlaps?Math.max(L+7,Math.min(R-7,exactX+15)):exactX;
      const yy=overlaps?Math.max(T+7,Math.min(B-7,exactY-18)):exactY;
      if(overlaps){
        svg.append(el('line',{x1:exactX,x2:xx,y1:exactY,y2:yy,class:'chart-sold','stroke-width':1}));
        svg.append(el('circle',{cx:exactX,cy:exactY,r:2,class:'chart-sold-marker'}));
      }
      const g=el('g',{tabindex:0,role:'button','aria-label':saleText(s)+(overlaps?' Marker offset to avoid overlap; leader ends at exact value.':''),
        'data-sale-at':s.at,'data-testid':'sold-point'});
      g.append(el('title',{},saleText(s)));
      g.append(el('circle',{cx:xx,cy:yy,r:14,fill:'transparent'}));
      g.append(el('path',{d:`M${xx},${yy-6} L${xx+6},${yy} L${xx},${yy+6} L${xx-6},${yy} Z`,class:'chart-sold-marker'}));
      const inspectSale=()=>{container.dataset.inspectSale=s.at;delete container.dataset.inspectTime;delete container.dataset.inspectBuy;readout.textContent=saleText(s);};
      g.addEventListener('click',inspectSale);g.addEventListener('focus',inspectSale);
      g.addEventListener('keydown',e=>{if(['Enter',' '].includes(e.key)){e.preventDefault();e.stopPropagation();inspectSale();}});
      svg.append(g);
      if(String(s.at)===activeSale)g.focus({preventScroll:true});
    }
    if(!data.length){
      const inspectedBuy=buys.find(b=>(b.id||`${b.at}:${b.side}`)===container.dataset.inspectBuy);
      const inspectedSale=sales.find(s=>String(s.at)===container.dataset.inspectSale);
      readout.textContent=inspectedBuy?buyText(inspectedBuy):inspectedSale?saleText(inspectedSale):
        sales.length?saleText(sales.at(-1)):
        sold?`Sold line ${money(sold.now)} · ${saleText(sold)} Waiting for new chart samples.`:
        buys.length?buyText(buys.at(-1)):'Waiting for chart samples.';
      return;
    }
    const cursor=el('line',{x1:R,x2:R,y1:T,y2:B,class:'chart-cursor',visibility:'hidden'});
    svg.append(cursor);
    const inspect=i=>{
      delete container.dataset.inspectSale;
      delete container.dataset.inspectBuy;
      const p=data[Math.max(0,Math.min(data.length-1,i))];
      container.dataset.inspectTime=p.t;
      cursor.setAttribute('x1',x(p.t));cursor.setAttribute('x2',x(p.t));cursor.setAttribute('visibility','visible');
      readout.textContent=`${new Date(p.t).toLocaleTimeString([],{hour12:false})} · Now ${money(p.now)}`+
        (own&&p.position===own.startedAt?` · Best ${money(p.best)} · Exit ${money(p.exit)} · Staircase ${money(p.stair)} · Entry stop ${money(p.entryStop)} · Trailing line ${money(p.line)}`:'');
    };
    let index=data.length-1;
    const inspectAt=e=>{
      if(e.target?.closest?.('[data-testid="buy-point"],[data-testid="sold-point"]'))return;
      const r=svg.getBoundingClientRect(),target=start+((e.clientX-r.left-L)/(R-L))*(end-start);
      index=data.reduce((best,p,i)=>Math.abs(p.t-target)<Math.abs(data[best].t-target)?i:best,0);inspect(index);
    };
    svg.addEventListener('pointermove',inspectAt);
    svg.addEventListener('pointerdown',inspectAt);
    svg.addEventListener('pointerleave',()=>{delete container.dataset.inspectTime;});
    svg.addEventListener('keydown',e=>{
      if(e.key==='ArrowLeft'||e.key==='ArrowRight'){
        e.preventDefault();index=Math.max(0,Math.min(data.length-1,index+(e.key==='ArrowLeft'?-1:1)));inspect(index);
      }
    });
    readout.textContent=`Chart sample ${new Date(data.at(-1).t).toLocaleTimeString([],{hour12:false})} · Now ${money(data.at(-1)?.now)} · Point, touch or use arrow keys to inspect.`;
    if(container.dataset.inspectTime){
      const t=Number(container.dataset.inspectTime);
      index=data.reduce((best,p,i)=>Math.abs(p.t-t)<Math.abs(data[best].t-t)?i:best,0);inspect(index);
    }
    const inspected=sales.find(s=>String(s.at)===container.dataset.inspectSale);
    if(inspected)readout.textContent=saleText(inspected);
    const inspectedBuy=buys.find(b=>(b.id||`${b.at}:${b.side}`)===container.dataset.inspectBuy);
    if(inspectedBuy)readout.textContent=buyText(inspectedBuy);
  }
  root.NowChart={draw};
})(globalThis);
