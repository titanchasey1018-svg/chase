(function(root,factory){
  const api=factory();
  if(typeof module==='object'&&module.exports)module.exports=api;
  else root.TimedCashout=api;
})(typeof globalThis!=='undefined'?globalThis:this,function(){
  'use strict';
  const DEFAULTS={upCashoutEnabled:false,upCashoutPercent:95,upCashoutSeconds:60,upCashoutStopReentry:true,
    upCashoutBlockEntry:true,
    downCashoutEnabled:false,downCashoutPercent:95,downCashoutSeconds:60,downCashoutStopReentry:true,
    downCashoutBlockEntry:true};
  function validate(input){
    const out={};
    for(const p of ['up','down']){
      const key=p+'CashoutEnabled',v=Object.hasOwn(input,key)?input[key]:false;
      if(typeof v!=='boolean')throw new Error(key+': use checked or unchecked.');
      out[key]=v;
      const lockKey=p+'CashoutStopReentry',lock=Object.hasOwn(input,lockKey)?input[lockKey]:true;
      if(typeof lock!=='boolean')throw new Error(lockKey+': use checked or unchecked.');
      out[lockKey]=lock;
      const entryKey=p+'CashoutBlockEntry',block=Object.hasOwn(input,entryKey)?input[entryKey]:true;
      if(typeof block!=='boolean')throw new Error(entryKey+': use checked or unchecked.');
      out[entryKey]=block;
      for(const [suffix,lo,hi]of [['Percent',1,100],['Seconds',1,900]]){
        const k=p+'Cashout'+suffix,raw=Object.hasOwn(input,k)?input[k]:DEFAULTS[k],n=Number(raw);
        if(!['number','string'].includes(typeof raw)||String(raw).trim()===''||!Number.isFinite(n)||n<lo||n>hi)
          throw new Error(`${k}: enter a number from ${lo} to ${hi}.`);
        out[k]=n;
      }
    }
    return out;
  }
  function evaluate(rules,quote,m,side,remaining,now,running=true){
    const up=side==='UP',p=up?'up':'down',enabled=rules[p+'CashoutEnabled']===true;
    const threshold=rules[p+'CashoutPercent']??95,windowSeconds=rules[p+'CashoutSeconds']??60;
    const ask=up?quote?.upAsk:quote?.downAsk,bid=up?quote?.upBid:quote?.downBid;
    const fresh=m?.ready===true&&Number.isFinite(quote?.ts)&&now>=quote.ts&&now-quote.ts<=10000;
    const executable=Number.isFinite(bid)&&bid>0&&bid<100;
    const priceValid=Number.isFinite(ask)&&ask>0&&ask<=100;
    const timeValid=Number.isFinite(remaining)&&remaining>0;
    const marketOpen=!['closed','settled','finalized','inactive'].includes(quote?.status);
    const pricePassed=priceValid&&ask>=threshold,timePassed=timeValid&&remaining<=windowSeconds;
    const action=!enabled?'OFF':!running?'STOPPED':!timeValid||!marketOpen?'EXPIRED':
      !fresh||!executable||!priceValid?'PAUSED':pricePassed&&timePassed?'SELL':'HOLD';
    const reason=action==='SELL'?`${side} timed cash-out: button ${ask}% ≥ ${threshold}% with ${remaining.toFixed(1)}s left ≤ ${windowSeconds}s. Sell bid ${bid}¢; no extra wait.`:
      action==='OFF'?'Timed percentage cash-out is off.':
      action==='STOPPED'?'Monitor only: bot stopped. No automatic cash-out.':
      action==='PAUSED'?'Cash-out paused: fresh data and an executable sell bid are required.':
      action==='EXPIRED'?'Cash-out unavailable: market closed or countdown missing.':
      `Cash out if ${side} button ≥ ${threshold}% AND time left ≤ ${windowSeconds}s.`;
    return {enabled,threshold,windowSeconds,stopReentry:rules[p+'CashoutStopReentry']!==false,
      ask:ask??null,bid:bid??null,remaining,
      pricePassed,timePassed,action,reason,side};
  }
  function entryGuard(rules,quote,market,side,now){
    const p=side==='UP'?'up':'down',enabled=rules[p+'CashoutEnabled']===true&&
      rules[p+'CashoutBlockEntry']!==false;
    const threshold=rules[p+'CashoutPercent']??95,windowSeconds=rules[p+'CashoutSeconds']??60;
    const ask=side==='UP'?quote?.upAsk:quote?.downAsk;
    const remaining=Number.isFinite(market?.closeTime)?(market.closeTime-now)/1000:null;
    const valid=!!market&&Number.isFinite(now)&&Number.isFinite(remaining)&&remaining>0&&
      Number.isFinite(quote?.ts)&&now>=quote.ts&&now-quote.ts<=10000&&
      (!quote.ticker||quote.ticker===market.ticker)&&
      (!quote.status||['active','open'].includes(quote.status))&&
      Number.isFinite(ask)&&ask>0&&ask<=100;
    const conflict=valid&&ask>=threshold&&remaining<=windowSeconds;
    const allowed=!enabled||valid&&!conflict;
    const reason=!enabled?`${side} entry blocker inactive: ${rules[p+'CashoutEnabled']!==true?'timed cash-out is off':'block-new-buys checkbox is off'}.`:
      !valid?`${side} buy blocked: fresh matching Kalshi ask and positive market countdown required for the timed cash-out entry check.`:
      conflict?`${side} buy blocked: timed cash-out conditions already met (button ${ask}% ≥ ${threshold}%; ${remaining.toFixed(1)}s left ≤ ${windowSeconds}s).`:
      `${side} entry check passes: timed cash-out conditions are not both met (button ${ask}%; ${remaining.toFixed(1)}s left).`;
    return {side,enabled,allowed,conflict,valid,ask:ask??null,remaining,threshold,windowSeconds,reason};
  }
  return {DEFAULTS,validate,evaluate,entryGuard};
});
