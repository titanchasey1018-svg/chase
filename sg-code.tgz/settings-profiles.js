'use strict';
const crypto = require('node:crypto');
const Guard = require('./public/guard-engine');
const Buy = require('./public/buy-signal');
const Safety = require('./public/safety-engine');
const Following = require('./public/following-trail-engine');
const Candle = require('./public/candle-reversal-engine');
const Line = require('./public/line-trail-engine');
const Entry = require('./entry-policy');
const NowEntry = require('./public/now-entry-engine');
const BuyConditions = require('./public/buy-conditions');
const NowExit = require('./public/now-exit-engine');
const LIMIT = 40;
const KEYS = ['entryMethod', 'triggerPoint', 'upBuyCents', 'downBuyCents', 'upBuyNow', 'downBuyNow', 'dollars',
  'slippage', ...Object.keys(Entry.DEFAULTS)];

// Explicit allowlist: no mode, credentials, balance, ledger or running state.
function snapshot(settings) {
  const out = {};
  for (const key of KEYS) out[key] = settings[key] ?? Entry.DEFAULTS[key];
  Entry.validateSettings(out,Entry.DEFAULTS,false);
  out.upBuyCents = Buy.priceThreshold(settings,'UP');
  out.downBuyCents = Buy.priceThreshold(settings,'DOWN');
  out.rules = Guard.validateRules(settings.rules);
  out.safety=Safety.validate(settings.safety||{});
  out.following=Following.assertPlan(settings.following,out.safety);
  out.nowEntry=NowEntry.validate(settings.nowEntry);
  out.buyConditions=BuyConditions.assertUsage(settings.buyConditions,out.nowEntry);
  out.nowExit=NowExit.validate(settings.nowExit);
  out.candleReversal=Candle.validate(settings.candleReversal);
  out.lineTrail=Line.validate(settings.lineTrail);
  return structuredClone(out);
}
function builtins(defaults) {
  const trial = snapshot(defaults);
  Object.assign(trial.rules, {
    upTrailEnabled: true, upTrailActivation: 80, upTrailPullback: 50, upTrailSeconds: 2,
    downTrailEnabled: true, downTrailActivation: -100, downTrailPullback: 30, downTrailSeconds: 2,
    upTrailWarmupEnabled: false, downTrailWarmupEnabled: false,
  });
  return [
    { id: 'factory-baseline', name: 'Factory baseline', builtIn: true, paperOnly: false,
      description: defaults.asset==='BTC'?'Original factory strategy settings. Loading never starts trading.':
        `${defaults.asset} starter settings, not a tested strategy. Loading never starts trading.`,
      config: snapshot(defaults) },
    { id: 'paper-trailing-trial-1', name: 'Trailing trial 1 (Paper)', builtIn: true, paperOnly: true,
      description: 'Unvalidated trial, not a best-profit preset. UP: activation +$80, pullback $50, confirmation 2s. DOWN: activation −$100, pullback $30, confirmation 2s. Opening warm-up OFF. Contract entry >90¢ plus UP Now ≥+$40 or DOWN Now ≤−$40; $10 budget, 2¢ slippage; re-entry OFF. Regular sell checks ON; Now-only and timed cashout OFF. Other values use factory defaults. Loading does not start trading. Paper fills do not model real fees/liquidity.',
      config: trial },
  ].slice(0,defaults.asset&&defaults.asset!=='BTC'?1:2);
}
function list(b, defaults) { return [...builtins(defaults), ...(b.profiles || [])]; }
function find(b, defaults, id) { return list(b, defaults).find(p => p.id === id); }
function sameConfig(a,b) {
  const x=snapshot(a),y=snapshot(b);
  // The shared field is only a fallback; compare effective per-side prices.
  delete x.triggerPoint;delete y.triggerPoint;
  return JSON.stringify(x)===JSON.stringify(y);
}
function active(b, defaults) {
  const p = find(b, defaults, b.activeProfileId);
  return p ? { id: p.id, name: p.name, paperOnly: !!p.paperOnly,
    modified: !sameConfig(b.settings,p.config) } : null;
}
function paperOnly(b, defaults) {
  if(b.profilesShared)return b.profilePaperOnly===true;
  return b.profilePaperOnly === true || !!find(b, defaults, b.activeProfileId)?.paperOnly;
}
function entryTag(b, defaults) {
  const p = active(b, defaults);
  return { id: p?.id || null, name: p?.name || 'Custom settings',
    modified: !!p?.modified, paperOnly: paperOnly(b, defaults), config: snapshot(b.settings) };
}
function validateName(b, defaults, name, except) {
  if (typeof name !== 'string' || !name.trim() || name.trim().length > 40 || /[\x00-\x1f\x7f]/.test(name))
    throw new Error('Use a profile name of 1–40 characters, without control characters.');
  name = name.trim();
  if (list(b, defaults).some(p => p.id !== except && p.name.toLowerCase() === name.toLowerCase()))
    throw new Error('A profile with that name already exists. Choose another name.');
  return name;
}
function save(b, defaults, name, id) {
  const old = id ? find(b, defaults, id) : null;
  if (id && !old) throw new Error('Profile not found.');
  if (old?.builtIn) throw new Error('Built-in profiles cannot be replaced. Save a new profile.');
  if(b.profilesShared&&old?.paperOnly&&b.settings.mode!=='paper')
    throw new Error('This shared profile is Paper-only. Save a new profile instead, or switch safely to Paper before replacing it.');
  if (!old && b.profiles.length >= LIMIT) throw new Error(`Maximum ${LIMIT} saved profiles. Delete an unused profile first.`);
  name = validateName(b, defaults, old ? old.name : name, id);
  const p = { id: id || crypto.randomUUID(), name, builtIn: false,
    paperOnly: !!old?.paperOnly || paperOnly(b, defaults),
    createdAt: old?.createdAt || Date.now(), updatedAt: Math.max(Date.now(),(old?.updatedAt||0)+1),
    description: 'Your saved applied settings. Loading does not start or arm trading.',
    config: snapshot(b.settings) };
  if (old) b.profiles[b.profiles.findIndex(x => x.id === id)] = p;
  else b.profiles.push(p);
  b.activeProfileId = p.id;
  b.profilePaperOnly = p.paperOnly;
  return p;
}
function assertLoadable(b, profile) {
  if (b.running || b.armedLive) throw new Error('Stop and disarm the bot before loading or restoring a profile.');
  if (b.busy || ['BUYING', 'SELLING', 'MANUAL'].includes(b.phase))
    throw new Error('Wait for the current operation to finish, then try again.');
  if (b.open || b.position || b.paper?.pos || b.pendingSettle?.length || b.paper?.pending?.length)
    throw new Error('Close this copy’s position and finish pending settlements before switching profiles.');
  if (profile.paperOnly && b.settings.mode !== 'paper')
    throw new Error('This trial and its saved copies are Paper-only. Select Paper mode first.');
}
function apply(b, defaults, p, restoring = false) {
  assertLoadable(b, p);
  const config = snapshot(p.config);
  const previous = { config: snapshot(b.settings), activeProfileId: b.activeProfileId,
    paperOnly: paperOnly(b, defaults) };
  b.settings = { ...b.settings, ...config };
  b.activeProfileId = restoring ? (p.activeProfileId || null) : p.id;
  b.profilePaperOnly = !!p.paperOnly;
  b.profileUndo = restoring ? null : previous;
  b.armedLive = false;
  b.guard = Guard.blank(); b.guardDecision = null; b.entrySignals = {};b.safetyEntries={};b.lowHighExit=null;b.lossCooldown=null;b.candleReversalState=null;
}
function remove(b, defaults, id) {
  const p = find(b, defaults, id);
  if (!p) throw new Error('Profile not found.');
  if (p.builtIn) throw new Error('Built-in profiles cannot be deleted.');
  if (b.activeProfileId === id) throw new Error('Load another profile before deleting the active one.');
  b.profiles = b.profiles.filter(x => x.id !== id);
  // Undo retains its full configuration even if the old named profile is deleted.
  if (b.profileUndo?.activeProfileId === id) b.profileUndo.activeProfileId = null;
}
function applyTrial(b, defaults) {
  if(defaults.asset&&defaults.asset!=='BTC')throw Error('The original BTC trailing trial is not available for this coin.');
  assertLoadable(b,{paperOnly:true});
  const id='paper-trial-my-settings', old=b.profiles.find(p=>p.id===id);
  if(!old && b.profiles.length>=LIMIT) throw new Error('Delete an unused saved profile before adding the Paper trial.');
  let name=old?.name || 'Paper trial with my settings',n=2;
  while(list(b,defaults).some(p=>p.id!==id&&p.name.toLowerCase()===name.toLowerCase()))
    name='Paper trial with my settings '+n++;
  const config=snapshot(b.settings),candidate=builtins(defaults)[1].config.rules;
  for(const side of ['up','down']) for(const suffix of ['Enabled','Activation','Pullback','Seconds'])
    config.rules[side+'Trail'+suffix]=candidate[side+'Trail'+suffix];
  // This explicit trial promises absolute +80/-100 activation, not entry-relative.
  for(const side of ['up','down'])config.rules[side+'TrailFromEntryEnabled']=false;
  const p={id,name,builtIn:false,paperOnly:true,createdAt:old?.createdAt||Date.now(),updatedAt:Math.max(Date.now(),(old?.updatedAt||0)+1),config,
    description:'Unvalidated Paper trailing trial. UP +$80 activation / $50 pullback / 2s; DOWN −$100 / $30 / 2s. Your buy settings, budget, re-entry, warm-up choices and other exits were retained when applied. No profit guarantee. Loading never starts trading.'};
  apply(b,defaults,p);
  if(old)b.profiles[b.profiles.findIndex(p=>p.id===id)]=p;else b.profiles.push(p);
  return p;
}
module.exports = { KEYS, LIMIT, snapshot, sameConfig, builtins, list, find, active, paperOnly, entryTag,
  save, assertLoadable, apply, remove, applyTrial };
