'use strict';
const {parseTrades}=require('./contract-volume');
const REFRESH=5000,OVERLAP=15000,MAX_AGE=20000;

class ContractCounter {
  constructor(request,{clock=Date.now,maxPages=8}={}){
    this.request=request;this.clock=clock;this.maxPages=maxPages;this.cache=new Map();
  }
  key(env,m){return `${env}:${m.ticker}:${m.openTime}`;}
  active(m,now){
    return !!m?.ticker&&Number.isFinite(m.openTime)&&Number.isFinite(m.closeTime)&&
      m.openTime<=now&&now<m.closeTime&&m.closeTime-m.openTime<=960000;
  }
  snapshot(env,m){
    const now=this.clock();
    if(!this.active(m,now))return {status:'no-market'};
    const e=this.cache.get(this.key(env,m));
    if(e?.limited)return {status:'incomplete'};
    if(e?.error||e?.data&&(now-e.data.asOf>MAX_AGE||now<e.data.asOf))
      return {status:'unavailable'};
    if(!e?.data)return {status:'loading'};
    const {up,down,asOf}=e.data,total=up+down;
    return {status:total?'ready':'empty',up:up/100,down:down/100,total:total/100,
      net:(up-down)/100,upPercent:total?up/total*100:null,downPercent:total?down/total*100:null,
      asOf,ticker:m.ticker};
  }
  kick(env,m){
    const now=this.clock();
    if(!this.active(m,now))return;
    const key=this.key(env,m);
    for(const [k,v] of this.cache)if(!v.promise&&now-v.used>1200000)this.cache.delete(k);
    let e=this.cache.get(key);
    if(e){e.used=now;if(e.promise||e.limited||now<e.next)return e.promise;}
    if([...this.cache.values()].some(v=>v.promise))return;
    if(!e){
      if(this.cache.size>=12){
        const oldest=[...this.cache].sort((a,b)=>a[1].used-b[1].used)[0];
        this.cache.delete(oldest[0]);
      }
      e={used:now,next:0,data:null,error:false,limited:false,promise:null};
      this.cache.set(key,e);
    }
    const asOf=Math.floor(now/1000)*1000;
    const from=Math.max(m.openTime,(e.data?.asOf??m.openTime)-OVERLAP);
    e.next=now+REFRESH;
    e.promise=Promise.resolve().then(async()=>{
      try{
        let cursor='',complete=false;
        const seen=new Set(),rows=[];
        for(let i=0;i<this.maxPages;i++){
          const query=new URLSearchParams({ticker:m.ticker,min_ts:String(Math.floor(from/1000)),
            max_ts:String(asOf/1000),limit:'1000',is_block_trade:'false'});
          if(cursor)query.set('cursor',cursor);
          const r=await this.request(env,'/markets/trades?'+query);
          if(!Array.isArray(r?.trades)||r.trades.length>1000||typeof r.cursor!=='string')
            throw Error('Invalid trade page');
          rows.push(...r.trades);
          cursor=r.cursor;
          if(!cursor){complete=true;break;}
          if(seen.has(cursor))throw Error('Repeated trade cursor');
          seen.add(cursor);
        }
        if(!complete){e.limited=true;return;}
        let up=e.data?.up??0,down=e.data?.down??0;
        const ids=new Map(e.data?.ids);
        for(const t of parseTrades(rows,m.ticker)){
          if(t.ts<from||t.ts>asOf||t.ts>=m.closeTime)continue;
          if(ids.has(t.id)){
            const last=ids.get(t.id);
            if(last.ts!==t.ts||last.side!==t.side||last.count!==t.count)throw Error('Trade changed');
            continue;
          }
          const count=Math.round(t.count*100);
          if(count<1||!Number.isSafeInteger(count)||Math.abs(count/100-t.count)>1e-8)
            throw Error('Invalid contract precision');
          if(t.side==='UP')up+=count;else down+=count;
          ids.set(t.id,t);
        }
        if(!Number.isSafeInteger(up+down))throw Error('Count overflow');
        for(const [id,t] of ids)if(t.ts<asOf-OVERLAP)ids.delete(id);
        e.data={asOf,up,down,ids};e.error=false;
      }catch(err){
        e.error=true;e.next=this.clock()+(err.status===429?15000:REFRESH);
      }finally{e.promise=null;}
    });
    return e.promise;
  }
}
module.exports={ContractCounter};
