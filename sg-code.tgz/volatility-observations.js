'use strict';
const Following=require('./public/following-trail-engine');
const KEYS=['chop','atr','timeLeft'];
const MODES=new Set(['paper','live']);
const available=mode=>MODES.has(mode);
function defaults(mode){return {chop:mode==='paper',atr:false,timeLeft:mode==='paper'};}
function options(mode,input){
  const out=defaults(mode);
  if(!available(mode)||!input)return out;
  for(const k of KEYS)if(typeof input[k]==='boolean')out[k]=input[k];
  return out;
}
function writeOptions(input){
  if(!input||typeof input!=='object'||Array.isArray(input)||Object.keys(input).length!==KEYS.length||
    !KEYS.every(k=>Object.hasOwn(input,k)&&typeof input[k]==='boolean'))
    throw Error('Provide all three observation options as on/off values.');
  return Object.fromEntries(KEYS.map(k=>[k,input[k]]));
}
function timeLeft(market,at){
  return Number.isFinite(at)&&Number.isFinite(market?.closeTime)&&market.closeTime>at&&
    (!Number.isFinite(market.openTime)||market.openTime<=at)?
    Math.floor((market.closeTime-at)/1000):null;
}
const BASELINE=12, QUIET=.85, RISE=1.15, MINUTE=60000;
const RULE='COINBASE_ATR14_QUIET_RISE_V1', SOURCE='Coinbase closed 1m candles';
const unavailable=()=>({label:'UNAVAILABLE',rule:RULE,source:SOURCE,observationOnly:true,
  atrUsd:null,priorAtrUsd:null,baselineUsd:null,candleEndAt:null,
  reason:'Need fresh consecutive closed one-minute candles.'});
function regime(candles,at){
  const latest=candles.filter(c=>Number.isFinite(c.endAt)&&c.endAt<=at)
    .reduce((best,c)=>Math.max(best,c.endAt),-Infinity);
  const current=Following.closedAtr(candles,at);
  if(current===null||!Number.isFinite(latest))return unavailable();
  const prior=Following.closedAtr(candles,latest-MINUTE);
  const history=Array.from({length:BASELINE},(_,i)=>Following.closedAtr(candles,latest-(i+2)*MINUTE));
  // closedAtr tolerates a stale latest candle; require the intended close at
  // every baseline minute rather than silently reusing a preceding candle.
  const ends=new Set(candles.map(c=>c.endAt));
  if(prior===null||history.some((v,i)=>v===null||!ends.has(latest-(i+2)*MINUTE))||!ends.has(latest-MINUTE))
    return unavailable();
  history.sort((a,b)=>a-b);
  const median=(history[BASELINE/2-1]+history[BASELINE/2])/2;
  const label=prior<=median*QUIET&&current>=prior*RISE?'QUIET_TO_ACTIVE':
    current<=median*QUIET?'QUIET':'NORMAL';
  return {label,rule:RULE,source:SOURCE,observationOnly:true,atrUsd:current,priorAtrUsd:prior,
    baselineUsd:median,candleEndAt:latest};
}

module.exports={KEYS,available,options,writeOptions,timeLeft,regime,unavailable};
