'use strict';
const fs=require('node:fs');
const crypto=require('node:crypto');
const hash=value=>crypto.createHash('sha256').update(value).digest('hex');
function fingerprint(creds){
  if(!creds?.keyId||!creds?.privateKey||!['live','demo'].includes(creds.env))return null;
  try{
    // A public PEM is not proof of private-key ownership.
    const secret=crypto.createPrivateKey(creds.privateKey);
    const pub=crypto.createPublicKey(secret).export({type:'spki',format:'der'});
    return hash(creds.env+'\0'+creds.keyId.trim()+'\0'+pub.toString('base64'));
  }catch{return null;}
}
function label(id){return 'SG-'+hash(id).slice(0,8).toUpperCase();}
function occupied(b){
  return !!(b?.running||b?.busy||b?.phase==='MANUAL'||b?.open||b?.position||
    b?.paper?.pos||b?.paper?.pending?.length||b?.pendingSettle?.length);
}
class SessionConnections{
  constructor({file=null}={}){
    this.file=file;this.data={version:1,codes:{},aliases:{}};this.attempts=new Map();
    if(file){
      try{
        const d=JSON.parse(fs.readFileSync(file,'utf8'));
        if(d.version!==1||!d.codes||!d.aliases||typeof d.codes!=='object'||typeof d.aliases!=='object'||
          Array.isArray(d.codes)||Array.isArray(d.aliases)||
          Object.entries(d.codes).some(([k,v])=>!/^[a-f0-9]{64}$/.test(k)||typeof v!=='string'||!v||v.length>128)||
          Object.entries(d.aliases).some(([k,v])=>!/^[a-f0-9]{64}$/.test(k)||typeof v!=='string'||!v||v.length>128))
          throw Error('Invalid session connection registry.');
        this.data=d;
      }catch(e){if(e.code!=='ENOENT')throw Error('Cannot load session connections; original file retained.');}
    }
  }
  flush(next){
    if(this.file){
      const tmp=this.file+'.tmp-'+process.pid;
      try{fs.writeFileSync(tmp,JSON.stringify(next),{mode:0o600});fs.renameSync(tmp,this.file);}
      catch(e){try{fs.unlinkSync(tmp);}catch{}throw Error('Connection was not saved. Please retry.');}
    }
    this.data=next;
  }
  resolve(visitor){return this.data.aliases[hash(visitor)]||visitor;}
  known(id){return Object.values(this.data.aliases).includes(id)||Object.values(this.data.codes).includes(id);}
  issue(id){
    // Deterministic hash lookup; only secret possession permits connection.
    const code='SG1-'+crypto.randomBytes(32).toString('base64url');
    const next=structuredClone(this.data);
    // Keep a bounded number of recovery codes per session.
    const keys=Object.keys(next.codes).filter(k=>next.codes[k]===id);
    for(const k of keys.slice(0,Math.max(0,keys.length-7)))delete next.codes[k];
    next.codes[hash(code)]=id;this.flush(next);return code;
  }
  target(code){
    if(typeof code!=='string'||!/^SG1-[A-Za-z0-9_-]{43}$/.test(code))return null;
    return this.data.codes[hash(code)]||null;
  }
  connect(visitor,source,target){
    if(source.id!==target.id&&occupied(source))
      throw Error('This view has running automation, an order, a position or settlement. It cannot switch sessions. No bot was stopped.');
    const next=structuredClone(this.data);
    next.aliases[hash(visitor)]=target.id;this.flush(next);
  }
  limit(key,now=Date.now()){
    for(const[k,v]of this.attempts)if(now-v.at>60000)this.attempts.delete(k);
    const v=this.attempts.get(key)||{at:now,n:0};
    if(++v.n>30)throw Error('Too many recovery attempts. Wait one minute.');
    this.attempts.set(key,v);
  }
}
module.exports={SessionConnections,fingerprint,label,occupied};
