'use strict';

// Additive, bounded evidence on the existing owned-position/result records.
// No orders, credentials, settings or account I/O belong in this module.
const MAX_EVENTS = 96;
const finite = x => Number.isFinite(x) ? x : null;
function ensure(open, now, mode) {
  if (!open || !(open.count > 0)) return null;
  const tradeId = open.tradeId || `${open.mode||mode}:${open.ticker}:${open.startedAt||0}`;
  if (!open.exitAudit || open.exitAudit.tradeId !== tradeId) {
    open.exitAudit = {version:1, tradeId, ticker:open.ticker, side:open.side,
      mode:open.mode||mode, firstObservedAt:now, firstBreachAt:null,
      orderSubmittedAt:null, fillAt:null, submissionCount:0, droppedEvents:0, events:[]};
  }
  return open.exitAudit;
}
function append(audit, event) {
  audit.events.push(event);
  if (audit.events.length > MAX_EVENTS) {
    audit.droppedEvents += audit.events.length-MAX_EVENTS;
    audit.events.splice(0,audit.events.length-MAX_EVENTS);
  }
}
function observe(open, {now, quote, decision:d, running, oldProfitLatched, oldLossLatched, safety,mode}) {
  const a = ensure(open,now,mode);
  if (!a) return false;
  const profit = d.contractProfit, loss = d.contractLoss;
  const mark = profit?.mark || loss?.mark;
  const lossLevels = [
    safety.tradeDollarsEnabled ? -safety.tradeDollars : null,
    safety.tradePercentEnabled && mark ? -mark.basis*safety.tradePercent/100 : null,
  ].filter(Number.isFinite);
  const snapshot = {at:now, action:d.action, exitKind:d.exitKind||null, reason:d.reason,
    running:running===true, bid:finite(mark?.bid), pnl:finite(mark?.pnl),
    quoteReceivedAt:finite(quote?.receivedAt??quote?.ts),
    quoteRequestedAt:finite(quote?.requestedAt),
    quoteAgeMs:Number.isFinite(quote?.ts) ? Math.max(0,now-quote.ts) : null,
    quoteRequestLatencyMs:finite(quote?.requestLatencyMs),
    profit:{kind:profit?.kind||'current',unit:profit?.kind==='volatility'?'btc-now-usd':'position-pnl-usd',
      active:profit?.active===true, latched:profit?.latched===true,
      best:finite(profit?.best), level:finite(profit?.level), action:profit?.action||null},
    loss:{breached:loss?.breached===true, action:loss?.action||null,
      triggered:loss?.triggered===true, cooldownMs:finite(loss?.requiredMs),
      cooldownElapsedMs:finite(loss?.elapsedMs),
      level:lossLevels.length ? Math.max(...lossLevels) : null},
    ...(d.exitKind==='contract-volume'&&d.contractVolumeExit?{contractVolume:{
      up:finite(d.contractVolumeExit.up),down:finite(d.contractVolumeExit.down),
      total:finite(d.contractVolumeExit.total),oppositePercent:finite(d.contractVolumeExit.percent),
      requiredPercent:finite(d.contractVolumeExit.required),lookback:finite(d.contractVolumeExit.lookback),
      ageMs:finite(d.contractVolumeExit.ageMs)}}:{})};
  // Rehydrated legacy latches establish only an observed state, not when the
  // breach happened. A newly observed false->true latch does establish a time.
  const newLoss = running && loss?.breached && !oldLossLatched;
  const newProfit = running && profit?.latched && !oldProfitLatched;
  const inherited = d.exitKind==='contract-loss' ? oldLossLatched :
    d.exitKind==='contract-profit' ? oldProfitLatched : false;
  const kind = newLoss ? 'contract-loss' : newProfit ? 'contract-profit' :
    running && d.action==='SELL' && !inherited ? d.exitKind : null;
  let first = false;
  if (a.firstBreachAt===null && kind) {
    a.firstBreachAt = now;
    a.firstBreachKind = kind;
    a.firstBreachBid = snapshot.bid;
    a.firstBreachPnl = snapshot.pnl;
    a.firstBreachLevel = kind==='contract-profit' ? snapshot.profit.level :
      kind==='contract-loss' ? snapshot.loss.level : null;
    a.firstBreachLevelUnit=kind==='contract-profit'?snapshot.profit.unit:
      kind==='contract-loss'?'position-pnl-usd':null;
    a.quoteReceivedAt = snapshot.quoteReceivedAt;
    a.firstBreach = structuredClone({...snapshot,exitKind:kind});
    first = true;
  }
  // Omit wall-clock/age fields from the signature: unchanged quotes and state
  // must not generate a write on every UI poll.
  // Keep timer progress in each recorded snapshot, but do not write private
  // state on every sampling tick solely because pending elapsed time advanced.
  const {cooldownElapsedMs,...lossSignature}=snapshot.loss;
  const signature = JSON.stringify([snapshot.action,snapshot.exitKind,snapshot.running,
    snapshot.bid,snapshot.pnl,snapshot.profit,lossSignature]);
  if (!first && signature===a.lastDecisionSignature) return false;
  a.lastDecisionSignature = signature;
  append(a,{type:first?'first-breach':'decision',...snapshot});
  return true;
}
function submitted(open, {now,count,price,execution,exitKind,clientOrderId=null}) {
  const a = ensure(open,now,execution);
  if (!a) return null;
  const token = ++a.submissionCount;
  if (a.orderSubmittedAt===null) a.orderSubmittedAt=now;
  a.lastOrderSubmittedAt=now;
  append(a,{type:'submission',at:now,submission:token,count,price,execution,
    exitKind:exitKind||'manual',clientOrderId});
  return token;
}
function response(open, token, now, {filled=null,error=null}={}) {
  if (!open?.exitAudit || token===null) return;
  append(open.exitAudit,{type:error?'submission-error':'response',at:now,
    submission:token,filled:finite(filled),error:error?String(error).slice(0,240):null});
}
function fill(open, {now,count,price,pnl,completed,mode}) {
  const a=ensure(open,now,mode);
  if (!a) return null;
  if (!Number.isFinite(a.firstFillAt)) a.firstFillAt=now;
  a.fillAt=now;
  append(a,{type:'fill',at:now,submission:a.submissionCount||null,count,price,pnl,
    completed,remaining:Math.max(0,open.count-count)});
  // Each partial-fill result must keep its own immutable evidence snapshot.
  return structuredClone(a);
}
function summary(audit) {
  if (!audit) return null;
  const {events,lastDecisionSignature,...rest}=audit;
  return {...structuredClone(rest),retainedEventCount:events?.length||0};
}
function event(open, now, mode, data) {
  const a=ensure(open,now,mode);
  if(a)append(a,{...data,at:now});
}
module.exports={MAX_EVENTS,observe,submitted,response,fill,summary,event};
