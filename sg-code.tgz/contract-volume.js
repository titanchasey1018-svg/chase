'use strict';
// Public completed trades only. No account credentials or order calls.
// Schema: https://docs.kalshi.com/api-reference/market/get-trades
function parseTrades(rows,ticker){
  if(!Array.isArray(rows))throw Error('Trade-history response is missing trades.');
  const trades=new Map();
  for(const r of rows){
    if(r.is_block_trade===true)continue;
    if(r.ticker!==ticker)throw Error('Trade history returned a different market.');
    const raw=r.taker_outcome_side??(r.taker_book_side==='bid'?'yes':
      r.taker_book_side==='ask'?'no':r.taker_side);
    const amount=r.count_fp??r.count,count=Number(amount),ts=Date.parse(r.created_time);
    if(r.taker_book_side!=null&&(!['bid','ask'].includes(r.taker_book_side)||
      (r.taker_book_side==='bid'?'yes':'no')!==raw))
      throw Error('Conflicting trade direction fields.');
    if(!['yes','no'].includes(raw)||!['number','string'].includes(typeof amount)||
      !Number.isFinite(count)||count<=0||typeof r.created_time!=='string'||
      !Number.isFinite(ts)||typeof r.trade_id!=='string'||!r.trade_id)
      throw Error('Trade history contains an invalid count, timestamp or direction.');
    const t={id:r.trade_id,ts,count,side:raw==='yes'?'UP':'DOWN'};
    if(trades.has(t.id)&&JSON.stringify(trades.get(t.id))!==JSON.stringify(t))
      throw Error('Conflicting duplicate trade data.');
    trades.set(t.id,t);
  }
  return [...trades.values()];
}
class ContractVolumeFeed{
  constructor(request,{clock=Date.now,maxPages=5}={}){
    this.request=request;this.clock=clock;this.maxPages=maxPages;this.cache=new Map();
  }
  key(env,ticker){return env+':'+ticker;}
  snapshot(env,ticker){return this.cache.get(this.key(env,ticker))?.data||null;}
  kick(env,ticker,lookback){
    const now=this.clock(),key=this.key(env,ticker);
    for(const [k,v]of this.cache)if(!v.promise&&now-v.used>600000)this.cache.delete(k);
    if(!this.cache.has(key)){
      if(this.cache.size>=16){
        const oldest=[...this.cache].filter(([,v])=>!v.promise).sort((a,b)=>a[1].used-b[1].used)[0];
        if(!oldest)return;
        this.cache.delete(oldest[0]);
      }
      this.cache.set(key,{used:now,next:0,lookback:0,data:null,promise:null});
    }
    const e=this.cache.get(key);e.used=now;e.lookback=Math.max(e.lookback,Math.min(300,Math.max(5,lookback)));
    if(e.promise||now<e.next)return e.promise;
    const asOf=Math.floor(now/1000)*1000,from=asOf-e.lookback*1000-1000;
    e.next=now+2000;
    e.promise=Promise.resolve().then(async()=>{
      try{
        let cursor='',rows=[],complete=false;const seen=new Set();
        for(let page=0;page<this.maxPages;page++){
          const params=new URLSearchParams({ticker,min_ts:String(from/1000),
            max_ts:String(asOf/1000),limit:'1000',is_block_trade:'false'});
          if(cursor)params.set('cursor',cursor);
          const r=await this.request(env,'/markets/trades?'+params);
          if(!r||!Array.isArray(r.trades)||typeof r.cursor!=='string')
            throw Error('Incomplete trade-history response.');
          rows.push(...r.trades);
          if(rows.length>5000)throw Error('Trade window exceeded the safe data limit.');
          cursor=r.cursor;
          if(!cursor){complete=true;break;}
          if(seen.has(cursor))throw Error('Trade-history pagination repeated.');
          seen.add(cursor);
        }
        if(!complete)throw Error('Trade window is too busy to verify completely; shorten the lookback.');
        e.data={env,ticker,asOf,from,complete:true,trades:parseTrades(rows,ticker),error:null};
      }catch(err){
        e.data={env,ticker,asOf,from,complete:false,trades:[],error:
          err.status===429?'Contract trade feed rate-limited; auto buys paused.':
          'Contract trade feed unavailable: '+String(err.message).slice(0,160)};
        e.next=this.clock()+(err.status===429?10000:3000);
      }finally{e.promise=null;}
    });
    return e.promise;
  }
}
module.exports={ContractVolumeFeed,parseTrades};
