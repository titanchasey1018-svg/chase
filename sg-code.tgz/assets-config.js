'use strict';
const assets=Object.freeze({
  BTC:Object.freeze({series:'KXBTC15M',index:'BRTI'}),
  ETH:Object.freeze({series:'KXETH15M',index:'ETHUSD_RTI'}),
  SOL:Object.freeze({series:'KXSOL15M',index:'SOLUSD_RTI'}),
});
function matchesMarket(asset,ticker){return typeof ticker==='string'&&
  Object.hasOwn(assets,asset)&&ticker.startsWith(assets[asset].series+'-');}
module.exports={assets,matchesMarket};
