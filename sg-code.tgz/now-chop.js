'use strict';
// Observation only. Neither the score nor its availability is a trade input.
const RULE = 'KALSHI_NOW_CHOP_V1';
const WINDOW_MS = 120000, GAP_MS = 8000, FRESH_MS = 5000, SAMPLE_MS = 1000;
const BAND = 5, QUIET_PATH = 10, CROSSING_CAP = 3;
const SOURCE_KINDS = new Set(['public_chart', 'authenticated_index']);
const round = (n, scale) => Math.round(n * scale) / scale;

class NowChop {
  constructor(asset='BTC') { this.asset=asset;this.reset(); }
  reset() { this.key = null; this.points = []; }

  observe(market, index, at) {
    const {ticker, strike, openTime, closeTime} = market || {};
    const {nowDiff, sourceKind, sourceTime, receivedTime} = index || {};
    if (!ticker || !Number.isFinite(strike) || !Number.isFinite(at) ||
        !SOURCE_KINDS.has(sourceKind) || ![nowDiff, sourceTime, receivedTime].every(Number.isFinite) ||
        sourceTime > at || at - sourceTime > FRESH_MS || receivedTime > at ||
        (Number.isFinite(openTime) && sourceTime < openTime) ||
        (Number.isFinite(closeTime) && at >= closeTime)) {
      this.reset();
      return;
    }
    const key = JSON.stringify([ticker, strike, sourceKind]);
    if (key !== this.key) this.points = [];
    this.key = key;
    const points = this.points, last = points.at(-1);
    if (last && (at < last.at || sourceTime < last.sourceTime ||
        at - last.at > GAP_MS || sourceTime - last.sourceTime > GAP_MS)) points.length = 0;
    else if (last && (sourceTime === last.sourceTime || at - last.at < SAMPLE_MS)) return;
    points.push({at, sourceTime, now: nowDiff});
    while (points[0].at < at - WINDOW_MS) points.shift();
  }

  snapshot(market, at) {
    const key = this.key ? JSON.parse(this.key) : [];
    const sameMarket = key[0] === market?.ticker && key[1] === market?.strike;
    const points = sameMarket ? this.points.filter(p => p.at >= at - WINDOW_MS && p.at <= at) : [];
    const first = points[0], last = points.at(-1);
    const info = {
      rule: RULE, observationOnly: true, at, windowSeconds: WINDOW_MS / 1000,
      sourceKind: sameMarket ? key[2] ?? null : null, sampleCount: points.length,
      timeLeftSeconds: Number.isFinite(market?.closeTime) ?
        Math.max(0, Math.floor((market.closeTime - at) / 1000)) : null,
      coverageSeconds: first ? round((last.at - first.at) / 1000, 10) : 0,
    };
    if (!last || at - last.sourceTime > FRESH_MS || first.at > at - WINDOW_MS + GAP_MS)
      return {...info, label:'UNAVAILABLE', score:null, efficiency:null, crossings:null, pathUsd:null,
        reason:last ? 'Warming up: need a near-full two-minute window of fresh same-source readings.' :
          'No fresh signed Kalshi Now readings for this market.'};

    let path = 0, crossings = 0, side = 0;
    const band=this.asset==='BTC'?BAND:market.strike*0.0001,quietPath=this.asset==='BTC'?QUIET_PATH:band*2;
    for (let i = 0; i < points.length; i++) {
      const {now} = points[i];
      if (i) path += Math.abs(now - points[i - 1].now);
      const outside = now >= band ? 1 : now <= -band ? -1 : 0;
      if (outside) {
        if (side && side !== outside) crossings++;
        side = outside;
      }
    }
    const measured = {...info, crossings, pathUsd:round(path, 100)};
    if (path < quietPath) return {...measured, label:'QUIET', score:null, efficiency:null};
    const efficiency = Math.min(1, Math.abs(last.now - first.now) / path);
    const score = 75 * (1 - efficiency) + 25 * Math.min(1, crossings / CROSSING_CAP);
    return {...measured, label: score >= 60 ? 'CHOPPY' : score <= 30 ? 'CLEAN' : 'MIXED',
      score:round(score, 10), efficiency:round(efficiency, 1000)};
  }
}

module.exports = {NowChop};
