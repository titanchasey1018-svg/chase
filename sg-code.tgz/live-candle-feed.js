'use strict';
// Observed Coinbase trades only. Never invent the open of a partial minute.
const MINUTE=60000,STALE=3000;
const color=(open,close)=>close>open?'green':close<open?'red':'neutral';
class LiveCandleFeed{
  constructor(asset='BTC'){this.asset=asset;this.bars=[];this.last=null;this.broken=true;this.sequence=0;this.trades=[];}
  disconnect(){this.broken=true;if(this.bars.length)this.bars.at(-1).complete=false;}
  observe(price,sourceAt,receivedAt=Date.now(),tradeId=null){
    if(!Number.isFinite(price)||price<=0||!Number.isFinite(sourceAt)||
      !Number.isFinite(receivedAt)||sourceAt>receivedAt+250||receivedAt-sourceAt>STALE)return false;
    if(this.last&&(sourceAt<this.last.sourceAt||
      (tradeId!=null&&this.last.tradeId!=null&&Number(tradeId)<=Number(this.last.tradeId))||
      (tradeId==null&&sourceAt===this.last.sourceAt&&price===this.last.price)))return false;
    const continuous=!!this.last&&!this.broken&&sourceAt-this.last.sourceAt<=STALE&&
      receivedAt-this.last.receivedAt<=STALE&&receivedAt>=this.last.receivedAt;
    const startAt=Math.floor(sourceAt/MINUTE)*MINUTE;
    let bar=this.bars.at(-1);
    if(!bar||bar.startAt!==startAt){
      if(bar&&!continuous)bar.complete=false;
      const known=continuous&&bar?.startAt===startAt-MINUTE;
      bar={startAt,endAt:startAt+MINUTE,open:price,high:price,low:price,close:price,
        openKnown:!!known,complete:!!known,color:'neutral',colorSince:sourceAt};
      this.bars.push(bar);this.bars=this.bars.slice(-60);
    }else{
      if(!continuous)bar.complete=false;
      const nextColor=color(bar.open,price);
      if(nextColor!==bar.color||!continuous)bar.colorSince=sourceAt;
      bar.color=nextColor;bar.close=price;
      bar.high=Math.max(bar.high,price);bar.low=Math.min(bar.low,price);
    }
    this.last={sourceAt,receivedAt,price,tradeId};this.broken=false;this.sequence++;
    this.trades.push({price,sourceAt,observedAt:receivedAt,sequence:this.sequence,continuous});
    // Private bounded tick buffer: confirmation must see recoveries between polls.
    this.trades=this.trades.filter(t=>receivedAt-t.observedAt<=10000).slice(-6000);
    return true;
  }
  trailingFrame(ticker,strike,afterSequence,now=Date.now()){
    const s=this.snapshot(now);
    const cursor=Number.isInteger(afterSequence)&&afterSequence<=this.sequence?afterSequence:null;
    return {ticker,strike,fresh:s.fresh,sourceAt:s.sourceAt,observedAt:s.observedAt,
      sequence:this.sequence,ticks:this.trades.filter(t=>cursor==null||t.sequence>cursor)
        .map(t=>({...t}))};
  }
  snapshot(now=Date.now()){
    const last=this.last,current=this.bars.at(-1);
    const fresh=!!last&&!this.broken&&now>=last.receivedAt&&now>=last.sourceAt-250&&
      now-last.receivedAt<=STALE&&now-last.sourceAt<=STALE&&
      current?.startAt===Math.floor(now/MINUTE)*MINUTE;
    const closed=this.bars.filter(b=>b.endAt<=now).at(-1)||null;
    return {source:`Observed Coinbase ${this.asset}/USD trades`,timeframeSeconds:60,staleMs:STALE,
      sequence:this.sequence,observedAt:last?.receivedAt??null,sourceAt:last?.sourceAt??null,
      fresh,ready:fresh&&current.openKnown,current:current?{...current}:null,
      lastClosed:closed?{...closed}:null,bars:this.bars.map(b=>({...b})),
      reason:!fresh?'Waiting for fresh Coinbase trades (maximum age 3s).':
        !current.openKnown?'First/partial candle: waiting for a continuously observed minute boundary.':
        'Live observed candle ready. Dashed candles contain partial/gapped observations.'};
  }
}
module.exports={LiveCandleFeed,MINUTE,STALE};
