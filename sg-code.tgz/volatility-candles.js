'use strict';
const {parseCandles}=require('./scripts/candle-observation-engine.cjs');
const Following=require('./public/following-trail-engine');
class VolatilityCandles{
  constructor({asset='BTC',enabled=true,fetchImpl=(...args)=>fetch(...args),now=()=>Date.now()}={}){
    this.asset=asset;
    this.enabled=enabled;this.fetch=fetchImpl;this.now=now;
    this.candles=[];this.next=0;this.busy=false;this.error=null;this.observedAt=null;
  }
  snapshot(){
    const at=this.now();
    if(this.enabled&&!this.busy&&at>=this.next){
      this.busy=true;this.next=at+15000;
      const end=Math.floor(at/60000)*60000;
      const url=new URL(`https://api.exchange.coinbase.com/products/${this.asset}-USD/candles`);
      url.searchParams.set('granularity','60');
      url.searchParams.set('start',new Date(end-30*60000).toISOString());
      url.searchParams.set('end',new Date(end).toISOString());
      this.pending=(async()=>{
        try{
          const r=await this.fetch(url.href,{method:'GET',redirect:'error',signal:AbortSignal.timeout(5000)});
          if(!r.ok)throw Error('Candle HTTP '+r.status);
          const rows=await r.json(),received=this.now();
          this.candles=parseCandles(rows,received);this.observedAt=received;this.error=null;
        }catch(e){this.error=String(e.message).slice(0,180);}
        finally{this.busy=false;}
      })();
    }
    const atr=Following.closedAtr(this.candles,at);
    return {candles:this.candles,atr,ready:atr!==null,observedAt:this.observedAt,
      reason:this.error||(atr===null?'Waiting for fresh closed Coinbase candles.':'Closed Coinbase ATR ready.')};
  }
}
module.exports={VolatilityCandles};
