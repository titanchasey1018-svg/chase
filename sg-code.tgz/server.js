// Kalshi 15-Minute Crypto Bot v2 — mobile edition
// Zero-dependency Node server: signs Kalshi API requests and runs the bot loop per visitor.
'use strict';
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const Guard = require('./public/guard-engine');
const feed = require('./market-data');
const Entry = require('./entry-policy');
const EntryWindow = require('./public/entry-window');
const LowHighSpread = require('./public/low-high-spread');
const Buy = require('./public/buy-signal');
const NowEntry = require('./public/now-entry-engine');
const BuyConditions = require('./public/buy-conditions');
const NowDirection = require('./public/now-entry-direction');
const NowExit = require('./public/now-exit-engine');
const Trailing = require('./public/trailing-engine');
const Cashout = require('./public/cashout-engine');
const Volume = require('./public/volume-engine');
const {ContractVolumeFeed}=require('./contract-volume');
const contractVolume=new ContractVolumeFeed((env,apiPath)=>kalshi(env,'GET',apiPath));
const sellContractVolume=new ContractVolumeFeed((env,apiPath)=>kalshi(env,'GET',apiPath));
const {ContractCounter}=require('./contract-counter');
const contractCounter=new ContractCounter((env,apiPath)=>kalshi(env,'GET',apiPath));
const Profiles = require('./settings-profiles');
const {SharedProfileLibrary}=require('./shared-profiles');
const {SessionConnections,fingerprint:connectionFingerprint,label:sessionLabel,occupied:sessionOccupied}=require('./session-connections');
const Safety = require('./public/safety-engine');
const Following = require('./public/following-trail-engine');
const Candle = require('./public/candle-reversal-engine');
const Line = require('./public/line-trail-engine');
const {VolatilityCandles}=require('./volatility-candles');
const volatilityCandles=new VolatilityCandles({enabled:process.env.NODE_ENV!=='test'});
const observationCandles=new VolatilityCandles({enabled:process.env.NODE_ENV!=='test'});
const ExitAudit = require('./exit-audit');
const {NowChop}=require('./now-chop');
const Observations=require('./volatility-observations');
const ChopBuy=require('./chop-buy-filter');
const volatilityScratch=new WeakMap();
const chopBuyLogs=new WeakMap();
const {KalshiIndex}=require('./kalshi-index');
const indexFeed=new KalshiIndex({signHeaders,enabled:process.env.NODE_ENV!=='test'});
// An independent public fallback keeps observation refreshes out of trade inputs.
const observationIndex=new KalshiIndex({enabled:process.env.NODE_ENV!=='test'});

const PORT = process.env.PORT || 5100;
const STATE_DIR = process.env.SPREAD_GUARD_STATE_DIR || __dirname;
const DATA_FILE = path.join(STATE_DIR, 'data.json');
const PUBLIC_DIR = path.join(__dirname, 'public');
// Production is fail-closed. Legacy engine fixtures can opt into the new
// application-level guards explicitly without changing their simulated worlds.
const STRICT_SESSION_IDENTITY=process.env.NODE_ENV!=='test'||process.env.STRICT_SESSION_IDENTITY==='1';
const SINGLE_AUTOMATION_LOCK=process.env.NODE_ENV!=='test'||process.env.SINGLE_AUTOMATION_LOCK==='1';
const connections=new SessionConnections({
  file:process.env.NODE_ENV==='test'?null:path.join(STATE_DIR,'session-connections.json'),
});

const BASES = {
  live: 'https://api.elections.kalshi.com',
  demo: 'https://demo-api.kalshi.co',
};
const {assets,matchesMarket}=require('./assets-config');
const extraData=Object.fromEntries(['ETH','SOL'].map(asset=>[asset,{
  feed:feed.createMarketFeed(asset),
  atr:new VolatilityCandles({asset,enabled:process.env.NODE_ENV!=='test'}),
  observations:new VolatilityCandles({asset,enabled:process.env.NODE_ENV!=='test'}),
}]));
const marketFeed=b=>extraData[b.settings.asset]?.feed||feed;
const atrFeed=b=>extraData[b.settings.asset]?.atr||volatilityCandles;
const observationFeed=b=>extraData[b.settings.asset]?.observations||observationCandles;
const DEFAULT_SETTINGS = {
  ...Entry.DEFAULTS,
  ...Buy.DEFAULTS,
  nowEntry: {...NowEntry.DEFAULTS},
  buyConditions: BuyConditions.validate(),
  nowExit: {...NowExit.DEFAULTS},
  asset: 'BTC',
  mode: 'paper',        // paper | demo | live
  triggerPoint: 90,     // BUY when a side's price is ABOVE this (cents)
  entryMethod: 'price', // price | spread
  rules: { ...Guard.DEFAULT_RULES },
  safety: { ...Safety.DEFAULTS },
  following: { ...Following.DEFAULTS },
  candleReversal: { ...Candle.DEFAULTS },
  lineTrail: { ...Line.DEFAULTS },
  dollars: 10,          // dollars to spend per entry
  slippage: 2,          // cents of price tolerance on IOC orders
};
const coinDefaults=new Map();
function defaultsFor(b){
  const asset=b.settings.asset;
  if(asset==='BTC')return DEFAULT_SETTINGS;
  if(coinDefaults.has(asset))return coinDefaults.get(asset);
  const s=structuredClone(DEFAULT_SETTINGS);
  s.asset=asset;s.upBuyNow=0;s.downBuyNow=0;
  // Non-BTC starts with no active legacy price-distance checks or exits.
  // Optional distances are illustrative placeholders, not BTC presets.
  for(const key of Object.keys(s.rules)){
    if(/^(up|down)(Buy)?Use(Spread|Target|Now)$/.test(key))s.rules[key]=false;
    if(/^(up|down)(Spread|Target|Now|Hold|Sell|NowOnlyThreshold|TrailActivation)$/.test(key))s.rules[key]=0;
  }
  for(const [settings,pattern] of [
    [s,/RebuyMove$/],[s.rules,/(TrailPullback|StairStep|TrailFromEntryMove)$/],
    [s.nowEntry,/(TrailMove|TrailPullback|StairStep|DirectionMove)$/],
    [s.following,/(MinimumDistance|MaximumDistance)$/],[s.lineTrail,/Distance$/],
    [s.candleReversal,/Activation$/],[s.safety,/^(maxVenueGap|maxSpread)$/],
  ])for(const key of Object.keys(settings))if(pattern.test(key))settings[key]=1;
  for(const key of Object.keys(s.nowEntry))
    if(/(Low|High)(Level|TargetLevel|KalshiLevel)$/.test(key))s.nowEntry[key]=key.endsWith('KalshiLevel')?0.01:0;
  coinDefaults.set(asset,s);
  return s;
}

// ---------- persistence ----------
let store = {};
if (process.env.NODE_ENV !== 'test') {
  try { store = JSON.parse(fs.readFileSync(DATA_FILE, 'utf8')); } catch { store = {}; }
}
let saveTimer = null;
const sharedProfiles=new SharedProfileLibrary({
  enabled:process.env.SHARED_PROFILES==='1'||!process.env.NODE_ENV||process.env.NODE_ENV==='production',
  file:process.env.NODE_ENV==='test'?null:path.join(STATE_DIR,'profiles-library.json'),
  records:store,
});
function persist() {
  if (process.env.NODE_ENV === 'test') return;
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    const out = { ...store }; // Preserve saved visitors not loaded since the last restart.
    for (const [id, v] of Object.entries(bots)) {
      const coinWorkspaces={...store[id]?.coinWorkspaces};
      for(const [asset,child] of coinBots.get(v)||[])coinWorkspaces[asset]=savedBot(child);
      out[id]={...savedBot(v),...(Object.keys(coinWorkspaces).length?{coinWorkspaces}:{})};
    }
    fs.writeFile(DATA_FILE + '.tmp', JSON.stringify(out), { mode: 0o600 }, err => {
      if (!err) fs.rename(DATA_FILE + '.tmp', DATA_FILE, () => {});
    });
  }, 300);
}
function savedBot(v){
  return {settings:v.settings,creds:v.creds,paper:v.paper,wasRunning:v.running,history:v.history,
    open:v.open,pendingSettle:v.pendingSettle,enteredTicker:v.enteredTicker,entryLedger:v.entryLedger,
    profiles:v.profiles,profilesShared:!!v.profilesShared,activeProfileId:v.activeProfileId,
    profileUndo:v.profileUndo,profilePaperOnly:v.profilePaperOnly,riskLedger:v.riskLedger,sellMarkers:v.sellMarkers,
    ...(v.settings.asset!=='BTC'?{coinReviewed:v.coinReviewed}:{}),
    ...(v.showContractCounter?{showContractCounter:true}:{}),
    ...(Object.keys(v.observationOptions).length?{observationOptions:v.observationOptions}:{}),
    ...(Object.keys(v.chopBuyOptions).length?{chopBuyOptions:v.chopBuyOptions}:{})};
}

// ---------- helpers ----------
const sleep = (ms) => process.env.NODE_ENV === 'test' ? Promise.resolve() : new Promise((r) => setTimeout(r, ms));
const cents = (d) => (d == null || d === '' ? null : Math.round(parseFloat(d) * 100));
const fineCents=d=>d!=null&&d!==''&&Number.isFinite(Number(d))?Math.round(Number(d)*10000)/100:null;
const clampC = (c) => Math.max(1, Math.min(99, Math.round(c)));
const priceStr = (c) => (clampC(c) / 100).toFixed(2);

function signHeaders(creds, method, fullPath) {
  const ts = Date.now().toString();
  const msg = ts + method.toUpperCase() + fullPath.split('?')[0];
  const key = crypto.createPrivateKey(creds.privateKey);
  let sig;
  if (key.asymmetricKeyType === 'ed25519') {
    sig = crypto.sign(null, Buffer.from(msg), key);
  } else {
    sig = crypto.sign('sha256', Buffer.from(msg), {
      key, padding: crypto.constants.RSA_PKCS1_PSS_PADDING, saltLength: crypto.constants.RSA_PSS_SALTLEN_DIGEST,
    });
  }
  return {
    'KALSHI-ACCESS-KEY': creds.keyId,
    'KALSHI-ACCESS-TIMESTAMP': ts,
    'KALSHI-ACCESS-SIGNATURE': sig.toString('base64'),
  };
}

async function kalshi(env, method, apiPath, { creds, body } = {}) {
  const fullPath = '/trade-api/v2' + apiPath;
  const headers = { Accept: 'application/json' };
  if (creds) Object.assign(headers, signHeaders(creds, method, fullPath));
  if (body) headers['Content-Type'] = 'application/json';
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), 8000);
  try {
    const res = await fetch(BASES[env] + fullPath, {
      method, headers, body: body ? JSON.stringify(body) : undefined, signal: ctrl.signal,
    });
    const text = await res.text();
    let json = null; try { json = JSON.parse(text); } catch {}
    if (!res.ok) {
      const m = json?.error?.message || json?.message || json?.error?.code || text.slice(0, 160) || res.statusText;
      const err = new Error(`HTTP ${res.status}: ${m}`); err.status = res.status; throw err;
    }
    return json;
  } finally { clearTimeout(t); }
}

// ---------- exchange shard funding ----------
// Kalshi keeps a separate cash balance per exchange shard (crypto markets live on shard 2).
// The Kalshi app moves cash automatically; API orders do not, so we top up the market's shard first.
async function kRetry(fn) {
  for (let i = 0; ; i++) {
    try { return await fn(); } catch (e) { if (e.status !== 429 || i >= 4) throw e; await sleep(600 * (i + 1)); }
  }
}
async function fundShard(b, creds, needDollars, recheckBuy) {
  const env = envOf(b);
  const idx = Number.isInteger(b.market?.exchangeIndex) ? b.market.exchangeIndex : 2;
  const shardBal = (bal) => {
    const row = (bal.balance_breakdown || []).find((x) => x.exchange_index === idx);
    return row ? parseFloat(row.balance) : idx === 0 ? parseFloat(bal.balance_dollars ?? bal.balance / 100) : 0;
  };
  const bal = await kRetry(() => kalshi(env, 'GET', '/portfolio/balance', { creds }));
  const have = shardBal(bal);
  if (have >= needDollars) return;
  let short = needDollars - have;
  const sources = (bal.balance_breakdown || [])
    .filter((x) => x.exchange_index !== idx && parseFloat(x.balance) > 0)
    .sort((a, z) => (a.exchange_index === 0 ? -1 : z.exchange_index === 0 ? 1 : 0));
  for (const src of sources) {
    if (short <= 0) break;
    const centicents = Math.floor(Math.min(short, parseFloat(src.balance)) * 10000);
    if (centicents < 1) continue;
    const transferId = crypto.randomUUID(); // same ID on retries so a transfer can't happen twice
    await kRetry(() => {
      recheckBuy?.();
      return kalshi(env, 'POST', '/portfolio/intra_exchange_instance_transfer', { creds, body: {
        client_transfer_id: transferId, source: 'event_contract', destination: 'event_contract', amount: centicents,
        source_exchange_shard: src.exchange_index, destination_exchange_shard: idx } });
    });
    addLog(b, `Moved $${(centicents / 10000).toFixed(2)} into your Kalshi crypto balance to fund the order`, 'info');
    short -= centicents / 10000;
  }
  if (short > 0.005) throw new Error(`Not enough cash: order needs about $${needDollars.toFixed(2)}, account has $${(needDollars - short).toFixed(2)}`);
  for (let i = 0; i < 6; i++) { // transfers settle asynchronously; go easy on rate limits
    await sleep(700);
    try { if (shardBal(await kalshi(env, 'GET', '/portfolio/balance', { creds })) >= needDollars - 0.001) return; } catch {}
  }
}
const feeFor = (count, p) => Math.ceil(0.07 * count * p * (1 - p) * 100) / 100;

// ---------- results ledger (wins / losses per closed trade) ----------
const c2 = (x) => Math.round(x * 100) / 100;
// Kalshi V2 fills are quoted in YES terms; pick the reading that matches the side we traded.
function sidePx(avgYes, side, expect) {
  if (!Number.isFinite(avgYes)) return expect;
  const a = side === 'yes' ? avgYes : 1 - avgYes, b2 = side === 'yes' ? 1 - avgYes : avgYes;
  return expect != null && Math.abs(b2 - expect) < Math.abs(a - expect) ? b2 : a;
}
function recordResult(b, row) {
  b.history = b.history || [];
  row={ at: Date.now(), mode: b.settings.mode, ...row, fees: c2(row.fees || 0), pnl: c2(row.pnl) };
  if(Number.isFinite(row.tradePnl))row.tradePnl=c2(row.tradePnl);
  Safety.recordResult(b.riskLedger,b.history,row);
  b.history.push(row);
  if (b.history.length > 500) b.history.splice(0, b.history.length - 500);
  const r = row.pnl;
  addLog(b, `Result: ${row.how.toUpperCase()} ${row.side.toUpperCase()} ${row.count} on ${row.ticker.split('-').slice(1).join('-')} ${r >= 0 ? '+' : '-'}$${Math.abs(r).toFixed(2)}`, r >= 0 ? 'good' : 'bad');
  persist();
}
function resultsSummary(b) {
  const rows = (b.history || []).filter((r) => r.mode === b.settings.mode);
  const wins = rows.filter((r) => r.pnl > 0).length, losses = rows.filter((r) => r.pnl < 0).length;
  const sum = (f) => c2(rows.reduce((a, r) => a + f(r), 0));
  const today = new Date(); today.setHours(0, 0, 0, 0);
  return {
    mode: b.settings.mode, trades: rows.length, wins, losses, even: rows.length - wins - losses,
    net: sum((r) => r.pnl), fees: sum((r) => r.fees || 0),
    today: c2(rows.filter((r) => r.at >= today.getTime()).reduce((a, r) => a + r.pnl, 0)),
    winRate: wins + losses ? Math.round((wins / (wins + losses)) * 100) : null,
    best: rows.length ? Math.max(...rows.map((r) => r.pnl)) : null,
    worst: rows.length ? Math.min(...rows.map((r) => r.pnl)) : null,
    // Keep full settings snapshots in the private ledger, not every 1s poll.
    rows: rows.slice(-60).reverse().map(({entryProfile,exitSettings,exitAudit,...row}) => ({
      ...row,
      ...(exitAudit?{exitAudit:ExitAudit.summary(exitAudit)}:{}),
      entryProfile: entryProfile ? {id:entryProfile.id,name:entryProfile.name,
        modified:entryProfile.modified,paperOnly:entryProfile.paperOnly} : null,
      settingsChangedDuringTrade: !!entryProfile?.config && !!exitSettings &&
        !Profiles.sameConfig(entryProfile.config,exitSettings),
    })),
  };
}

const observationOptions=b=>Observations.options(b.settings.mode,b.observationOptions[b.settings.mode]);
const chopBuyOptions=b=>ChopBuy.options(b.settings.mode,b.chopBuyOptions[b.settings.mode]);
function chopReading(b,at){
  const research=volatilityScratch.get(b);
  if(research?.mode!==b.settings.mode||!b.market||
    (Number.isFinite(b.market.closeTime)&&at>=b.market.closeTime))return new NowChop().snapshot(b.market,at);
  return research.chop.snapshot(b.market,at);
}
function chopBuyDecision(b,side,at=Date.now(),check=false){
  const config=chopBuyOptions(b),enabled=config[side.toLowerCase()]===true;
  if(enabled&&check)observeVolatility(b,at);
  const decision=ChopBuy.evaluate(enabled,enabled?chopReading(b,at):null,side,config.requireTwoCrossings);
  if(check&&enabled&&(!decision.allowed||decision.label==='UNAVAILABLE')){
    const key=JSON.stringify([b.settings.mode,b.market?.ticker,b.market?.strike]);
    let log=chopBuyLogs.get(b);
    if(log?.key!==key){log={key,seen:new Set()};chopBuyLogs.set(b,log);}
    const tag=side+':'+decision.label;
    if(!log.seen.has(tag)){log.seen.add(tag);addLog(b,decision.reason,decision.allowed?'info':'warn');}
  }
  return decision;
}
function observeVolatility(b,at){
  const switches=observationOptions(b),mode=b.settings.mode;
  const filter=chopBuyOptions(b),needsChop=switches.chop||filter.up||filter.down;
  if(!needsChop&&!switches.atr){volatilityScratch.delete(b);return;}
  let research=volatilityScratch.get(b);
  if(research?.mode!==mode){
    research={mode,chop:new NowChop(b.settings.asset),atr:null,lastAlertEnd:null};
    volatilityScratch.set(b,research);
  }
  try{
    if(needsChop){
      let point=indexFeed.peek(b,at);
      if(!point||point.sourceKind==='public_chart'){
        // Runs even with no app open. Only ingest received, timestamped values.
        observationIndex.publicSnapshot(b);
        const fallback=observationIndex.peek(b,at);
        if(fallback&&(!point||fallback.sourceTime>point.sourceTime))point=fallback;
      }
      research.chop.observe(b.market,point,at);
    }
  }catch{research.chop.reset();}
  try{
    if(switches.atr){
      const bars=observationFeed(b).snapshot(),minute=Math.floor(at/60000);
      if(research.atr&&research.candles===bars.candles&&research.minute===minute&&
        (!research.atr.candleEndAt||at-research.atr.candleEndAt<=90000))return;
      const prior=research.atr;
      research.atr=Observations.regime(bars.candles,at);
      research.candles=bars.candles;research.minute=minute;
      const {label,candleEndAt,atrUsd}=research.atr;
      if(label==='QUIET_TO_ACTIVE'&&prior?.label!=='QUIET_TO_ACTIVE'&&candleEndAt!==research.lastAlertEnd){
        research.lastAlertEnd=candleEndAt;
        const left=switches.timeLeft?Observations.timeLeft(b.market,at):null;
        addLog(b,`Volatility observation: quiet to active · Coinbase ATR $${atrUsd.toFixed(2)}`+
          (left===null?'':` · ${left}s left in market`)+'. No trade signal.');
      }
    }
  }catch{research.atr=null;}
}
function volatilitySnapshot(b,at){
  const switches=observationOptions(b),research=volatilityScratch.get(b);
  const current=research?.mode===b.settings.mode?research:null;
  const chop=switches.chop?chopReading(b,at):null;
  const end=current?.atr?.candleEndAt;
  const atr=switches.atr?(Number.isFinite(end)&&end<=at&&at-end<=90000?
    current.atr:Observations.unavailable()):null;
  const timeLeftSeconds=switches.timeLeft?Observations.timeLeft(b.market,at):null;
  if(chop&&!switches.timeLeft)delete chop.timeLeftSeconds;
  return {switches,chop,atr,timeLeftSeconds};
}
function annotateVolatilityEntry(b){
  const at=b.open.startedAt;
  observeVolatility(b,at);
  const {switches,chop,atr,timeLeftSeconds}=volatilitySnapshot(b,at);
  if(chop){
    b.open.entryNowChop=chop;
    const label=b.open.mode==='paper'?'Paper':'Live';
    addLog(b,`${label} entry Now chop: ${chop.label}${chop.score==null?'':` (${chop.score}/100)`}`+
      `${chop.reason?`. ${chop.reason}`:''}`);
  }
  if(switches.atr||switches.timeLeft){
    b.open.entryVolatility={at,observationOnly:true,...(atr?{atr}:{}),
      ...(switches.timeLeft?{timeLeftSeconds}:{})};
    // The existing Paper chop entry log remains unchanged for old batches.
    if(atr||!chop){
      const labels=[atr&&`ATR ${atr.label.replaceAll('_',' ').toLowerCase()}`,
        switches.timeLeft&&(timeLeftSeconds===null?'Time left unavailable':`${timeLeftSeconds}s left in market`)].filter(Boolean);
      addLog(b,`Entry volatility observation: ${labels.join(' · ')}.`);
    }
  }
}

function ledgerBuy(b, f) {
  if (!f || !(f.filled > 0)) return;
  const side = f.side, t = b.market.ticker;
  if (b.open && (b.open.ticker !== t || b.open.side !== side)) { b.pendingSettle.push({ ...b.open, at: Date.now() }); b.open = null; }
  if (!b.open) {
    Entry.record(b).entries += 1;
    b.open = { ticker: t, side, count: 0, avg: 0, fee: 0, closeTime: b.market.closeTime, mode: b.settings.mode, startedAt: Date.now() };
    b.open.tradeId=crypto.randomUUID();b.open.realizedPnl=0;b.open.entryCostTotal=0;
    b.open.entryProfile = Profiles.entryTag(b, defaultsFor(b));
    if(b.settings.nowEntry?.enabled)
      b.open.nowEntryConfig=NowEntry.validate(b.settings.nowEntry);
    const m=marketFeed(b).snapshot(b.market.strike,b.quote?.ts);
    b.open.entryNow=m.ready&&Number.isFinite(m.nowDiff)?m.nowDiff:null;
    try{annotateVolatilityEntry(b);}catch{} // Never interrupt bookkeeping for a fill.
    if(b.settings.lineTrail?.[(side==='yes'?'up':'down')+'Enabled']===true)
      b.open.lineTarget=b.market.strike;
    const following=Following.validate(b.settings.following);
    if(following[(side==='yes'?'up':'down')+'Mode']==='volatility'){
      const bars=atrFeed(b).snapshot();
      b.open.followingEntry={atr:bars.atr,observedAt:bars.observedAt,
        at:b.open.startedAt,source:'Coinbase closed 1m simple-mean TR14'};
    }
    updateExitDecision(b,m,side==='yes'?'UP':'DOWN',Date.now());
  }
  const o = b.open, n = o.count + f.filled;
  o.entryCostTotal=(o.entryCostTotal??o.avg*o.count+o.fee)+f.px*f.filled+f.fee;
  o.avg = (o.avg * o.count + f.px * f.filled) / n; o.count = n; o.fee += f.fee;
  persist();
}
function ledgerSell(b, f, how) {
  const o = b.open;
  if (!o || !f || !(f.filled > 0) || o.ticker !== b.market?.ticker) return;
  const q = Math.min(o.count, f.filled);
  const entryFee = o.fee * (q / o.count);
  const pnl = (f.px - o.avg) * q - f.fee * (q / f.filled) - entryFee;
  o.realizedPnl=(o.realizedPnl||0)+pnl;
  const entryRecord = Entry.record(b);
  const soldAt=Date.now(),m=marketFeed(b).snapshot(b.market.strike,b.quote?.ts);
  const completed=q>=o.count-1e-9;
  const sale=Entry.recordSale(b,{side:o.side,filled:q,px:f.px},
    m.ready&&Number.isFinite(m.nowDiff)?m.nowDiff:null,completed,soldAt);
  if(how==='timed percentage cash-out'&&b.settings.rules[(o.side==='yes'?'up':'down')+'CashoutStopReentry']!==false)
    o.cashoutLock=true;
  const exitAudit=ExitAudit.fill(o,{now:soldAt,count:q,price:f.px,pnl,completed,mode:b.settings.mode});
  recordResult(b, { ticker: o.ticker, side: o.side, count: q, entry: c2(o.avg), exit: f.px, how, fees: entryFee + f.fee * (q / f.filled), pnl,
    tradeId:o.tradeId||`${o.mode||b.settings.mode}:${o.ticker}:${o.startedAt||0}`,
    completed,tradePnl:o.realizedPnl,soldNow:sale.now,soldNowAt:soldAt,
    ...(o.entryNowChop?{entryNowChop:o.entryNowChop}:{}),
    ...(o.entryVolatility?{entryVolatility:o.entryVolatility}:{}),
    entryProfile: o.entryProfile || null, exitSettings: Profiles.snapshot(b.settings),exitAudit });
  o.count -= q; o.fee -= entryFee;
  if (o.count <= 1e-9) {
    if(o.cashoutLock)entryRecord.cashoutLocked=true;
    b.open = null;
    entryRecord.lastSellAt = soldAt;
    b.entrySignals = {};
  }
  persist();
}
async function settleLedger(b) {
  if (!b.pendingSettle.length || Date.now() - b.lastSettleCheck < 10000) return;
  b.lastSettleCheck = Date.now();
  for (const it of [...b.pendingSettle]) {
    if (Date.now() < (it.closeTime || 0) + 15000) continue;
    if(b.root&&!matchesMarket(b.settings.asset,it.ticker))continue;
    try {
      const r = await kalshi(envOf(b), 'GET', `/markets/${it.ticker}`, { creds: readCreds(b) });
      if(b.root&&r.market?.ticker!==it.ticker)continue;
      const res = r.market?.result;
      if (res !== 'yes' && res !== 'no') continue;
      const won = res === it.side, payout = won ? it.count : 0;
      b.pendingSettle = b.pendingSettle.filter((x) => x !== it);
      const prevMode = b.settings.mode; b.settings.mode = it.mode || prevMode;
      recordResult(b, { ticker: it.ticker, side: it.side, count: it.count, entry: c2(it.avg), exit: payout ? 1 : 0,
        how: won ? 'won' : 'lost', fees: it.fee, pnl: payout - it.avg * it.count - it.fee,
        completed:true,tradeId:it.tradeId,
        tradePnl:payout-it.avg*it.count-it.fee+(it.realizedPnl||0),
        ...(it.entryNowChop?{entryNowChop:it.entryNowChop}:{}),
        ...(it.entryVolatility?{entryVolatility:it.entryVolatility}:{}),
        entryProfile: it.entryProfile || null,
        ...(it.exitAudit?{exitAudit:structuredClone(it.exitAudit)}:{}) });
      b.settings.mode = prevMode;
    } catch {}
  }
}

// ---------- bot ----------
const bots = {};
const coinBots=new Map();
const allBots=()=>Object.values(bots).flatMap(root=>[root,...(coinBots.get(root)?.values()||[])]);

function newBot(id,asset='BTC',root=null) {
  const saved = (asset==='BTC'? store[id] : store[id]?.coinWorkspaces?.[asset]) || {};
  const defaults=defaultsFor({settings:{asset}});
  const rules={...(asset==='BTC'?{}:defaults.rules),...saved.settings?.rules};
  const b = {
    id,root,coinReviewed:saved.coinReviewed===true,showContractCounter:saved.showContractCounter===true,
    observationOptions:Object.fromEntries(['paper','live'].filter(m=>saved.observationOptions?.[m])
      .map(m=>[m,Observations.options(m,saved.observationOptions[m])])),
    chopBuyOptions:Object.fromEntries(['paper','live'].filter(m=>saved.chopBuyOptions?.[m])
      .map(m=>[m,ChopBuy.options(m,saved.chopBuyOptions[m])])),
    settings: { ...defaults, ...(saved.settings || {}), asset,
      rules: Guard.migrateRules(rules),
      nowEntry: NowEntry.validate(saved.settings?.nowEntry??defaults.nowEntry),
      buyConditions: BuyConditions.validate(saved.settings?.buyConditions),
      nowExit: NowExit.validate(saved.settings?.nowExit),
      safety: Safety.validate(saved.settings?.safety??defaults.safety),
      following: Following.validate(saved.settings?.following??defaults.following),
      candleReversal: Candle.validate(saved.settings?.candleReversal??defaults.candleReversal),
      lineTrail: Line.validate(saved.settings?.lineTrail??defaults.lineTrail) },
    candleReversalState:null,
    creds: saved.creds || null,
    profiles: Array.isArray(saved.profiles) ? saved.profiles : [],
    activeProfileId: saved.activeProfileId || null,
    profileUndo: saved.profileUndo || null,
    profilePaperOnly: saved.profilePaperOnly === true,
    paper: saved.paper || { cash: 1000, pos: 0, side: null, avg: 0, pnl: 0, trades: 0, wins: 0, pending: [] },
    history: saved.history || [],
    open: saved.open || null,            // this bot's own open trade {ticker, side:'yes'|'no', count, avg, fee}
    pendingSettle: saved.pendingSettle || [],
    lastSettleCheck: 0,
    running: false,
    phase: 'IDLE',
    market: null,          // {ticker, closeTime, openTime, strike, title}
    quote: null,           // {upAsk, upBid, downAsk, downBid, ts}
    position: 0,           // >0 UP (yes) contracts, <0 DOWN (no) contracts
    balance: null,
    log: [],
    lastPoll: Date.now(),
    loopActive: false,
    busy: false,
    lastPosFetch: 0,
    lastBalFetch: 0,
    lastMarketFetch: 0,
    error: null,
    sessionTicker: null,
    enteredTicker: saved.enteredTicker || null,
    entryLedger: saved.entryLedger || {},
    sellMarkers: Array.isArray(saved.sellMarkers)?saved.sellMarkers:[],
    guard: Guard.blank(),
    guardDecision: null,
    entrySignals: {},
    safetyEntries: {},
    riskLedger: saved.riskLedger || {days:{},markets:{}},
    safetyStatus: null,
    book: null,
    lastBookFetch: 0,
    bookRetryAt: 0,
    nowHistory: [],
    chartTicker: null,
    armedLive: false,
  };
  // Pin this session's existing Paper-only permission before exposing shared
  // snapshots. Editing a library profile must not change another session's mode.
  if(asset==='BTC'&&sharedProfiles.enabled&&!saved.profilesShared&&saved.profiles?.find(p=>p.id===b.activeProfileId)?.paperOnly)
    b.profilePaperOnly=true;
  if(asset==='BTC'){
    sharedProfiles.attach(b);
    bots[id] = b;
    coinBots.set(b,new Map());
    for(const coin of ['ETH','SOL'])if(saved.coinWorkspaces?.[coin])getCoinBot(b,coin);
  }else{
    coinBots.get(root).set(asset,b);
    if(process.env.NODE_ENV!=='test')marketFeed(b).start();
  }
  Safety.hydrate(b.riskLedger,b.history,Date.now());
  if(b.open?.trail){ b.open.trail.since=null;b.open.trail.last=null; }
  if(b.open?.stair){ b.open.stair.since=null;b.open.stair.last=null; }
  // Never resume real-money automation after a process restart.
  if (saved.wasRunning) addLog(b, 'Restarted safely stopped. Review your position before starting.', 'warn');
  if (process.env.NODE_ENV !== 'test') ensureLoop(b);
  return b;
}
function getBot(id) { return Object.hasOwn(bots,id) ? bots[id] : newBot(id); }
function getCoinBot(root,asset){
  if(asset==='BTC')return root;
  if(!Object.hasOwn(assets,asset))throw Error('Unsupported coin.');
  return coinBots.get(root).get(asset)||newBot(root.id,asset,root);
}
function workspaceStatus(b){
  const root=b.root||b,children=coinBots.get(root);
  return Object.keys(assets).map(asset=>{
    const bot=asset==='BTC'?root:children?.get(asset);
    return {asset,mode:bot?.settings.mode||'paper',running:!!bot?.running,armed:!!bot?.armedLive,
      position:!!(bot?.open||bot?.position||bot?.paper?.pos),
      settling:!!(bot?.pendingSettle?.length||bot?.paper?.pending?.length)};
  });
}
function hasSession(id){return Object.hasOwn(bots,id)||Object.hasOwn(store,id);}
function duplicateConnection(b){
  if(b.settings.mode==='paper')return null;
  const fp=connectionFingerprint(b.creds);if(!fp)return null;
  return allBots().find(other=>other!==b&&other.running&&
    other.settings.mode===b.settings.mode&&connectionFingerprint(other.creds)===fp)||null;
}
function otherActiveBot(b){
  if(!SINGLE_AUTOMATION_LOCK)return null;
  return allBots().find(other=>other!==b&&
    (other.running||other.armedLive||['BUYING','SELLING','MANUAL'].includes(other.phase)))||null;
}
function singleBotBlocked(res,b){
  const other=otherActiveBot(b);
  if(!other)return false;
  send(res,409,{code:'ANOTHER_BOT_ACTIVE',
    error:`Another ${other.settings.asset} bot is running, armed, or finishing an order. Stop it before starting or arming another bot.`});
  return true;
}

function addLog(b, msg, kind = 'info') {
  b.log.push({ t: Date.now(), msg, kind });
  if (b.log.length > 200) b.log.splice(0, b.log.length - 200);
}

// Sign public reads with the user's key when it matches the environment (higher per-account rate limit)
function readCreds(b) { return b.creds && (b.creds.env || 'live') === envOf(b) ? b.creds : undefined; }
function tradeCreds(b) { return b.settings.mode !== 'paper' ? readCreds(b) : undefined; }
function envOf(b) { return b.settings.mode === 'demo' ? 'demo' : 'live'; }
function remainingSec(b) { return b.market ? Math.floor((b.market.closeTime - Date.now()) / 1000) : null; }

async function findMarket(b) {
  const asset=b.settings.asset,series=assets[asset]?.series;
  if(!series)throw Error('Unsupported coin; no market selected.');
  const r = await kalshi(envOf(b), 'GET', `/markets?series_ticker=${series}&status=open&limit=20&_=${Date.now()}`, { creds: readCreds(b) });
  const now = Date.now();
  const list = (r.markets || [])
    .map((m) => ({
      ticker: m.ticker, eventTicker: m.event_ticker, closeTime: Date.parse(m.close_time), openTime: Date.parse(m.open_time), exchangeIndex: m.exchange_index,
      strike: m.floor_strike, title: m.title, sub: m.yes_sub_title,
    }))
    .filter((m) => m.closeTime > now && m.openTime <= now &&
      (asset==='BTC'||(matchesMarket(asset,m.ticker)&&matchesMarket(asset,m.eventTicker))))
    .sort((a, c) => a.closeTime - c.closeTime);
  return list[0] || null;
}

async function refreshQuote(b) {
  if (!b.market) return;
  const requestedAt=Date.now();
  let r;
  try{
    r = await kalshi(envOf(b), 'GET', `/markets/${b.market.ticker}`, { creds: readCreds(b) });
  }catch(e){
    if(ownedTrade(b)){
      ExitAudit.event(b.open,Date.now(),b.settings.mode,{type:'quote-error',requestedAt,
        error:String(e.message).slice(0,240)});
      persist();
    }
    throw e;
  }
  const receivedAt=Date.now();
  const m = r.market || {};
  if(b.settings.asset!=='BTC'&&m.ticker!==b.market.ticker){
    b.quote=null;
    throw Error('Kalshi returned a quote for a different market.');
  }
  const toCents=b.settings.asset==='BTC'?cents:fineCents;
  if(b.settings.asset!=='BTC')b.market.priceLevelStructure=m.price_level_structure;
  b.quote = {
    ticker:b.market.ticker,
    upAsk: toCents(m.yes_ask_dollars), upBid: toCents(m.yes_bid_dollars),
    downAsk: toCents(m.no_ask_dollars), downBid: toCents(m.no_bid_dollars),
    status: m.status, ts: receivedAt, requestedAt, receivedAt,
    requestLatencyMs:Math.max(0,receivedAt-requestedAt),
  };
  const strike = Number(m.floor_strike);
  if (m.floor_strike != null && Number.isFinite(strike)) b.market.strike = strike;
  if (m.yes_sub_title) b.market.sub = m.yes_sub_title;
}

async function refreshPosition(b, force = false) {
  if (b.settings.mode === 'paper') {
    const p = b.paper;
    if (!p.pos || p.ticker !== b.market?.ticker) b.position = 0;
    else b.position = p.side === 'yes' ? p.pos : p.side === 'no' ? -p.pos : 0;
    b.balance = p.cash;
    return b.position;
  }
  if (!tradeCreds(b) || !b.market) { b.position = 0; return 0; }
  const now = Date.now();
  if (force || now - b.lastPosFetch > 2000) {
    const r = await kalshi(envOf(b), 'GET', `/portfolio/positions?ticker=${b.market.ticker}&count_filter=position`, { creds: b.creds });
    if(!Array.isArray(r?.market_positions))throw new Error('Invalid position snapshot; no position inferred.');
    const mp = r.market_positions.find((x) => x.ticker === b.market.ticker);
    const raw=mp?(mp.position_fp??mp.position):0;
    const n=typeof raw==='number'||typeof raw==='string'&&raw.trim()!==''?Number(raw):NaN;
    if(!Number.isFinite(n))throw new Error('Invalid position quantity; no position inferred.');
    b.position=n;
    b.lastPosFetch=now;
  }
  if (force || now - b.lastBalFetch > 10000) {
    b.lastBalFetch = now;
    try {
      const bal = await kalshi(envOf(b), 'GET', '/portfolio/balance', { creds: b.creds });
      b.balance = bal.balance_dollars != null ? parseFloat(bal.balance_dollars) : (bal.balance != null ? bal.balance / 100 : null);
    } catch (e) { /* non-fatal */ }
  }
  return b.position;
}

function entrySignalChanged(message) {
  return Object.assign(new Error(message), { code: 'ENTRY_SIGNAL_CHANGED' });
}
function checkBuySafety(b,side,count,automatic) {
  try { assertSafeBuy(b,side,count,automatic); }
  catch(e) { if(automatic)throw entrySignalChanged(e.message);throw e; }
}

// Place an immediate-or-cancel order. The optional attempt record is set BEFORE
// any buy mutation/submission, never inferred from an error string or response.
async function placeOrder(b, side, action, count, submission = null) {
  const q = b.quote; const s = b.settings;
  if(s.asset!=='BTC'){
    if(!matchesMarket(s.asset,b.market?.ticker)||q?.ticker!==b.market?.ticker)
      throw Error('No matching coin market and quote. No order sent.');
    if(!['active','open'].includes(q.status)||!(remainingSec(b)>=0))
      throw Error('This coin market is not open for orders.');
    if(action==='buy'&&!b.coinReviewed)throw Error('Review this coin’s trading setup before buying.');
  }
  if (Profiles.paperOnly(b, defaultsFor(b)) && s.mode !== 'paper') throw new Error('The loaded trial profile is Paper-only. No exchange order sent.');
  if (!q) throw new Error('No quote');
  if (!b.running && b.phase !== 'MANUAL') throw new Error('Bot was stopped. No new order sent.');
  const checkEntryWindow=()=>{
    if(action!=='buy')return;
    const w=EntryWindow.evaluate(b.settings,b.market,Date.now());
    if(!w.allowed)throw entrySignalChanged(w.reason+' No buy sent.');
  };
  const checkChopBuy=()=>{
    if(action!=='buy'||b.phase==='MANUAL')return;
    const d=chopBuyDecision(b,side,Date.now(),true);
    if(!d.allowed)throw entrySignalChanged(d.reason+' No buy sent.');
  };
  checkEntryWindow();
  if (action === 'buy' && (remainingSec(b) == null || remainingSec(b) <= 5)) throw new Error('No new entries in the final five seconds.');
  if (Date.now() - q.ts > 10000) throw new Error('Quote is stale. No order sent.');
  if(action==='buy')checkBuySafety(b,side,count,b.phase!=='MANUAL'||s.nowEntry?.enabled);
  const requirePriceSignal = action === 'buy' && (s.nowEntry?.enabled||b.phase !== 'MANUAL'&&s.entryMethod !== 'spread');
  if (requirePriceSignal) {
    const signal = automaticBuySignal(b,marketFeed(b).snapshot(b.market?.strike,q.ts),side);
    if (!signal.passed) throw entrySignalChanged(`Automatic buy blocked: ${signal.reason}`);
  }
  checkChopBuy();
  if (b.settings.mode !== 'paper' && !b.armedLive) throw new Error('Arm trading in this copy first.');
  const expected = side === 'UP' ? (action === 'buy' ? q.upAsk : q.upBid) : (action === 'buy' ? q.downAsk : q.downBid);
  if (!Number.isFinite(expected) || expected <= 0 || expected >= 100) throw new Error('No executable quote.');
  const slip = Number(s.slippage) || 0;
  // V2 endpoint quotes everything in YES price. bid = buy YES / sell NO; ask = sell YES / buy NO.
  let bookSide, yesPrice;
  if (side === 'UP' && action === 'buy') { bookSide = 'bid'; yesPrice = q.upAsk + slip; }
  else if (side === 'UP' && action === 'sell') { bookSide = 'ask'; yesPrice = q.upBid - slip; }
  else if (side === 'DOWN' && action === 'buy') { bookSide = 'ask'; yesPrice = 100 - (q.downAsk + slip); }
  else { bookSide = 'bid'; yesPrice = 100 - (q.downBid - slip); }
  const orderYesPrice=()=>{
    if(s.asset==='BTC')return priceStr(yesPrice);
    const tapered=b.market.priceLevelStructure==='tapered_deci_cent';
    const min=tapered?0.1:1,max=100-min;
    // A buy limit rounds down; a sell limit rounds up. Never expand slippage.
    const bounded=Math.min(max,Math.max(min,yesPrice));
    const scale=tapered&&(bounded<=10||bounded>=90)?10:1;
    const ticks=bookSide==='bid'?Math.floor(bounded*scale+1e-8):Math.ceil(bounded*scale-1e-8);
    return (ticks/scale/100).toFixed(tapered?4:2);
  };
  const execNoPrice = (c) => (side === 'DOWN' ? 100 - c : c);
  const recheckMonitorSell=()=>{
    if(action!=='sell'||b.phase!=='SELLING'||
      (b.guardDecision?.exitKind!=='contract-volume'&&!b.settings.nowExit?.enabled&&!Candle.validate(s.candleReversal)[(side==='UP'?'up':'down')+'Enabled']&&
        !Line.validate(s.lineTrail)[(side==='UP'?'up':'down')+'Enabled']))return;
    if(!ownedTrade(b)||ownedSide(b)!==side)throw Error('No matching strategy-owned position to sell.');
    const d=updateExitDecision(b,marketFeed(b).snapshot(b.market.strike,b.quote?.ts),side,Date.now());
    if(d.action!=='SELL'||!b.running)throw Error('Automatic sell conditions changed before submission. No sell sent.');
  };

  if (s.mode === 'paper') {
    checkEntryWindow();
    recheckMonitorSell();
    const p = b.paper;
    const fill = side === 'UP' ? (action === 'buy' ? q.upAsk : q.upBid) : (action === 'buy' ? q.downAsk : q.downBid);
    if (fill == null || fill <= 0) throw new Error('No liquidity at this moment');
    if (action === 'buy') {
      const cost = (fill * count) / 100;
      if (cost > p.cash) throw new Error('Not enough paper cash');
      if (p.pos) throw new Error('Paper position already exists.');
      if(submission)submission.attempted=true;
      p.cash -= cost; p.pos = count; p.side = side === 'UP' ? 'yes' : 'no'; p.avg = fill; p.ticker = b.market.ticker;
      p.entryCost = cost;
    } else {
      if (!p.pos || p.side !== (side === 'UP' ? 'yes' : 'no')) throw new Error('No matching position to close.');
      count = Math.min(count, p.pos);
      const token=ExitAudit.submitted(b.open,{now:Date.now(),count,price:fill/100,
        execution:'paper',exitKind:b.phase==='SELLING'?b.guardDecision?.exitKind:'manual'});
      const proceeds = (fill * count) / 100;
      const pnl = proceeds - (p.avg * count) / 100;
      p.cash += proceeds; p.pnl += pnl; p.trades += 1; if (pnl > 0) p.wins += 1;
      addLog(b, `Paper P&L on close: ${pnl >= 0 ? '+' : ''}$${pnl.toFixed(2)}`, pnl >= 0 ? 'good' : 'bad');
      p.pos -= count;
      if (!p.pos) { p.side = null; p.avg = 0; }
      ExitAudit.response(b.open,token,Date.now(),{filled:count});
    }
    persist();
    return { fill_count: count, average_fill_price: (fill / 100).toFixed(s.asset==='BTC'?2:4), _fill: { side: side === 'UP' ? 'yes' : 'no', filled: count, px: fill / 100, fee: 0 } };
  }

  if (!tradeCreds(b)) throw new Error(`Add a ${envOf(b)} Kalshi API key in Settings`);
  const body = {
    ticker: b.market.ticker,
    client_order_id: crypto.randomUUID(),
    side: bookSide,
    count: String(count),
    price: orderYesPrice(),
    time_in_force: 'immediate_or_cancel',
    self_trade_prevention_type: 'taker_at_cross',
  };
  if (action === 'sell') body.reduce_only = true;
  if (action === 'buy' && s.asset==='BTC') {
    const p = (side === 'UP' ? yesPrice : 100 - yesPrice) / 100;
    await fundShard(b, b.creds, count * p + feeFor(count, p) + 0.02,
      b.phase!=='MANUAL'&&chopBuyOptions(b)[side.toLowerCase()]?checkChopBuy:null);
  }
  if (!b.running && b.phase !== 'MANUAL') throw new Error('Bot was stopped. No new order sent.');
  if (action === 'buy' && (remainingSec(b) <= 5 || Date.now() - q.ts > 10000)) {
    throw new Error('Entry window or fresh quote expired before submission. No buy sent.');
  }
  if (requirePriceSignal) {
    const signal = automaticBuySignal(b,marketFeed(b).snapshot(b.market?.strike, q.ts),side);
    if (!signal.passed) throw entrySignalChanged(`Automatic buy blocked before submission: ${signal.reason}`);
  }
  if(action==='buy')checkBuySafety(b,side,count,b.phase!=='MANUAL'||s.nowEntry?.enabled);
  checkEntryWindow();
  checkChopBuy();
  recheckMonitorSell();
  if(submission)submission.attempted=true;
  const auditedOpen=action==='sell'?b.open:null;
  const auditToken=action==='sell'?ExitAudit.submitted(auditedOpen,{now:Date.now(),count,
    price:expected/100,execution:s.mode,
    exitKind:b.phase==='SELLING'?b.guardDecision?.exitKind:'manual',
    clientOrderId:body.client_order_id}):null;
  if(auditToken!==null)persist();
  let r;
  try{
    r = await kalshi(envOf(b), 'POST', '/portfolio/events/orders', { creds: b.creds, body });
    ExitAudit.response(auditedOpen,auditToken,Date.now(),{filled:Number(r?.fill_count)});
    if(auditToken!==null)persist();
  }catch(e){
    ExitAudit.response(auditedOpen,auditToken,Date.now(),{error:e.message});
    if(auditToken!==null)persist();
    throw e;
  }
  const rawFilled=r?.fill_count;
  const reportedFilled=['number','string'].includes(typeof rawFilled)&&String(rawFilled).trim()!==''?
    Number(rawFilled):NaN;
  if(action==='buy'&&(!Number.isFinite(reportedFilled)||reportedFilled<0||reportedFilled>count+1e-9))
    throw Error('Buy response did not confirm a valid filled quantity. An order may have been submitted; check orders and positions before retrying.');
  const filled = action==='buy'?reportedFilled:parseFloat(r.fill_count)||0;
  const tside = side === 'UP' ? 'yes' : 'no';
  const expect = (side === 'UP' ? (action === 'buy' ? q.upAsk : q.upBid) : (action === 'buy' ? q.downAsk : q.downBid)) / 100;
  const px = sidePx(parseFloat(r.average_fill_price), tside, expect);
  const avgFee = parseFloat(r.average_fee_paid);
  r._fill = { side: tside, filled, px: Math.round(px * 10000) / 10000, fee: filled > 0 ? (Number.isFinite(avgFee) ? avgFee * filled : feeFor(filled, px)) : 0 };
  return r;
}

function heldSide(b) { return b.position > 0 ? 'UP' : b.position < 0 ? 'DOWN' : null; }
// An exchange snapshot is observation, not proof that our confirmed fill vanished.
// Ownership is retired only by confirmed sell fills or market rollover/settlement.
function ownedTrade(b) {
  const o=b.open;
  return o&&b.market&&o.ticker===b.market.ticker&&(!o.mode||o.mode===b.settings.mode)&&
    Number.isFinite(o.count)&&o.count>0&&['yes','no'].includes(o.side)?o:null;
}
function ownedSide(b) {
  const o=ownedTrade(b);
  return o?(o.side==='yes'?'UP':'DOWN'):null;
}
function positionStatus(b) {
  const o=ownedTrade(b),side=ownedSide(b),exchange=b.position;
  const mismatch=!!o&&(!Number.isFinite(exchange)||heldSide(b)!==side||
    Math.abs(Math.abs(exchange)-o.count)>1e-9);
  return {owned:!!o,side,recordedCount:o?.count??0,
    exchangeCount:Number.isFinite(exchange)?exchange:null,reconciling:mismatch,
    reason:mismatch?'Position snapshot differs from recorded fills. Recorded ownership retained; new buys blocked. Enabled exits remain monitored while running. Check Kalshi for external changes.':
      o?'Recorded strategy position matches the latest exchange snapshot.':'No recorded current-market strategy position.'};
}

function plannedCount(b,side){
  const px=side==='UP'?b.quote?.upAsk:b.quote?.downAsk;
  if(!Number.isFinite(px)||px<=0)return 0;
  return Math.floor(b.settings.dollars*100/(px+(b.settings.mode==='paper'?0:Number(b.settings.slippage)||0)));
}
function riskSnapshot(b,now=Date.now()){
  const t=Safety.totals(b.riskLedger,b.history||[],b.settings.mode,b.market?.ticker||'no-market',now);
  const mtm=Safety.mark(b.open,b.quote,b.market,b.settings.mode,now,feeFor);
  return {...Safety.limits(b.settings.safety,t,mtm),mark:mtm};
}
function updateRiskLimits(b,now){
  const r=riskSnapshot(b,now),t=Safety.totals(b.riskLedger,b.history||[],b.settings.mode,b.market?.ticker||'no-market',now);
  let changed=false;
  for(const [s,key,hit]of [[t.marketStats,'lossLocked',r.marketHit],[t.dayStats,'lossLocked',r.dayHit],
    [t.dayStats,'losersLocked',r.losingHit]]){
    if(hit&&!s[key]){s[key]=true;changed=true;}
  }
  if(changed)persist();
  b.safetyStatus=r;return r;
}
function buyFilters(b,m,side,count=plannedCount(b,side),now=Date.now()){
  const q=b.quote?{...b.quote,_buySlippage:b.settings.mode==='paper'?0:Number(b.settings.slippage)||0}:null;
  const filters=Safety.entryFilters(b.settings.safety,q,m,b.book,side,count,b.market,now);
  const cashout=Cashout.entryGuard(b.settings.rules,q,b.market,side,now);
  filters.checks.push({name:'Timed cash-out conflict',enabled:cashout.enabled,passed:cashout.allowed,
    detail:cashout.reason});
  filters.allowed=filters.allowed&&cashout.allowed;
  if(!cashout.allowed)filters.blockers.push(cashout.reason);
  const nowOnly=Safety.nowOnlyEntry(b.settings.safety,b.settings.rules,m,side);
  filters.checks.push({name:'Now-only sell conflict',enabled:nowOnly.enabled,passed:nowOnly.allowed,detail:nowOnly.reason});
  filters.allowed=filters.allowed&&nowOnly.allowed;
  if(!nowOnly.allowed)filters.blockers.push(nowOnly.reason);
  const protection=entryProtectionGate(b,m,side);
  filters.checks.push({name:'Immediate entry protection',enabled:protection.enabled,
    passed:protection.allowed,detail:protection.reason});
  // Automatic-only: manual buys bypass this optional gate, like confirmation.
  const volume=Volume.evaluate(b.settings.rules,contractVolume.snapshot(envOf(b),b.market?.ticker),
    b.market,side,now,envOf(b));
  const rebuy=Entry.rebuy(b,m,side);
  return {...filters,cashout,nowOnly,volume,rebuy,protection,
    automaticAllowed:filters.allowed&&volume.allowed&&rebuy.allowed&&protection.allowed};
}
function entryProtectionGate(b,m,side) {
  const enabled=b.settings.safety.requireEntryProtection===true;
  const p=side==='UP'?'up':'down';
  const allowed=!enabled||b.settings.rules[p+'EntryProtectionEnabled']===true&&
    m?.ready===true&&Number.isFinite(m.nowDiff);
  return {enabled,allowed,reason:!enabled?'Immediate-protection buy requirement is off.':
    allowed?`${side} entry protection is enabled and fresh Now can anchor the stop.`:
      `Automatic ${side} buy blocked: enable ${side} entry-point protection and require fresh Now.`};
}
const directionMarket=b=>b.market?.ticker?`${b.settings.mode}:${b.market.ticker}:${b.market.strike}`:null;
const conditionKey=b=>JSON.stringify(BuyConditions.validate(b.settings.buyConditions));
const needsEntryIndex=b=>NowEntry.needsKalshi(b.settings.nowEntry)||BuyConditions.needsKalshi(b.settings.buyConditions);
const alternatives=(b,m,index,now=Date.now())=>Object.fromEntries(['up','down'].map(p=>
  [p,BuyConditions.evaluate(b.settings.buyConditions,m,index,p.toUpperCase(),now,b.market)]));
function refreshNowDirection(b,m,index,now=Date.now()){
  if(!EntryWindow.evaluate(b.settings,b.market,now).allowed){b.nowDirection=null;return;}
  b.nowDirection=NowDirection.observe(b.nowDirection,b.settings.nowEntry,m,index,
    directionMarket(b),now,!b.open&&!heldSide(b),alternatives(b,m,index,now),conditionKey(b));
}
function nowEntrySignal(b,m,side,advance=false){
  const index=needsEntryIndex(b)?indexFeed.snapshot(b):null;
  if(advance)refreshNowDirection(b,m,index);
  const direction=NowDirection.inspect(b.nowDirection,b.settings.nowEntry,directionMarket(b),Date.now(),conditionKey(b));
  return NowEntry.evaluate(b.settings.nowEntry,m,side,index,direction[side],alternatives(b,m,index));
}
function automaticBuySignal(b,m,side){
  return b.settings.nowEntry?.enabled?nowEntrySignal(b,m,side,true):
    Buy.evaluate(b.settings,b.quote,m,side);
}
function rawBuySignal(b,m,side){
  if(b.settings.nowEntry?.enabled)return nowEntrySignal(b,m,side).passed;
  if(b.settings.entryMethod!=='spread')return Buy.evaluate(b.settings,b.quote,m,side).passed;
  const c=Guard.entryChecks(b.settings.rules,m,side).filter(c=>c.enabled);
  return m?.ready===true&&c.length>0&&c.every(c=>c.passed);
}
function updateSafetyEntries(b,m,now){
  const limits=b.safetyStatus||riskSnapshot(b,now),entry=Entry.status(b,now);
  const eligible=b.running&&!b.open&&!b.position&&entry.allowed&&limits.allowed&&
    m?.ready===true&&Safety.quoteFresh(b.quote,b.market,now);
  const rec=Entry.record(b);
  for(const side of ['UP','DOWN']){
    const f=buyFilters(b,m,side,plannedCount(b,side),now);
    const validFeed=f.checks.find(c=>c.name==='Feed age / disagreement');
    b.safetyEntries[side]=Safety.confirm(b.safetyEntries[side]?.state,b.settings.safety,{
      key:`${b.settings.mode}:${b.market?.ticker}:${side}`,now,
      rawPassed:rawBuySignal(b,m,side),filtersPassed:f.automaticAllowed,
      eligible:eligible&&(!validFeed.enabled||validFeed.passed),
      lastSellAt:rec.lastSellAt,running:b.running,
    });
  }
}
async function refreshBook(b,force=false){
  if(!b.settings.safety.depthEnabled||!b.market||b.open)return;
  const now=Date.now();
  if(now<b.bookRetryAt||(!force&&now-b.lastBookFetch<1500))return;
  b.lastBookFetch=now;
  const ticker=b.market.ticker;
  try{
    const r=await kalshi(envOf(b),'GET',`/markets/${encodeURIComponent(ticker)}/orderbook?depth=100`,{creds:readCreds(b)});
    if(b.market?.ticker!==ticker)return;
    b.book=Safety.parseBook(r,ticker,Date.now());b.bookRetryAt=0;
  }catch(e){
    b.book={ticker,ts:null,error:e.status===429?'Orderbook rate-limited; buys paused.':`Orderbook unavailable: ${e.message}`};
    b.bookRetryAt=Date.now()+(e.status===429?5000:3000);
  }
}
function assertSafeBuy(b,side,count,automatic){
  const r=updateRiskLimits(b,Date.now());
  if(!r.allowed)throw new Error(r.blockers.join(' '));
  const s=b.settings.safety;
  const signalRequired=automatic&&(s.confirmEnabled||s.freshReentryEnabled&&Entry.record(b).lastSellAt!=null);
  const cashout=Cashout.entryGuard(b.settings.rules,b.quote,b.market,side,Date.now());
  if(!cashout.allowed)throw new Error('Safety entry blocked: '+cashout.reason);
  if(s.blockNowOnlyEntry&&b.settings.rules[(side==='UP'?'up':'down')+'NowOnlyEnabled']){
    const nowOnly=Safety.nowOnlyEntry(s,b.settings.rules,
      marketFeed(b).snapshot(b.market?.strike,b.quote?.ts),side);
    if(!nowOnly.allowed)throw new Error('Safety entry blocked: '+nowOnly.reason);
  }
  if(automatic){
    if(s.requireEntryProtection){
      const protection=entryProtectionGate(b,marketFeed(b).snapshot(b.market?.strike,b.quote?.ts),side);
      if(!protection.allowed)throw new Error(protection.reason);
    }
    if(b.settings[(side==='UP'?'up':'down')+'RebuyEnabled']){
      const rebuy=Entry.rebuy(b,marketFeed(b).snapshot(b.market?.strike,b.quote?.ts),side);
      if(!rebuy.allowed)throw new Error(rebuy.reason);
    }
    const volume=Volume.evaluate(b.settings.rules,contractVolume.snapshot(envOf(b),b.market?.ticker),
      b.market,side,Date.now(),envOf(b));
    if(!volume.allowed)throw new Error(volume.reason);
  }
  if(!s.spreadEnabled&&!s.depthEnabled&&!s.feedEnabled&&!signalRequired)return;
  const m=marketFeed(b).snapshot(b.market?.strike,b.quote?.ts),f=buyFilters(b,m,side,count);
  if(!f.allowed)throw new Error('Safety entry blocked: '+f.blockers.join(' '));
  if(signalRequired){
    const proof=b.safetyEntries[side];
    if(!proof?.passed||!Number.isFinite(proof.state.last)||Date.now()<proof.state.last||
      Date.now()-proof.state.last>3500||!rawBuySignal(b,m,side))
      throw new Error('Fresh safety entry confirmation is required. No buy sent.');
  }
}

const WATCH_ENTRY = Symbol('watch-entry');
function observeBuyingEntry(b,side){
  if(!b.running||b.phase!=='BUYING'||!b.market||b.open||heldSide(b))return;
  const now=Date.now(),m=marketFeed(b).snapshot(b.market.strike,b.quote?.ts);
  refreshNowDirection(b,m,needsEntryIndex(b)?indexFeed.snapshot(b):null,now);
  if(chopBuyOptions(b)[side.toLowerCase()]===true)observeVolatility(b,now);
  updateRiskLimits(b,now);
  updateSafetyEntries(b,m,now);
}
async function buyWithRetry(b, side) {
  const s = b.settings;
  // Shared across all attempts. Even a zero-fill response means an order was
  // submitted; later signal changes must not re-arm an uncertain execution.
  const submission={attempted:false};
  const watchIfNeverSent=()=>!submission.attempted?WATCH_ENTRY:false;
  // The main loop awaits this function. Keep its read-only observations alive
  // during network waits, without new account/order requests or wider TTLs.
  // Index snapshots retain their existing shared refresh/reconnect throttles.
  let observationError=null;
  const observer=setInterval(()=>{
    try{observeBuyingEntry(b,side);observationError=null;}
    catch(e){b.safetyEntries={};b.nowDirection=null;observationError=e;}
  },750);
  observer.unref?.();
  try{
  for (let i = 1; i <= 4; i++) {
    if (!b.running && b.phase !== 'MANUAL') return false;
    try {
      await refreshQuote(b);
      await refreshPosition(b, true);
      if (!b.running && b.phase !== 'MANUAL') return false;
      // Never send a second buy when an earlier response/position is ambiguous.
      if (ownedSide(b)) return ownedSide(b)===side;
      if (heldSide(b)) return heldSide(b) === side;
      await refreshBook(b,true);
      const eligibility = Entry.status(b);
      if (!eligibility.allowed) { addLog(b, eligibility.reason, 'warn'); return false; }
      const fresh = marketFeed(b).snapshot(b.market?.strike, b.quote?.ts);
      if (!fresh.ready) { addLog(b, 'Entry paused: fresh market data is required.', 'warn'); return watchIfNeverSent(); }
      if (s.nowEntry?.enabled||b.phase !== 'MANUAL'&&s.entryMethod !== 'spread') {
        const signal = automaticBuySignal(b,fresh,side);
        if (!signal.passed) {
          addLog(b, `Automatic buy signal no longer agrees: ${signal.reason} No buy sent.`, 'warn');
          return watchIfNeverSent();
        }
      }
      if (b.phase !== 'MANUAL' && !s.nowEntry?.enabled && s.entryMethod === 'spread') {
        const m = marketFeed(b).snapshot(b.market?.strike, b.quote?.ts);
        const checks = Guard.entryChecks(s.rules,m,side).filter(c=>c.enabled);
        if (!m.ready || !checks.length || !checks.every(c => c.passed)) {
          addLog(b, 'Spread entry signal no longer agrees. No buy sent.', 'warn');
          b.entrySignals = {};
          return watchIfNeverSent();
        }
      }
      const px = side === 'UP' ? b.quote.upAsk : b.quote.downAsk;
      const count = Math.floor((Number(s.dollars) * 100) / Math.max(1, px + (s.mode === 'paper' ? 0 : Number(s.slippage) || 0)));
      if (count < 1) { addLog(b, `Dollar amount too small to buy 1 contract at ${px}¢`, 'bad'); return false; }
      if(observationError)throw entrySignalChanged('Entry observations unavailable. No retry buy sent.');
      if(b.phase!=='MANUAL'){
        const chop=chopBuyDecision(b,side,Date.now(),true);
        if(!chop.allowed)throw entrySignalChanged(chop.reason+' No buy sent.');
      }
      addLog(b, `Placing ${side} order: ${count} @ ≤${px}¢ (attempt ${i})`);
      const r = await placeOrder(b, side, 'buy', count, submission);
      ledgerBuy(b, r?._fill);
      if (r?._fill?.filled > 0) { b.enteredTicker = b.market.ticker; b.guard = Guard.blank(); persist(); }
      if (r && r.fill_count != null) addLog(b, `Filled ${parseFloat(r.fill_count)} contracts${r.average_fill_price ? ' @ ' + Math.round(parseFloat(r.average_fill_price) * 100) + '¢' : ''}`);
      if (ownedSide(b)===side) {
        addLog(b, `${side} fill recorded. Keeping exit monitoring active while exchange positions synchronize.`, 'good');
        return true;
      }
    } catch (e) {
      if(e.code==='ENTRY_SIGNAL_CHANGED'&&!submission.attempted){
        addLog(b, `Entry check changed before submission: ${e.message}`, 'warn');
        return WATCH_ENTRY;
      }
      if(e.code==='ENTRY_SIGNAL_CHANGED'){
        addLog(b, `Retry blocked: ${e.message} An earlier buy order was submitted; entry stays paused to avoid a duplicate. Check orders and positions before retrying.`, 'warn');
        return false;
      }
      addLog(b, `Order error: ${e.message}. Check account before retrying.`, 'bad'); return false;
    }
    await sleep(s.mode === 'paper' ? 300 : 1500);
    try { await refreshPosition(b, true); } catch (e) { addLog(b, `Position check failed: ${e.message}; no repeat buy sent.`, 'bad'); return false; }
    if (heldSide(b) === side) { addLog(b, `${side} position confirmed (${Math.abs(b.position)})`, 'good'); return true; }
    addLog(b, 'Position not confirmed. Retrying...', 'warn');
    await sleep(1000);
  }
  return false;
  }finally{clearInterval(observer);}
}

async function sellWithRetry(b, side) {
  const automated = b.phase === 'SELLING';
  for (let i = 1; i <= 4; i++) {
    if (automated && !b.running) return false;
    ExitAudit.event(b.open,Date.now(),b.settings.mode,{type:'exit-attempt',attempt:i});
    persist();
    try {
      await refreshQuote(b);
      try { await refreshPosition(b, true); }
      catch(e) {
        if(!ownedTrade(b)||b.settings.mode==='paper')throw e;
        b.position=null;
        addLog(b, `Position refresh unavailable; retaining recorded ownership for reduce-only exit: ${e.message}`, 'warn');
      }
      if (heldSide(b) && heldSide(b) !== side) throw new Error('Position side changed; close blocked.');
      // Manage only inventory opened and recorded by this independent strategy.
      const own = ownedSide(b)===side?ownedTrade(b).count:0;
      const qty = own>0&&(!Number.isFinite(b.position)||b.position===0)?own:
        Math.min(Math.abs(b.position), own);
      if (!own) {
        addLog(b, 'No strategy-owned position. External inventory is not managed.', 'warn');
        return false;
      }
      if (!(qty>0)) return false;
      if (automated) {
        const m = marketFeed(b).snapshot(b.market.strike, b.quote?.ts);
        const d = updateExitDecision(b,m,side,Date.now());
        if (d.action !== 'SELL' || !b.running) return false;
      }
      addLog(b, `Closing ${side}: ${qty} contracts (attempt ${i})`);
      const r = await placeOrder(b, side, 'sell', qty);
      ledgerSell(b, r?._fill, b.phase === 'SELLING' ?
        b.guardDecision?.exitKind === 'contract-loss' ? 'contract loss protection' :
        b.guardDecision?.exitKind === 'contract-profit' ?
          b.guardDecision.contractProfit?.kind==='staged'?'staged profit trailing exit':
          b.guardDecision.contractProfit?.kind==='volatility'?'volatility trailing exit':'contract profit trailing exit' :
        b.guardDecision?.exitKind === 'candle-reversal' ? 'candle reversal exit' :
        b.guardDecision?.exitKind === 'contract-volume' ? 'contract-volume exit' :
        b.guardDecision?.exitKind === 'trailing-line' ? 'trailing-line exit' :
        b.guardDecision?.exitKind === 'timed-cashout' ? 'timed percentage cash-out' :
        b.guardDecision?.exitKind === 'entry-protection' ? 'entry protection exit' :
        b.guardDecision?.exitKind === 'staircase' ? 'staircase exit' :
        b.guardDecision?.exitKind === 'trailing' ? 'trailing exit' :
        b.guardDecision?.exitKind === 'now-only' ? 'now-only exit' :
        b.guardDecision?.exitKind === 'low-high' ? 'LOW/HIGH sell exit' : 'spread exit' : 'sold');
    } catch (e) {
      ExitAudit.event(b.open,Date.now(),b.settings.mode,{type:'exit-attempt-error',
        attempt:i,error:String(e.message).slice(0,240)});
      persist();
      addLog(b, `Close error: ${e.message}`, 'bad');
    }
    await sleep(b.settings.mode === 'paper' ? 300 : 1500);
    try { await refreshPosition(b, true); } catch {}
    if (!ownedTrade(b)) { addLog(b, `${side} strategy position closed by confirmed fills`, 'good'); return true; }
    addLog(b, 'Close not confirmed. Retrying...', 'warn');
    await sleep(1000);
  }
  return false;
}

async function settlePaper(b) {
  const p = b.paper;
  if (!p.pending?.length) return;
  for (const item of [...p.pending]) {
    if (Date.now() - item.at < 20000) continue;
    if(b.root&&!matchesMarket(b.settings.asset,item.ticker))continue;
    try {
      const r = await kalshi(envOf(b), 'GET', `/markets/${item.ticker}`);
      if(b.root&&r.market?.ticker!==item.ticker)continue;
      const res = r.market?.result;
      if (res === 'yes' || res === 'no') {
        const won = res === item.side;
        const payout = won ? item.count : 0;
        const pnl = payout - (item.avg * item.count) / 100;
        p.cash += payout; p.pnl += pnl; p.trades += 1; if (pnl > 0) p.wins += 1;
        addLog(b, `Paper settlement ${item.ticker}: ${won ? 'WON' : 'LOST'} ${pnl >= 0 ? '+' : ''}$${pnl.toFixed(2)}`, won ? 'good' : 'bad');
        p.pending = p.pending.filter((x) => x !== item);
        persist();
      }
    } catch {}
  }
}

function candleMark(b,now){
  if(!b.quote)return null;
  const q={...b.quote},key=b.open?.side==='no'?'downBid':'upBid';
  const slip=b.settings.mode==='paper'?0:Number(b.settings.slippage)||0;
  if(Number.isFinite(q[key])&&b.settings.mode!=='paper'){
    const adjusted=Math.max(1,Math.min(99,q[key]-slip));
    // Match YES-price rounding for sell NO as well as sell YES. Never mark
    // above either the slippage-adjusted bid or the actual rounded limit.
    const limit=b.open.side==='no'?100-clampC(100-adjusted):clampC(adjusted);
    q[key]=Math.min(adjusted,limit);
  }
  // A missing/zero bid must never be turned into invented executable liquidity.
  if(!(b.quote[key]>0&&b.quote[key]<100))return null;
  return Safety.mark(b.open,q,b.market,b.settings.mode,now,feeFor);
}
function updateExitDecision(b,m,side,now){
  const oldProfitLatched=b.open.profitTrail?.latched===true;
  const oldLossLatched=b.open.safetyStop?.dollars===true||b.open.safetyStop?.percent===true;
  const key=`${b.market.ticker}:${side}:${b.open.startedAt||0}`;
  const protectionRules=NowEntry.exitRules(b.settings.rules,b.open.nowEntryConfig);
  const d=Guard.evaluate(b.guard,b.settings.rules,m,side,key,now);
  const lowHigh=NowExit.evaluate(b.lowHighExit,b.settings.nowExit,m,side,key,now,b.running,indexFeed.snapshot(b));
  b.lowHighExit=lowHigh.state;d.lowHigh=lowHigh;
  // Replace only the regular compound exit. Independent now-only and all
  // protective overrides below retain their original behavior and priority.
  if(lowHigh.enabled&&d.exitKind!=='now-only'){
    d.action=lowHigh.action;d.reason=lowHigh.reason;d.exitKind=lowHigh.exitKind;
  }
  const oldBest=b.open.trail?.best;
  const t=Trailing.evaluate(b.open.trail,protectionRules,m,side,key,now,b.running,b.market.openTime,b.open.entryNow);
  b.open.trail=t.state;
  if(oldBest!==t.best)persist();
  d.trailing=t;
  const oldStair=b.open.stair;
  const stair=Trailing.evaluateStair(b.open.stair,protectionRules,m,side,key,now,b.running,b.market.openTime,b.open.entryNow);
  b.open.stair=stair.state;d.staircase=stair;
  if(oldStair?.level!==stair.state.level||oldStair?.best!==stair.best)persist();
  const entry=Trailing.evaluateEntryProtection(b.settings.rules,m,side,b.open.entryNow,b.running);
  d.entryProtection=entry;
  const c=Cashout.evaluate(b.settings.rules,b.quote,m,side,
    b.market?(b.market.closeTime-now)/1000:null,now,b.running);
  d.cashout=c;
  const loss=Safety.lossExit(b.settings.safety,b.open,
    Safety.mark(b.open,b.quote,b.market,b.settings.mode,now,feeFor),b.running,now,b.lossCooldown);
  b.lossCooldown=loss.state;
  d.contractLoss=loss;
  const needsCandles=Following.needsCandles(b.settings.following,b.settings.safety);
  const profit=Following.evaluate(b.settings.following,b.settings.safety,b.open,
    Safety.mark(b.open,b.quote,b.market,b.settings.mode,now,feeFor),m,
    needsCandles?atrFeed(b).snapshot().candles:[],now,b.running);
  d.contractProfit=profit;
  if(JSON.stringify(b.open.profitTrail)!==JSON.stringify(profit.state)){
    b.open.profitTrail=profit.state;persist();
  }
  if(JSON.stringify(b.open.safetyStop||{})!==JSON.stringify(loss.latched)){
    b.open.safetyStop=loss.latched;persist();
  }
  if(loss.action==='SELL'){
    d.action='SELL';d.reason=loss.reason;d.exitKind='contract-loss';
  }else if(profit.action==='SELL'){
    d.action='SELL';d.reason=profit.reason;d.exitKind='contract-profit';
  }else if(c.action==='SELL'){
    d.action='SELL';d.reason=c.reason;d.exitKind='timed-cashout';
  }else if(entry.action==='SELL'&&d.action!=='SELL'){
    d.action='SELL';d.reason=entry.reason;d.exitKind='entry-protection';
  }else if(stair.action==='SELL'&&d.action!=='SELL'){
    d.action='SELL';d.reason=stair.reason;d.exitKind='staircase';
  }else if(t.action==='SELL'&&d.action!=='SELL'){
    d.action='SELL';d.reason=t.reason;d.exitKind='trailing';
  }else if(t.action==='EXIT_WAIT'&&d.action!=='SELL'){
    d.action='TRAIL_WAIT';d.reason=t.reason;d.exitKind='trailing';
  }else if(t.action==='WARMUP'&&d.action!=='SELL'){
    d.action='TRAIL_WARMUP';d.reason=t.reason;d.exitKind='trailing';
  }else if(['EXIT_WAIT','WARMUP'].includes(stair.action)&&d.action!=='SELL'){
    d.action=stair.action==='EXIT_WAIT'?'STAIR_WAIT':'STAIR_WARMUP';d.reason=stair.reason;d.exitKind='staircase';
  }
  if(loss.breached&&['NO_BID','PAUSED'].includes(loss.action)&&d.action!=='SELL'){
    d.action=loss.action==='NO_BID'?'LOSS_NO_BID':'LOSS_PAUSED';d.reason=loss.reason;d.exitKind='contract-loss';
  }
  if(loss.action==='EXIT_WAIT'&&d.action!=='SELL'){
    d.action='LOSS_WAIT';d.reason=loss.reason;d.exitKind='contract-loss';
  }
  if(profit.latched&&['NO_BID','PAUSED'].includes(profit.action)&&d.action!=='SELL'){
    d.action=profit.action==='NO_BID'?'PROFIT_NO_BID':'PROFIT_PAUSED';d.reason=profit.reason;d.exitKind='contract-profit';
  }
  const candle=Candle.evaluate(b.settings.candleReversal,b.open,candleMark(b,now),
    marketFeed(b).candleFeed.snapshot(now),now,b.running,b.candleReversalState);
  b.candleReversalState=candle.state;d.candleReversal=candle;
  // Additive independent exit: no change to any existing exit's precedence.
  if(candle.action==='SELL'&&d.action!=='SELL'){
    d.action='SELL';d.reason=candle.reason;d.exitKind='candle-reversal';
  }
  const previousLine=b.open.lineTrail;
  const lineEnabled=Line.validate(b.settings.lineTrail)[(side==='UP'?'up':'down')+'Enabled'];
  const line=Line.evaluate(b.settings.lineTrail,b.open,candleMark(b,now),
    lineEnabled&&b.running?marketFeed(b).candleFeed.trailingFrame(b.market.ticker,b.market.strike,previousLine?.sequence,now):null,
    now,b.running,previousLine);
  d.lineTrail=line;
  if(line.enabled||previousLine){
    b.open.lineTrail=line.state;
    if(previousLine?.best!==line.best||previousLine?.level!==line.level)persist();
  }
  if(line.action==='SELL'&&d.action!=='SELL'){
    d.action='SELL';d.reason=line.reason;d.exitKind='trailing-line';
  }
  const volume=volumeExitDecision(b,side,now);
  d.contractVolumeExit=volume;
  if(volume.action==='SELL'&&d.action!=='SELL'){
    d.action='SELL';d.reason=volume.reason;d.exitKind='contract-volume';
  }
  if(ExitAudit.observe(b.open,{now,quote:b.quote,decision:d,running:b.running,
    oldProfitLatched,oldLossLatched,safety:b.settings.safety,mode:b.settings.mode}))persist();
  b.guard=d.state;b.guardDecision=d;return d;
}
function volumeExitDecision(b,side,now=Date.now()){
  const env=envOf(b),market=b.market;
  return Volume.evaluateExit(b.settings.rules,sellContractVolume.snapshot(env,market?.ticker),
    market,b.quote,side,now,env,b.running,ownedSide(b)===side);
}
function sampleNow(b,m,now){
  if(b.chartTicker!==b.market?.ticker){b.chartTicker=b.market?.ticker;b.nowHistory=[];}
  const last=b.nowHistory.at(-1);
  if(last&&now-last.t<1000)return;
  const t=b.guardDecision?.trailing,ready=m?.ready&&Number.isFinite(m.nowDiff);
  b.nowHistory.push({t:now,now:ready?m.nowDiff:null,best:ready&&b.open?t?.best??null:null,
    exit:ready&&b.open&&t?.active?t.level:null,
    stair:ready&&b.open&&b.guardDecision?.staircase?.active?b.guardDecision.staircase.level:null,
    entryStop:ready&&b.open&&b.guardDecision?.entryProtection?.active?b.guardDecision.entryProtection.level:null,
    line:ready&&b.open&&b.guardDecision?.lineTrail?.active?b.guardDecision.lineTrail.level:null,
    position:b.open?.startedAt??null});
  b.nowHistory=b.nowHistory.filter(x=>now-x.t<=900000).slice(-901);
}
// One iteration of the strategy state machine (mirrors the Nightshark v2 script)
async function step(b) {
  const s = b.settings;
  const now = Date.now();
  if(Following.needsCandles(s.following,s.safety))atrFeed(b).snapshot();

  // Session discovery / rollover
  const needMarket = !b.market || now >= b.market.closeTime || now - b.lastMarketFetch > 60000;
  if (needMarket && now - b.lastMarketFetch < 3000) return; // throttle lookups during rollover
  if (needMarket) {
    b.lastMarketFetch = now;
    const m = await findMarket(b);
    if (m && (!b.market || m.ticker !== b.market.ticker)) {
      // Paper: carry an open position into settlement
      if (s.mode === 'paper' && b.paper.pos > 0 && b.paper.ticker && b.paper.ticker !== m.ticker) {
        b.paper.pending.push({ ticker: b.paper.ticker, side: b.paper.side, count: b.paper.pos, avg: b.paper.avg, at: Date.now() });
        addLog(b, `Paper position held to resolution on ${b.paper.ticker}`);
        b.paper.pos = 0; b.paper.side = null; persist();
      }
      if (b.open && b.open.ticker !== m.ticker) {
        b.pendingSettle.push({ ...b.open, at: Date.now() });
        addLog(b, `Holding ${b.open.side === 'yes' ? 'UP' : 'DOWN'} ${b.open.count} to resolution on ${b.open.ticker}`);
        b.open = null; persist();
      }
      b.market = m;
      b.book=null;b.lastBookFetch=0;b.bookRetryAt=0;b.safetyEntries={};
      b.entrySignals = {};
      b.guard = Guard.blank();
      if (b.running) addLog(b, `Loaded session ${m.ticker}`);
      if (b.running) {
        b.phase = b.open?.ticker === m.ticker ? 'MONITOR_EXIT' : 'MONITOR_ENTRY';
        addLog(b, b.phase === 'MONITOR_EXIT' ? 'Resuming this copy’s position monitor' : 'Monitoring entry price in the new session');
      }
    } else if (!m) { b.market = null; b.quote = null; }
  }
  if (!b.market) {
    volatilityScratch.delete(b);b.nowDirection=null;b.entrySignals = {}; b.guard = Guard.blank(); b.guardDecision = null;
    if (b.running) b.phase = 'NO_MARKET';
    if(b.root){
      if(s.mode==='paper')await settlePaper(b);
      await settleLedger(b);
    }
    return;
  }
  await refreshQuote(b);
  if(s.rules.upVolumeEnabled||s.rules.downVolumeEnabled)
    void contractVolume.kick(envOf(b),b.market.ticker,
      Math.max(s.rules.upVolumeEnabled?s.rules.upVolumeLookback:0,
        s.rules.downVolumeEnabled?s.rules.downVolumeLookback:0));
  const volumeExitSide=b.running&&ownedSide(b);
  if(volumeExitSide){
    const key=Volume.exitKey(volumeExitSide);
    if(s.rules[key+'Enabled'])void sellContractVolume.kick(envOf(b),b.market.ticker,s.rules[key+'Lookback']);
  }
  try { await refreshPosition(b); }
  catch(e) {
    if(!ownedTrade(b))throw e;
    b.position=null;
    if(now-(b.lastPositionWarning||0)>15000) {
      addLog(b, `Position snapshot unavailable. Recorded trade remains monitored: ${e.message}`, 'warn');
      b.lastPositionWarning=now;
    }
  }
  await refreshBook(b);
  // Settlement queries are bookkeeping, never a dependency of an owned
  // position's exit loop. Defer them until flat/rollover; process them before
  // any subsequent entry so retained risk accounting is not bypassed.
  if(!ownedTrade(b)){
    if (s.mode === 'paper') await settlePaper(b);
    await settleLedger(b);
  }
  const metrics = marketFeed(b).snapshot(b.market.strike, b.quote?.ts);
  refreshNowDirection(b,metrics,needsEntryIndex(b)?indexFeed.snapshot(b):null,Date.now());
  updateRiskLimits(b,Date.now());
  updateSafetyEntries(b,metrics,Date.now());
  if (ownedTrade(b)) {
    const side = b.open.side === 'yes' ? 'UP' : 'DOWN';
    updateExitDecision(b,metrics,side,Date.now());
  } else {
    b.guard = Guard.blank();
    b.guardDecision = null;
    b.lowHighExit=null;
  }
  sampleNow(b,metrics,Date.now());
  observeVolatility(b,Date.now());
  if (!b.running) return;
  if(ownedTrade(b)&&!['MONITOR_EXIT','SELLING'].includes(b.phase)) {
    b.phase='MONITOR_EXIT';
    addLog(b,'Recorded open trade found. Restoring exit monitoring; no new buy sent.','warn');
  }

  const rem = remainingSec(b);
  const last5 = rem != null && rem <= 5;
  const q = b.quote;

  switch (b.phase) {
    case 'NO_MARKET':
    case 'STARTING':
      b.phase = b.open && b.open.ticker === b.market.ticker ? 'MONITOR_EXIT' : 'MONITOR_ENTRY';
      b.entrySignals = {};
      addLog(b, b.phase === 'MONITOR_EXIT' ? 'Monitoring this copy’s position with spread rules' :
        s.nowEntry?.enabled ? 'Monitoring ONLY checked low/high entry conditions; no contract-price trigger' :
        s.entryMethod === 'spread' ? 'Monitoring spread + target + now for confirmed entry' :
          `Monitoring UP ask > ${Buy.priceThreshold(s,'UP')}¢ / DOWN ask > ${Buy.priceThreshold(s,'DOWN')}¢ AND Now (UP ≥ ${s.upBuyNow}, DOWN ≤ ${s.downBuyNow} USD)`);
      break;

    case 'MONITOR_ENTRY': {
      if (last5) { b.entrySignals = {}; addLog(b, 'Last 5 seconds of session'); b.phase = 'WAIT_NEXT'; addLog(b, 'Waiting for next session'); break; }
      const eligibility=Entry.status(b,Date.now());
      if (!eligibility.allowed) {
        b.entrySignals = {};
        // A waiting first-entry clock must keep observing this market, not
        // become stranded in WAIT_NEXT (which only unlocks completed re-entries).
        if(eligibility.window.allowed)b.phase='WAIT_NEXT';
        break;
      }
      if(!b.safetyStatus.allowed){b.entrySignals={};break;}
      const up = q?.upAsk, down = q?.downAsk;
      let side;
      if (s.nowEntry?.enabled) {
        const hits=['UP','DOWN'].filter(dir=>nowEntrySignal(b,metrics,dir).passed&&b.safetyEntries[dir]?.passed);
        if(hits.length!==1)break;
        side=hits[0];
      } else if (s.entryMethod === 'spread') {
        for (const dir of ['UP','DOWN']) {
          b.entrySignals[dir] = Guard.evaluateEntry(b.entrySignals[dir]?.state,s.rules,metrics,dir,b.market.ticker,Date.now());
        }
        const hits = ['UP','DOWN'].filter(dir=>b.entrySignals[dir].action === 'READY'&&b.safetyEntries[dir]?.passed);
        if (hits.length !== 1) break; // Ambiguous overlapping custom rules must not choose a side.
        side = hits[0];
      } else {
        if (!metrics.ready) break;
        const hits = ['UP','DOWN'].filter(dir => Buy.evaluate(s, q, metrics, dir).passed&&b.safetyEntries[dir]?.passed);
        if (!hits.length) break;
        side = hits[0];
      }
      if (b.position !== 0) {
        addLog(b, 'Position already exists, skipping this session', 'warn');
        b.phase = 'WAIT_NEXT'; addLog(b, 'Waiting for next session'); break;
      }
      // Apply after the pre-existing side selection. Chop never resolves a
      // two-side ambiguity or switches the bot to the other side.
      if(!chopBuyDecision(b,side,Date.now(),true).allowed)break;
      addLog(b, `${side} ${s.nowEntry?.enabled?'checked low/high entry conditions met':s.entryMethod === 'spread' ? 'spread signal confirmed' : 'contract price + signed Now triggered'} at ${side === 'UP' ? up : down}¢. Placing ${side} order`, 'accent');
      b.phase = 'BUYING';
      const ok = await buyWithRetry(b, side);
      if (!b.running) { b.phase = 'IDLE'; break; }
      if (ok===true) { b.phase = 'MONITOR_EXIT'; addLog(b, 'Monitoring selected sell rules and enabled independent safety exits'); }
      else if(ok===WATCH_ENTRY&&!b.open&&!heldSide(b)&&Entry.status(b).allowed){
        b.entrySignals={};b.safetyEntries={};
        b.phase='MONITOR_ENTRY';
        addLog(b, 'No buy order sent. Continuing to watch this market for a fresh valid entry.', 'warn');
      }
      else { b.phase = 'WAIT_NEXT'; addLog(b, 'Entry paused. Waiting for next market; review Activity for the reason.', 'warn'); }
      break;
    }

    case 'MONITOR_EXIT': {
      const side = ownedSide(b)||heldSide(b);
      if (!side) { addLog(b, 'Position no longer open'); b.phase = 'WAIT_NEXT'; addLog(b, 'Waiting for next session'); break; }
      if (!ownedTrade(b)) {
        addLog(b, 'External position detected; this copy will not manage it.', 'warn');
        b.phase = 'WAIT_NEXT'; break;
      }
      if (rem <= 0) break;
      if (b.guardDecision?.action === 'SELL') {
        addLog(b, b.guardDecision.exitKind === 'timed-cashout' ? b.guardDecision.reason :
          ['contract-loss','contract-profit','low-high','candle-reversal','trailing-line','contract-volume'].includes(b.guardDecision.exitKind)?b.guardDecision.reason:
          `${b.guardDecision.exitKind === 'entry-protection' ? 'Entry protection' : b.guardDecision.exitKind === 'staircase' ? 'Staircase' : b.guardDecision.exitKind === 'trailing' ? 'Trailing' : b.guardDecision.exitKind === 'now-only' ? 'Now-only' : 'Selected-rule'} exit ${side}: spread ${metrics.spread.toFixed(2)}, all-target ${metrics.targetDiff.toFixed(2)}, now ${metrics.nowDiff.toFixed(2)}`, 'warn');
        b.phase = 'SELLING';
        const closed = await sellWithRetry(b, side);
        // A failed/partial close must remain monitored rather than being abandoned.
        b.phase = closed ? 'WAIT_NEXT' : 'MONITOR_EXIT';
        addLog(b, closed ? `Exit confirmed. ${Entry.status(b).reason}` : 'Close incomplete; still monitoring.', closed ? 'good' : 'bad');
      }
      break;
    }

    case 'WAIT_NEXT':
      // Only a recorded, completed sell may unlock same-market re-entry.
      if (Entry.record(b).entries > 0 && Entry.status(b, now).allowed) {
        b.phase = 'MONITOR_ENTRY'; b.entrySignals = {};
        addLog(b, 'Re-entry eligible. Monitoring a fresh entry signal.');
      }
      break;
  }
}

function ensureLoop(b) {
  if (process.env.NODE_ENV === 'test') return;
  if (b.loopActive) return;
  b.loopActive = true;
  (async () => {
    while (b.running || Date.now() - b.lastPoll < 20000 ||
      (b.root&&(b.open||b.pendingSettle.length||b.paper.pos||b.paper.pending.length))) {
      const t0 = Date.now();
      if (!b.busy) {
        b.busy = true;
        try { await step(b); b.error = null; }
        catch (e) {
          b.error = e.message;
          b.entrySignals = {};
          b.guard = Guard.blank();
          b.guardDecision = b.open ? Guard.evaluate(null, b.settings.rules,
            { ready: false, reason: 'Market refresh failed. Qualification resets.' },
            b.open.side === 'yes' ? 'UP' : 'DOWN', '', Date.now()) : null;
          if (e.status === 429) { b.backoffUntil = Date.now() + 3000; if (b.running) addLog(b, 'Kalshi rate limit hit. Slowing down for 3s', 'warn'); }
          else if (b.running) addLog(b, `Error: ${e.message}`, 'bad');
        }
        finally { b.busy = false; }
      }
      const fast = b.running && (b.phase === 'MONITOR_ENTRY' || b.phase === 'MONITOR_EXIT');
      const wait = b.backoffUntil && b.backoffUntil > Date.now() ? b.backoffUntil - Date.now() : 0;
      await sleep(Math.max(150, wait, (fast ? 750 : 1500) - (Date.now() - t0)));
    }
    b.loopActive = false;
  })();
}

function publicState(b) {
  const p = b.paper;
  return {
    settings: b.settings,
    hasKey: !!b.creds,
    keyEnv: b.creds?.env || null,
    keyIdHint: b.creds ? b.creds.keyId.slice(0, 8) + '…' : null,
    running: b.running,
    phase: b.phase,
    market: b.market,
    quote: b.quote,
    remaining: remainingSec(b),
    position: b.position,
    positionStatus: positionStatus(b),
    balance: b.balance,
    paper: b.settings.mode === 'paper' ? { cash: p.cash, pnl: p.pnl, trades: p.trades, wins: p.wins, pending: p.pending.length } : null,
    results: resultsSummary(b),
    openTrade: b.open,
    awaitingSettle: b.pendingSettle.length,
    error: b.error,
    log: b.log.slice(-80),
    serverTime: Date.now(),
    feeds: marketFeed(b).snapshot(b.market?.strike, b.quote?.ts),
    candleChart:marketFeed(b).candleFeed.snapshot(),
    kalshiIndex: indexFeed.snapshot(b),
    guard: b.guardDecision,
    armedLive: b.armedLive,
    enteredTicker: b.enteredTicker,
    entryEligibility: Entry.status(b),
    entryWindow: EntryWindow.evaluate(b.settings,b.market,Date.now()),
    entrySignals: b.entrySignals,
    nowChart: {ticker:b.chartTicker,points:b.nowHistory,sales:Entry.sales(b),
      rebuy:Object.fromEntries(['UP','DOWN'].map(side=>[side,Entry.rebuy(b,marketFeed(b).snapshot(b.market?.strike,b.quote?.ts),side)]))},
    priceBuySignals: Object.fromEntries(['UP','DOWN'].map(side => [side,
      Buy.evaluate(b.settings, b.quote, marketFeed(b).snapshot(b.market?.strike, b.quote?.ts), side)])),
    safety: {...riskSnapshot(b),entries:b.safetyEntries,
      filters:Object.fromEntries(['UP','DOWN'].map(side=>[side,buyFilters(b,
        marketFeed(b).snapshot(b.market?.strike,b.quote?.ts),side)])),
      contractLoss:b.guardDecision?.contractLoss||null,
      contractProfit:b.guardDecision?.contractProfit||null,
      followingCandles:Following.needsCandles(b.settings.following,b.settings.safety)?
        (({ready,atr,reason,observedAt})=>({ready,atr,reason,observedAt}))(atrFeed(b).snapshot()):null,
      bookAgeMs:Number.isFinite(b.book?.ts)?Math.max(0,Date.now()-b.book.ts):null},
    profiles: Profiles.list(b, defaultsFor(b)),
    profilesShared:!!b.profilesShared,
    activeProfile: Profiles.active(b, defaultsFor(b)),
    profilePaperOnly: Profiles.paperOnly(b, defaultsFor(b)),
    profileUndoAvailable: !!b.profileUndo,
    session:{label:sessionLabel(b.id),known:connections.known(b.id)||!!b.creds||
      !!b.activeProfileId||!!b.history.length,running:b.running,armed:b.armedLive},
    volatilityObservations:volatilitySnapshot(b,Date.now()),
    chopBuyFilter:{switches:chopBuyOptions(b),
      sides:Object.fromEntries(['UP','DOWN'].map(side=>[side,chopBuyDecision(b,side)]))},
    coinWorkspaces:workspaceStatus(b),coinReviewed:!b.root||b.coinReviewed,
    contractCounter:{enabled:b.showContractCounter,
      ...(b.showContractCounter?contractCounter.snapshot(envOf(b),b.market):{status:'off'})},
    sellContractVolume:Object.fromEntries(['UP','DOWN'].map(side=>[side,volumeExitDecision(b,side)])),
    features: {coinWorkspaces:true,chopBuyFilter:true,chopBuyCrossings:true,volatilityObservations:true,paperNowChop:true,lineTrail:true,candleReversal:true,followingTrails:true,ownedPositionGuard:true,entryRelativeTrailing:true,requireEntryProtection:true,sessionReconnect:true,
      sessionIdentityGate:STRICT_SESSION_IDENTITY,singleAutomationLock:SINGLE_AUTOMATION_LOCK,nowEntryMonitor:true,nowEntryConditions:true,nowEntrySignedKalshi:true,nowEntryDirection:true,lowHighSell:true,percentageExitDistance:true,entryTimeWindow:true,lowHighExchangeSpread:true,profitProtection:true,exitAudit:true,settlementIndependentExits:true,conditionalSpreadBuys:true,marketTimeBuyConditions:true,sellCooldowns:true,stopLossCooldown:true,buyChartHistory:true},
    nowEntrySignals:Object.fromEntries(['UP','DOWN'].map(side=>[side,nowEntrySignal(b,marketFeed(b).snapshot(b.market?.strike,b.quote?.ts),side)])),
    appVersion: 'spread-guard-61-contract-volume-exits',
  };
}

// ---------- HTTP ----------
function send(res, code, obj) {
  res.writeHead(code, { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*', 'Cache-Control': 'no-store' });
  res.end(JSON.stringify(obj));
}
function readBody(req) {
  return new Promise((resolve) => {
    let d = ''; req.on('data', (c) => { d += c; if (d.length > 1e5) req.destroy(); });
    req.on('end', () => { try { resolve(JSON.parse(d || '{}')); } catch { resolve({}); } });
  });
}
const MIME = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.json': 'application/json', '.svg': 'image/svg+xml', '.png': 'image/png', '.webmanifest': 'application/manifest+json' };

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://x');
  if (req.method === 'OPTIONS') {
    res.writeHead(204, { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': '*', 'Access-Control-Allow-Methods': 'GET,POST,OPTIONS' });
    return res.end();
  }
  if (!url.pathname.startsWith('/api/')) {
    // local static serving (deployed static files are served separately)
    let f = path.join(PUBLIC_DIR, url.pathname === '/' ? 'index.html' : path.normalize(url.pathname));
    if (!f.startsWith(PUBLIC_DIR)) { res.writeHead(403); return res.end(); }
    fs.readFile(f, (err, data) => {
      if (err) { res.writeHead(404); return res.end('Not found'); }
      res.writeHead(200, { 'Content-Type': MIME[path.extname(f)] || 'application/octet-stream' });
      res.end(data);
    });
    return;
  }

  let asset='BTC';
  if(url.pathname.startsWith('/api/coins/')){
    const scoped=/^\/api\/coins\/([A-Z]+)\/([a-z][a-z/-]*)$/.exec(url.pathname);
    if(!scoped||!Object.hasOwn(assets,scoped[1])||scoped[2].startsWith('session/'))
      return send(res,404,{error:'Unsupported coin or action. No settings or orders changed.'});
    asset=scoped[1];
    url.pathname='/api/'+scoped[2];
  }
  const vid = String(req.headers['x-visitor-id'] || url.searchParams.get('vid') || 'local').slice(0, 128);
  const resolved=connections.resolve(vid);
  // Unknown browser identities must not create a new bot, inherit account
  // permissions, or receive factory settings. Recovery endpoints remain usable.
  const root=hasSession(resolved)?getBot(resolved):
    STRICT_SESSION_IDENTITY?null:getBot(resolved);
  const b=root?getCoinBot(root,asset):null;
  if(b){b.lastPoll = Date.now();ensureLoop(b);}

  try {
    if(url.pathname==='/api/session/code'&&req.method==='POST'){
      if(!b)return send(res,409,{code:'SESSION_RECONNECT_REQUIRED',
        error:'Reconnect to your saved bot first. No new bot was created.'});
      persist();
      return send(res,200,{code:connections.issue(b.id),label:sessionLabel(b.id)});
    }
    if(url.pathname==='/api/session/find'&&req.method==='POST'){
      connections.limit(req.socket.remoteAddress||'proxy');
      const body=await readBody(req);
      if(typeof body.privateKey!=='string'||body.privateKey.length>16000||
        typeof body.keyId!=='string'||body.keyId.length>128)
        return send(res,400,{error:'Enter the original Kalshi key ID and full private key.'});
      const fp=connectionFingerprint({keyId:body.keyId,privateKey:body.privateKey,env:body.env});
      if(!fp)return send(res,400,{error:'Enter the original Kalshi key ID, environment and readable private key.'});
      // Proof of the exact saved private-key connection is required before any
      // other session labels or state are disclosed. Never save submitted keys.
      const matches=Object.entries({...store,...bots}).filter(([id,v])=>
        [v,...Object.values(store[id]?.coinWorkspaces||{}),...(coinBots.get(bots[id])?.values()||[])]
          .some(workspace=>connectionFingerprint(workspace.creds)===fp));
      if(!matches.length)return send(res,403,{error:'No saved session matches this key connection.'});
      return send(res,200,{sessions:matches.map(([id,v])=>({
        code:connections.issue(id),label:sessionLabel(id),mode:v.settings?.mode,
        running:workspaceStatus(getBot(id)).some(coin=>coin.running),profile:Profiles.active(getBot(id),DEFAULT_SETTINGS)?.name||'Custom settings',
      }))});
    }
    if(url.pathname==='/api/session/connect'&&req.method==='POST'){
      connections.limit(req.socket.remoteAddress||'proxy');
      const body=await readBody(req),target=connections.target(body.code);
      if(!target||!hasSession(target))return send(res,403,{error:'Invalid recovery code. No session changed.'});
      const next=getBot(target);
      if(b&&b!==next&&[b,...coinBots.get(b).values()].some(bot=>sessionOccupied(bot)||bot.armedLive))
        return send(res,409,{error:'This session has running or armed automation, an order, a position or settlement. It cannot switch sessions. No bot was stopped.'});
      connections.connect(vid,b||{id:resolved},next);
      // A view reconnect only. Do not start, stop, disarm, reset timers, load a
      // profile, copy credentials or replace any strategy/position ownership.
      return send(res,200,publicState(next));
    }
    if(!b)return send(res,409,{code:'SESSION_RECONNECT_REQUIRED',
      error:'This view is not connected to a saved bot. Reconnect using your private recovery code or original Kalshi key. No new bot was created.'});
    // Display-only snapshot. The index client may refresh its shared public cache;
    // this endpoint never evaluates rules or places orders.
    if (url.pathname === '/api/prices' && req.method === 'GET') return send(res, 200, {
      ...(b.root?{asset:b.settings.asset}:{}),
      marketTicker: b.market?.ticker ?? null, strike: b.market?.strike ?? null,
      feeds: marketFeed(b).snapshot(b.market?.strike, b.quote?.ts),
      kalshiIndex: indexFeed.snapshot(b), serverTime: Date.now(),
    });
    if (url.pathname === '/api/state' && req.method === 'GET') {
      if(b.showContractCounter&&process.env.NODE_ENV!=='test')
        void contractCounter.kick(envOf(b),b.market);
      return send(res, 200, publicState(b));
    }
    if(url.pathname==='/api/contract-counter'&&req.method==='POST'){
      const body=await readBody(req);
      if(typeof body?.enabled!=='boolean'||typeof body?.expected!=='boolean')
        return send(res,400,{error:'Choose whether to show the contract counter.'});
      if(body.expected!==b.showContractCounter)
        return send(res,409,{error:'The counter setting changed in another view. Refresh and try again.'});
      if(b.showContractCounter!==body.enabled){b.showContractCounter=body.enabled;persist();}
      if(b.showContractCounter&&process.env.NODE_ENV!=='test')
        void contractCounter.kick(envOf(b),b.market);
      return send(res,200,publicState(b));
    }
    if(url.pathname==='/api/coin-review'&&req.method==='POST'){
      if(!b.root)return send(res,400,{error:'Your existing BTC setup does not require coin review.'});
      const body=await readBody(req);
      if(body.confirm!==`REVIEW ${asset}`||b.running||b.armedLive)
        return send(res,400,{error:'Review the selected coin’s entry, exit and risk settings while stopped and disarmed.'});
      b.coinReviewed=true;
      addLog(b,`${asset} settings review confirmed. Nothing started or armed.`);
      persist();
      return send(res,200,publicState(b));
    }

    if(url.pathname==='/api/chop-buy-filter'&&req.method==='POST'){
      const body=await readBody(req),mode=b.settings.mode;
      if(!ChopBuy.available(mode))return send(res,400,{error:'Skip choppy buys is available in Live and Paper only.'});
      if(body.mode!==mode)return send(res,409,{error:'Mode changed. Reload the applied filter.'});
      if(b.running||b.armedLive||['BUYING','SELLING','MANUAL'].includes(b.phase))
        return send(res,409,{error:'Stop and disarm before changing the buy filter.'});
      let next,expected;
      try{next=ChopBuy.writeOptions(body.options);expected=ChopBuy.writeOptions(body.expected);}
      catch(e){return send(res,400,{error:e.message});}
      const current=chopBuyOptions(b);
      if(Object.hasOwn(next,ChopBuy.STRICT)&&!Object.hasOwn(expected,ChopBuy.STRICT))
        return send(res,400,{error:'Include the expected crossing setting when changing the crossing requirement.'});
      if(Object.keys(next).some(k=>current[k]!==expected[k]))
        return send(res,409,{error:'Filter changed in another view. Reload the applied filter.'});
      next={...current,...next};
      if(ChopBuy.KEYS.some(k=>current[k]!==next[k])){
        b.chopBuyOptions[mode]=next;chopBuyLogs.delete(b);persist();
      }
      return send(res,200,publicState(b));
    }

    if (url.pathname === '/api/volatility-observations' && req.method === 'POST') {
      const body=await readBody(req),mode=b.settings.mode;
      if(!Observations.available(mode))return send(res,400,{error:'Volatility observations are available in Paper and Live only.'});
      if(body.mode!==mode)return send(res,409,{error:'Mode changed. Reload the applied observation options.'});
      let next,expected;
      try{next=Observations.writeOptions(body.options);expected=Observations.writeOptions(body.expected);}
      catch(e){return send(res,400,{error:e.message});}
      const current=observationOptions(b);
      if(Observations.KEYS.some(k=>current[k]!==expected[k]))
        return send(res,409,{error:'Observation options changed in another view. Reload before applying.'});
      if(Observations.KEYS.some(k=>current[k]!==next[k])){
        const scratch=volatilityScratch.get(b);
        const filter=chopBuyOptions(b);
        if(scratch&&current.chop!==next.chop&&!filter.up&&!filter.down)scratch.chop.reset();
        if(scratch&&current.atr!==next.atr)scratch.atr=null;
        b.observationOptions[mode]=next;persist();
      }
      return send(res,200,publicState(b));
    }

    if (url.pathname === '/api/exit-audit' && req.method === 'GET') {
      const tradeId=url.searchParams.get('tradeId');
      if(!tradeId||tradeId.length>200)return send(res,400,{error:'A valid tradeId is required.'});
      // Existing session resolution above is the boundary: never search other
      // visitors, and never disclose credentials/settings with the audit.
      const record=[b.open,...b.pendingSettle,...b.history.slice().reverse()].find(r=>
        r&&r.tradeId===tradeId&&(!r.mode||r.mode===b.settings.mode));
      if(!record)return send(res,404,{tradeId,audit:null,status:'not-found'});
      return send(res,200,{tradeId,audit:record.exitAudit||null,
        status:record.exitAudit?'recorded':'not-recorded'});
    }

    if (url.pathname === '/api/profiles' && req.method === 'POST') {
      let rollback=null;
      try {
      const body = await readBody(req);
      if(b.profilesShared&&['save','update','trial','delete'].includes(body.action))rollback={
        profiles:structuredClone(sharedProfiles.profiles),
        settings:structuredClone(b.settings),activeProfileId:b.activeProfileId,
        profilePaperOnly:b.profilePaperOnly,profileUndo:structuredClone(b.profileUndo),
        guard:structuredClone(b.guard),guardDecision:structuredClone(b.guardDecision),
        entrySignals:structuredClone(b.entrySignals),safetyEntries:structuredClone(b.safetyEntries),
        log:structuredClone(b.log),
      };
      if(['update','delete'].includes(body.action)&&Object.hasOwn(body,'expectedUpdatedAt')){
        const current=Profiles.find(b,defaultsFor(b),String(body.id||''));
        if(!current||current.updatedAt!==body.expectedUpdatedAt)
          throw Error('This saved profile changed in another session. Review the latest version before replacing or deleting it.');
      }
      if (body.action === 'save' || body.action === 'update') {
        if (body.action === 'update' && !body.id) throw new Error('Choose a saved profile to replace.');
        const p = Profiles.save(b, defaultsFor(b), body.name, body.action === 'update' ? String(body.id || '') : null);
        persist(); addLog(b, `Settings profile saved: ${p.name}. No trading started.`, 'info');
      } else if (body.action === 'trial') {
        const p=Profiles.applyTrial(b,defaultsFor(b));
        persist();addLog(b,`Applied ${p.name}. Buy settings retained; bot stays stopped.`,'info');
      } else if (body.action === 'load' || body.action === 'restore') {
        const restoring = body.action === 'restore';
        const p = restoring ? b.profileUndo : Profiles.find(b, defaultsFor(b), String(body.id || ''));
        if (!p) throw new Error(restoring ? 'No previous settings to restore.' : 'Profile not found.');
        Profiles.assertLoadable(b, p);
        // Confirm account inventory before changing a stopped exchange strategy.
        if (b.settings.mode !== 'paper') await refreshPosition(b, true);
        Profiles.apply(b, defaultsFor(b), p, restoring);
        persist(); addLog(b, restoring ? 'Previous settings restored. Bot remains stopped.' : `Profile loaded: ${p.name}. Bot remains stopped.`, 'info');
      } else if (body.action === 'delete') {
        if(b.profilesShared&&Object.values(bots).some(other=>other!==b&&
          other.activeProfileId===body.id&&(other.running||other.open||other.position)))
          throw Error('Another session is using this profile for trading or an open position. Stop that session before deleting it.');
        Profiles.remove(b, defaultsFor(b), String(body.id || '')); persist();
      } else throw new Error('Choose save, update, load, restore or delete.');
      if(b.profilesShared&&['save','update','trial','delete'].includes(body.action))sharedProfiles.flush();
      rollback=null;
      return send(res, 200, publicState(b));
      } catch (e) {
        if(rollback){
          sharedProfiles.profiles=rollback.profiles;
          for(const key of ['settings','activeProfileId','profilePaperOnly','profileUndo',
            'guard','guardDecision','entrySignals','safetyEntries','log'])b[key]=rollback[key];
        }
        return send(res, 400, { error: e.message });
      }
    }

    if (url.pathname === '/api/settings' && req.method === 'POST') {
      const body = await readBody(req);
      if (b.phase === 'BUYING' || b.phase === 'SELLING' || b.phase === 'MANUAL') {
        return send(res, 409, { error: 'An order is being processed. Apply settings after it finishes.' });
      }
      const s = b.settings;
      if(body.expectedEntryWindow&&JSON.stringify(EntryWindow.pick(body.expectedEntryWindow))!==JSON.stringify(EntryWindow.pick(s)))
        return send(res,409,{error:'Entry time window changed elsewhere. Reload saved window settings before applying.'});
      if (body.mode && body.mode !== 'paper' && Profiles.paperOnly(b, defaultsFor(b)))
        return send(res, 400, { error: 'The loaded trial and its saved copies are Paper-only. Load Factory baseline or a non-trial profile before changing to Demo/Live.' });
      if (body.mode && body.mode !== s.mode) {
        if (b.running) return send(res, 400, { error: 'Stop the bot before switching modes' });
        const deadline = Date.now() + 9000;
        while (b.busy && Date.now() < deadline) await sleep(100);
        if (b.busy) return send(res, 409, { error: 'Market refresh is busy; try again shortly.' });
      }
      // Validate the complete request before mutating any setting.
      try { Entry.validateSettings(body, s, b.running); }
      catch (err) { return send(res, 400, { error: err.message }); }
      try { Buy.validate(body, s, b.running); }
      catch (err) { return send(res, 400, { error: err.message }); }
      let nowExit;
      try{
        if(Object.hasOwn(body,'nowExit')){
          nowExit=NowExit.validate(LowHighSpread.preserve(body.nowExit,s.nowExit),true);
          if(Object.hasOwn(body,'expectedNowExit')&&JSON.stringify(NowExit.validate(LowHighSpread.preserve(body.expectedNowExit,s.nowExit)))!==JSON.stringify(NowExit.validate(s.nowExit)))
            return send(res,409,{error:'Saved SELL settings changed elsewhere. Reload saved sell settings before applying.'});
          if(b.running&&JSON.stringify(nowExit)!==JSON.stringify(NowExit.validate(s.nowExit)))
            throw Error('Stop the bot before changing LOW/HIGH sell settings.');
        }
      }catch(err){return send(res,400,{error:err.message});}
      let nowEntry;
      try{
        if(Object.hasOwn(body,'nowEntry')){
          const preservePercent=c=>{
            if(!c||typeof c!=='object'||Array.isArray(c))return c;
            const out={...c};
            for(const p of ['up','down'])for(const kind of ['Trail','Stair'])for(const suffix of ['PercentEnabled','Percent']){
              const key=p+kind+suffix;
              if(!Object.hasOwn(out,key))out[key]=s.nowEntry?.[key]??NowEntry.DEFAULTS[key];
            }
            return out;
          };
          nowEntry=NowEntry.validateForApply(LowHighSpread.preserve(preservePercent(body.nowEntry),s.nowEntry));
          if(Object.hasOwn(body,'expectedNowEntry')&&JSON.stringify(NowEntry.validate(LowHighSpread.preserve(preservePercent(body.expectedNowEntry),s.nowEntry)))!==JSON.stringify(NowEntry.validate(s.nowEntry)))
            return send(res,409,{error:'Saved Now settings changed elsewhere. Reload saved Now settings before applying.'});
          if(b.running&&JSON.stringify(nowEntry)!==JSON.stringify(s.nowEntry))
            throw Error('Stop the bot before changing the Now buy monitor.');
        }
      }catch(err){return send(res,400,{error:err.message});}
      let buyConditions;
      try{
        if(Object.hasOwn(body,'buyConditions')){
          buyConditions=BuyConditions.validate(body.buyConditions);
          if(Object.hasOwn(body,'expectedBuyConditions')&&
            JSON.stringify(BuyConditions.validate(body.expectedBuyConditions))!==JSON.stringify(BuyConditions.validate(s.buyConditions)))
            return send(res,409,{error:'Saved buy conditions changed elsewhere. Reload the affected side before applying.'});
          if((b.running||b.busy||b.armedLive)&&JSON.stringify(buyConditions)!==JSON.stringify(BuyConditions.validate(s.buyConditions)))
            throw Error('Stop/disarm and wait for the current operation before changing buy conditions.');
        }
        if(nowEntry||buyConditions)BuyConditions.assertUsage(buyConditions||s.buyConditions,nowEntry||s.nowEntry);
      }catch(err){return send(res,400,{error:err.message});}
      let safety;
      try{
        if(Object.hasOwn(body,'safety')){
          if(!body.safety||typeof body.safety!=='object'||Array.isArray(body.safety))
            throw new Error('Safety settings must be an object.');
          safety=Safety.validate({...s.safety,...body.safety});
          if(Object.hasOwn(body,'expectedSafety')&&(!body.expectedSafety||
            typeof body.expectedSafety!=='object'||Array.isArray(body.expectedSafety)))
            throw new Error('Expected Safety Controls must be an object.');
          if(Object.hasOwn(body,'expectedSafety')&&
            JSON.stringify(Safety.validate({...s.safety,...body.expectedSafety}))!==JSON.stringify(Safety.validate(s.safety)))
            return send(res,409,{error:'Saved Safety Controls changed elsewhere. Revert drafts before applying again.'});
        }
      }catch(err){return send(res,400,{error:err.message});}
      let lineTrail;
      try{
        if(Object.hasOwn(body,'lineTrail')){
          if(!body.lineTrail||typeof body.lineTrail!=='object'||Array.isArray(body.lineTrail))
            throw Error('Trailing-line settings must be an object.');
          lineTrail=Line.validate({...s.lineTrail,...body.lineTrail});
          if(Object.hasOwn(body,'expectedLineTrail')&&
            JSON.stringify(Line.validate(body.expectedLineTrail))!==JSON.stringify(Line.validate(s.lineTrail)))
            return send(res,409,{error:'Saved trailing-line settings changed elsewhere. Reload before applying.'});
          if(JSON.stringify(lineTrail)!==JSON.stringify(Line.validate(s.lineTrail))&&
            (b.running||b.armedLive||b.busy||b.open||b.position||b.paper.pos||b.pendingSettle.length||b.paper.pending.length||
              ['BUYING','SELLING','MANUAL'].includes(b.phase)))
            throw Error('Stop, disarm and finish positions/settlements before changing trailing-line exits.');
        }
      }catch(err){return send(res,400,{error:err.message});}
      let candleReversal;
      try{
        if(Object.hasOwn(body,'candleReversal')){
          if(!body.candleReversal||typeof body.candleReversal!=='object'||Array.isArray(body.candleReversal))
            throw Error('Candle exit settings must be an object.');
          candleReversal=Candle.validate({...s.candleReversal,...body.candleReversal});
          if(Object.hasOwn(body,'expectedCandleReversal')&&
            JSON.stringify(Candle.validate(body.expectedCandleReversal))!==JSON.stringify(Candle.validate(s.candleReversal)))
            return send(res,409,{error:'Saved candle exit settings changed elsewhere. Reload before applying.'});
          if(JSON.stringify(candleReversal)!==JSON.stringify(Candle.validate(s.candleReversal))&&
            (b.running||b.armedLive||b.busy||b.open||b.position||b.paper.pos||b.pendingSettle.length||b.paper.pending.length||
              ['BUYING','SELLING','MANUAL'].includes(b.phase)))
            throw Error('Stop, disarm and finish positions/settlements before changing candle exits.');
        }
      }catch(err){return send(res,400,{error:err.message});}
      let following;
      try{
        if(Object.hasOwn(body,'following')){
          if(!body.following||typeof body.following!=='object'||Array.isArray(body.following))
            throw Error('Following options must be an object.');
          following=Following.validate({...s.following,...body.following});
          if(Object.hasOwn(body,'expectedFollowing')&&
            JSON.stringify(Following.validate(body.expectedFollowing))!==JSON.stringify(Following.validate(s.following)))
            return send(res,409,{error:'Saved trail choices changed elsewhere. Revert drafts before applying.'});
          if(JSON.stringify(following)!==JSON.stringify(Following.validate(s.following))&&
            (b.running||b.armedLive||b.open||b.position||b.paper.pos||b.pendingSettle.length||b.paper.pending.length))
            throw Error('Stop, disarm and close positions/settlements before changing following choices.');
        }
        Following.assertPlan(following||s.following,safety||s.safety);
      }catch(err){return send(res,400,{error:err.message});}
      let rules;
      try {
        if (body.rules) {
          const input={...body.rules};
          // An already-open older tab must not silently disable the new stop.
          for(const side of ['up','down'])for(const suffix of ['Enabled','Buffer']){
            const key=side+'EntryProtection'+suffix;
            if(!Object.hasOwn(input,key))input[key]=s.rules[key]??Guard.DEFAULT_RULES[key];
          }
          for(const side of ['up','down']){
            const key=side+'CashoutBlockEntry';
            if(!Object.hasOwn(input,key))input[key]=s.rules[key]??Guard.DEFAULT_RULES[key];
          }
          for(const key of Object.keys(Volume.DEFAULTS))
            if(!Object.hasOwn(input,key))input[key]=s.rules[key]??Volume.DEFAULTS[key];
          for(const side of ['up','down'])for(const suffix of ['Enabled','Move']){
            const key=side+'TrailFromEntry'+suffix;
            if(!Object.hasOwn(input,key))input[key]=s.rules[key]??Guard.DEFAULT_RULES[key];
          }
          for(const side of ['up','down'])for(const kind of ['Trail','Stair'])for(const suffix of ['PercentEnabled','Percent']){
            const key=side+kind+suffix;
            if(!Object.hasOwn(input,key))input[key]=s.rules[key]??Guard.DEFAULT_RULES[key];
          }
          for(const key of Object.keys(Volume.EXIT_DEFAULTS))
            if(!Object.hasOwn(input,key))input[key]=s.rules[key]??Volume.EXIT_DEFAULTS[key];
          rules=Guard.validateRules(input);
          if(Object.keys(Volume.EXIT_DEFAULTS).some(key=>rules[key]!==s.rules[key])&&
            (b.running||b.armedLive||b.open||b.position||b.paper.pos||b.pendingSettle.length||b.paper.pending.length))
            throw Error('Stop, disarm and finish positions/settlements before changing contract-volume exits.');
        }
      }
      catch (err) { return send(res, 400, { error: err.message }); }
      if (body.entryMethod != null && !['price','spread'].includes(body.entryMethod)) return send(res,400,{error:'Choose contract-price or spread-signal entry.'});
      if (body.entryMethod != null && body.entryMethod !== s.entryMethod && b.running) return send(res,400,{error:'Stop the bot before changing the entry method.'});
      const fields = { triggerPoint: [1,99], dollars: [1,10000], slippage: [0,10] };
      for (const [k, [lo,hi]] of Object.entries(fields)) {
        if (body[k] != null && (body[k] === '' || !Number.isFinite(Number(body[k])) ||
            Number(body[k]) < lo || Number(body[k]) > hi)) return send(res, 400, { error: `${k}: enter ${lo} to ${hi}.` });
      }
      if (body.asset != null && body.asset !== s.asset) return send(res, 400, { error: 'Use the coin picker. This workspace cannot change its coin.' });
      if (body.mode && ['paper', 'demo', 'live'].includes(body.mode) && body.mode !== s.mode) {
        if (b.running) return send(res, 400, { error: 'Stop the bot before switching modes' });
        if (b.open || b.paper.pos || b.pendingSettle.length || b.paper.pending.length) return send(res, 400, { error: 'Close positions and wait for settlements before switching modes.' });
        s.mode = body.mode; b.market = null; b.quote = null; b.lastMarketFetch = 0; b.position = 0; b.balance = null;
        b.nowHistory=[];b.chartTicker=null;volatilityScratch.delete(b);
        b.armedLive = false; b.enteredTicker = null; b.guard = Guard.blank(); b.guardDecision = null;
      }
      for (const k of Object.keys(fields)) if (body[k] != null) s[k] = Number(body[k]);
      // An older client still edits one shared trigger. Honor it for both sides.
      if(body.triggerPoint!=null)for(const side of ['up','down'])
        if(body[side+'BuyCents']===undefined)s[side+'BuyCents']=Number(body.triggerPoint);
      for(const key of ['upBuyCents','downBuyCents'])if(body[key]!==undefined)s[key]=Number(body[key]);
      for (const k of Object.keys(Buy.DEFAULTS)) if (body[k] !== undefined) s[k] = Number(body[k]);
      for (const k of Object.keys(Entry.DEFAULTS)) {
        if (body[k] !== undefined) s[k] = Entry.settingValue(k,body[k]);
      }
      if(EntryWindow.KEYS.some(k=>body[k]!==undefined)){
        b.entrySignals={};b.safetyEntries={};b.nowDirection=null;
        addLog(b,'Entry time window saved. No bot started or armed; exits unchanged.');
      }
      if (body.entryMethod != null) { s.entryMethod = body.entryMethod; b.entrySignals = {}; }
      if(nowEntry){s.nowEntry=nowEntry;b.nowDirection=null;b.entrySignals={};b.safetyEntries={};}
      if(buyConditions){s.buyConditions=buyConditions;b.nowDirection=null;b.entrySignals={};b.safetyEntries={};}
      if(nowExit){s.nowExit=nowExit;b.lowHighExit=null;b.guard=Guard.blank();b.guardDecision=null;}
      if(following)s.following=following;
      if(candleReversal){s.candleReversal=candleReversal;b.candleReversalState=null;}
      if(lineTrail)s.lineTrail=lineTrail;
      if(safety){
        s.safety=safety;b.safetyEntries={};b.entrySignals={};b.lossCooldown=null;
        addLog(b,'Safety controls saved. Entry timers reset; existing loss locks and position anchors retained.','info');
      }
      if (rules) {
        s.rules = rules; b.guard = Guard.blank(); b.guardDecision = null;
        if(b.open?.trail){b.open.trail.since=null;b.open.trail.last=null;}
        if(b.open?.stair){b.open.stair.since=null;b.open.stair.last=null;}
        b.entrySignals = {};
        addLog(b, 'UP/DOWN buy and sell rules applied. Entry and exit confirmation timers reset.', 'info');
      }
      persist();
      return send(res, 200, publicState(b));
    }

    if (url.pathname === '/api/keys' && req.method === 'POST') {
      const body = await readBody(req);
      if (b.running || b.phase === 'MANUAL' || b.open) return send(res, 400, { error: 'Stop the bot and close this copy’s position before changing credentials.' });
      b.armedLive = false;
      if (body.clear) { b.creds = null; persist(); addLog(b, 'API key removed'); return send(res, 200, publicState(b)); }
      const keyId = String(body.keyId || '').trim();
      let pem = String(body.privateKey || '').trim().replace(/\r/g, '');
      if (!keyId || !pem) return send(res, 400, { error: 'Key ID and private key are both required' });
      try { crypto.createPrivateKey(pem); } catch { return send(res, 400, { error: 'Private key could not be read. Paste the full key including the BEGIN/END lines.' }); }
      const env = b.settings.mode === 'demo' ? 'demo' : 'live';
      try {
        const bal = await kalshi(env, 'GET', '/portfolio/balance', { creds: { keyId, privateKey: pem } });
        b.creds = { keyId, privateKey: pem, env };
        b.balance = bal.balance_dollars != null ? parseFloat(bal.balance_dollars) : bal.balance / 100;
        persist();
        addLog(b, `API key verified on ${env} (balance $${(b.balance ?? 0).toFixed(2)})`, 'good');
        return send(res, 200, publicState(b));
      } catch (e) {
        return send(res, 400, { error: `Kalshi rejected the key on ${env}: ${e.message}` });
      }
    }

    if (url.pathname === '/api/start' && req.method === 'POST') {
      if(b.root&&!b.coinReviewed)return send(res,400,{error:`Review and confirm your ${asset} settings before starting.`});
      if(singleBotBlocked(res,b))return;
      if(duplicateConnection(b))return send(res,409,{error:'Another bot is running with this Kalshi key. Reconnect to that session instead of starting a duplicate.'});
      if (Profiles.paperOnly(b, defaultsFor(b)) && b.settings.mode !== 'paper')
        return send(res, 400, { error: 'The loaded trial profile is Paper-only.' });
      if (b.phase === 'MANUAL') return send(res, 409, { error: 'Wait for the manual order to finish.' });
      if (b.settings.mode !== 'paper' && !tradeCreds(b)) return send(res, 400, { error: `Add a ${envOf(b)} Kalshi API key in Settings first, or use Paper mode` });
      if (b.settings.mode !== 'paper' && !b.armedLive) return send(res, 400, { error: 'Arm trading in Settings before starting.' });
      if (!b.running) {
        b.running = true; b.phase = 'STARTING';
        b.nowDirection=null;
        b.entrySignals = {};b.safetyEntries={};b.lossCooldown=null;
        addLog(b, `Bot started (${b.settings.mode.toUpperCase()}, ${asset}): ${b.settings.nowEntry?.enabled?'ONLY checked low/high entry conditions':b.settings.entryMethod === 'spread' ? 'confirmed spread entry' : `UP > ${Buy.priceThreshold(b.settings,'UP')}¢ / DOWN > ${Buy.priceThreshold(b.settings,'DOWN')}¢ plus signed Now`}; selected exits.`, 'accent');
        persist();
      }
      return send(res, 200, publicState(b));
    }

    if (url.pathname === '/api/stop' && req.method === 'POST') {
      b.candleReversalState=null;
      if(b.open?.lineTrail){
        b.open.lineTrail.since=null;b.open.lineTrail.last=null;
        b.open.lineTrail.sourceAt=null;b.open.lineTrail.observedAt=null;
        b.open.lineTrail.monitorAt=Date.now();
      }
      b.entrySignals = {};b.safetyEntries={};b.lowHighExit=null;b.nowDirection=null;b.lossCooldown=null;
      if (b.running) {
        b.running = false;
        // Do not hide an order already submitted. A second bot must wait for
        // its outcome even though future automation has been stopped.
        if(!['BUYING','SELLING','MANUAL'].includes(b.phase))b.phase='IDLE';
        addLog(b, 'Bot stopped', 'warn'); persist();
      }
      b.armedLive = false;
      return send(res, 200, publicState(b));
    }

    if (url.pathname === '/api/arm' && req.method === 'POST') {
      const body = await readBody(req);
      if(b.root&&!b.coinReviewed)return send(res,400,{error:`Review and confirm your ${asset} settings before arming.`});
      if(singleBotBlocked(res,b))return;
      if(duplicateConnection(b))return send(res,409,{error:'Another bot is running with this Kalshi key. Reconnect to that session instead of arming a duplicate.'});
      if (Profiles.paperOnly(b, defaultsFor(b)))
        return send(res, 400, { error: 'The loaded trial profile cannot arm exchange trading. It is Paper-only.' });
      if (body.confirm !== 'ARM TRADING') return send(res, 400, { error: 'Explicit trading confirmation is required.' });
      if (b.running) return send(res, 400, { error: 'Stop before arming.' });
      if (b.settings.mode === 'paper' || !tradeCreds(b)) return send(res, 400, { error: 'Select Demo/Live and verify a matching API key first.' });
      b.armedLive = true;
      addLog(b, `${b.settings.mode.toUpperCase()} trading armed by user.`, 'warn');
      return send(res, 200, publicState(b));
    }

    if (url.pathname === '/api/trade' && req.method === 'POST') {
      if(duplicateConnection(b))return send(res,409,{error:'Another bot is running with this Kalshi key. Reconnect before placing a manual order here.'});
      const body = await readBody(req);
      const side = body.side === 'DOWN' ? 'DOWN' : 'UP';
      if (b.running) return send(res, 400, { error: 'Stop the bot to trade manually' });
      if (b.settings.mode !== 'paper' && !tradeCreds(b)) return send(res, 400, { error: `Add a ${envOf(b)} Kalshi API key in Settings first` });
      if (b.settings.mode !== 'paper' && !b.armedLive) return send(res, 400, { error: 'Arm trading in Settings first.' });
      if (!b.market) return send(res, 400, { error: 'No open session right now' });
      const waitUntil = Date.now() + 9000;
      while (b.busy && Date.now() < waitUntil) await sleep(100);
      if (b.busy) return send(res, 409, { error: 'Market refresh is busy. Try again shortly.' });
      // Closing an existing position remains available. New manual positions
      // must not bypass the one-active-bot guard.
      if(!ownedSide(b)&&!heldSide(b)&&singleBotBlocked(res,b))return;
      b.busy = true; b.phase = 'MANUAL';
      try {
        await refreshPosition(b, true);
        const held = ownedSide(b)||heldSide(b);
        if (held === side) { addLog(b, `Manual SELL ${side}`, 'accent'); await sellWithRetry(b, side); }
        else if (held) { addLog(b, `You hold ${held}. Close it before buying ${side}.`, 'warn'); }
        else {
          if(b.root&&!b.coinReviewed)return send(res,400,{error:`Review and confirm your ${asset} settings before buying.`});
          if(singleBotBlocked(res,b))return;
          const eligibility = Entry.status(b);
          if (!eligibility.allowed) return send(res, 400, { error: eligibility.reason });
          if (!marketFeed(b).snapshot(b.market.strike, b.quote?.ts).ready) return send(res, 400, { error: 'Fresh Coinbase, two venues, and a target are required before buying.' });
          addLog(b, `Manual BUY ${side}`, 'accent'); await buyWithRetry(b, side);
        }
      } finally { b.busy = false; b.phase = 'IDLE'; }
      return send(res, 200, publicState(b));
    }

    if (url.pathname === '/api/paper/reset' && req.method === 'POST') {
      if (b.settings.mode !== 'paper' || b.running) return send(res, 400, { error: 'Stop in Paper mode before resetting.' });
      const deadline = Date.now() + 9000;
      while (b.busy && Date.now() < deadline) await sleep(100);
      if (b.busy) return send(res, 409, { error: 'Market refresh is busy; try again shortly.' });
      if (b.paper.pos || b.paper.pending.length) return send(res, 400, { error: 'Close paper positions and wait for settlement before resetting.' });
      b.paper = { cash: 1000, pos: 0, side: null, avg: 0, pnl: 0, trades: 0, wins: 0, pending: [] };
      b.position = 0; addLog(b, 'Paper account reset to $1,000'); persist();
      return send(res, 200, publicState(b));
    }

    if (url.pathname === '/api/log/clear' && req.method === 'POST') { b.log = []; return send(res, 200, publicState(b)); }
    if (url.pathname === '/api/results/clear' && req.method === 'POST') { b.history = (b.history || []).filter((r) => r.mode !== b.settings.mode); persist(); return send(res, 200, publicState(b)); }

    send(res, 404, { error: 'Not found' });
  } catch (e) {
    send(res, 500, { error: e.message });
  }
});

if (require.main === module) {
  feed.start();
  for(const [id,saved] of Object.entries(store)){
    if(Object.values(saved.coinWorkspaces||{}).some(v=>v.open||v.paper?.pos||v.pendingSettle?.length||v.paper?.pending?.length))
      getBot(id);
  }
  server.listen(PORT, process.env.SPREAD_GUARD_HOST || '0.0.0.0', () => console.log('Spread Guard server on :' + PORT));
}
module.exports = { server, getBot, getCoinBot, hasSession, step, publicState, placeOrder, sellWithRetry, ledgerBuy, ledgerSell, candleMark, DEFAULT_SETTINGS, feed, indexFeed, contractVolume,sellContractVolume,connections,volatilityCandles,observationCandles };
