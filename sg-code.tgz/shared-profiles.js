'use strict';
const fs=require('node:fs');
const crypto=require('node:crypto');
const Profiles=require('./settings-profiles');

function clean(p){
  if(!p||typeof p.id!=='string'||!p.id||p.id.length>128||
    ['factory-baseline','paper-trailing-trial-1'].includes(p.id)||
    typeof p.name!=='string'||!p.name.trim()||p.name.trim().length>40||
    /[\x00-\x1f\x7f]/.test(p.name))
    throw Error('Invalid saved strategy profile in shared library.');
  return {id:p.id,name:p.name.trim(),builtIn:false,paperOnly:p.paperOnly===true,
    createdAt:Number.isFinite(p.createdAt)?p.createdAt:0,
    updatedAt:Number.isFinite(p.updatedAt)?p.updatedAt:0,
    description:typeof p.description==='string'?p.description.slice(0,2000):'Saved strategy settings.',
    config:Profiles.snapshot(p.config)};
}
function signature(p){
  const c=structuredClone(p.config);delete c.triggerPoint;
  return JSON.stringify({paperOnly:p.paperOnly,config:c});
}
function migrate(records){
  const groups=new Map();
  for(const [visitor,b]of Object.entries(records)){
    // Historical local fixtures stay in data.json, not the user's shared library.
    if(/(^qa-|(?:^|-)qa$|fixture|^local$)/i.test(visitor))continue;
    for(const raw of b.profiles||[]){
      const p=clean(raw),sig=signature(p);
      if(!groups.has(p.id))groups.set(p.id,new Map());
      const variants=groups.get(p.id),old=variants.get(sig);
      if(!old||p.updatedAt>=old.updatedAt)variants.set(sig,p);
    }
  }
  const out=[],names=new Set(['factory baseline','trailing trial 1 (paper)']);
  function add(p){
    let name=p.name,n=1;
    while(names.has(name.toLowerCase())){
      const suffix=` (recovered ${n++})`;
      name=p.name.slice(0,40-suffix.length)+suffix;
    }
    names.add(name.toLowerCase());out.push({...p,name});
  }
  for(const [id,variants]of groups){
    const sorted=[...variants.entries()].sort((a,b)=>b[1].updatedAt-a[1].updatedAt);
    add(sorted[0][1]);
    for(const [sig,p]of sorted.slice(1)){
      const recoveredId='recovered-'+crypto.createHash('sha256').update(id+sig).digest('hex').slice(0,24);
      add({...p,id:recoveredId});
    }
  }
  return out;
}
class SharedProfileLibrary{
  constructor({enabled=true,file=null,records={}}={}){
    this.enabled=enabled;this.file=file;this.profiles=[];
    if(!enabled)return;
    let saved;
    if(file){
      try{saved=JSON.parse(fs.readFileSync(file,'utf8'));}
      catch(e){if(e.code!=='ENOENT')throw Error('Cannot read shared profile library; original file retained: '+e.message);}
    }
    if(saved!==undefined){
      if(!saved||saved.version!==1||!Array.isArray(saved.profiles))throw Error('Invalid shared profile library; original file retained.');
      this.profiles=saved.profiles.map(clean);
      if(new Set(this.profiles.map(p=>p.id)).size!==this.profiles.length||
        new Set(this.profiles.map(p=>p.name.toLowerCase())).size!==this.profiles.length)
        throw Error('Duplicate entries in shared profile library; original file retained.');
    }else{
      this.profiles=migrate(records);
      this.flush();
    }
  }
  attach(b){
    if(!this.enabled)return;
    Object.defineProperty(b,'profiles',{enumerable:true,configurable:true,
      get:()=>this.profiles,set:value=>{this.profiles=value;}});
    b.profilesShared=true;
  }
  flush(){
    if(!this.enabled||!this.file)return;
    const profiles=this.profiles.map(clean);
    const tmp=this.file+'.tmp-'+process.pid;
    try{
      fs.writeFileSync(tmp,JSON.stringify({version:1,profiles}),{mode:0o600});
      fs.renameSync(tmp,this.file);
    }catch(e){
      try{fs.unlinkSync(tmp);}catch{}
      throw Error('Shared profiles were not saved. Please retry; the previous library is intact. '+e.message);
    }
  }
}
module.exports={SharedProfileLibrary,migrate};
