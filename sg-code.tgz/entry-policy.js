'use strict';
const Window=require('./public/entry-window');

const DEFAULTS = { ...Window.DEFAULTS,reentryEnabled: false, reentryCooldown: 30, maxTradesPerMarket: 3,
  upRebuyEnabled:false,upRebuyDirection:'above',upRebuyMove:20,
  downRebuyEnabled:false,downRebuyDirection:'below',downRebuyMove:20 };
const settingValue=(key,value)=>typeof DEFAULTS[key]==='number'?Number(value):value;

function validateSettings(body, settings, running) {
  Window.validate(body,settings,running);
  for (const key of Object.keys(DEFAULTS)) {
    if(Window.KEYS.includes(key))continue;
    if (body[key] === undefined) continue;
    if (typeof DEFAULTS[key] === 'boolean') {
      if (typeof body[key] !== 'boolean') throw new Error('Re-entry must be checked or unchecked.');
    } else if(key.endsWith('Direction')){
      if(!['above','below'].includes(body[key]))throw new Error(`${key}: choose above or below.`);
    } else {
      const move=key.endsWith('Move');
      const lo = key === 'reentryCooldown' ? 0 : 1;
      const hi = key === 'reentryCooldown' ? 3600 : 100;
      if (body[key] === null || typeof body[key] === 'boolean' ||
          typeof body[key]==='object'||String(body[key]).trim()===''||
          !Number.isFinite(Number(body[key]))||
          (!move&&!Number.isInteger(Number(body[key]))) ||
          Number(body[key]) < (move?0:lo) || Number(body[key]) > (move?100000:hi)) {
        throw new Error(`${key}: enter ${move?'a dollar amount from 0 to 100000':`a whole number from ${lo} to ${hi}`}.`);
      }
    }
    const value = settingValue(key,body[key]);
    if (running && value !== settings[key]) throw new Error('Stop the bot before changing re-entry settings.');
  }
}

function record(b) {
  if (!b.market) return { entries: 0, lastSellAt: null };
  b.entryLedger ||= {};
  const key = `${b.settings.mode}:${b.market.ticker}`;
  if (!b.entryLedger[key]) {
    // Older versions had one entry per market. Closed rows can be partial fills,
    // so count them conservatively rather than accidentally granting extra trades.
    const rows = (b.history || []).filter(r => r.mode === b.settings.mode && r.ticker === b.market.ticker);
    const owned = b.open?.ticker === b.market.ticker;
    const entered = b.enteredTicker === b.market.ticker;
    const sold = rows.filter(r => ['sold', 'spread exit', 'now-only exit'].includes(r.how));
    b.entryLedger[key] = {
      entries: Math.max(entered || owned ? 1 : 0, rows.length + (owned ? 1 : 0)),
      lastSellAt: !owned && sold.length ? Math.max(...sold.map(r => r.at)) : null,
    };
  }
  return b.entryLedger[key];
}

function status(b, now = Date.now()) {
  const r = record(b), enabled = b.settings.reentryEnabled === true;
  const max = enabled ? b.settings.maxTradesPerMarket : 1;
  const remainingMs = r.lastSellAt == null ? 0 :
    Math.max(0, r.lastSellAt + b.settings.reentryCooldown * 1000 - now);
  const window=Window.evaluate(b.settings,b.market,now);
  const base = { entries: r.entries, max, enabled, remainingMs, allowed: false,window };
  if (!b.market) return { ...base, reason: 'Waiting for an open market.' };
  if (now >= b.market.closeTime - 5000) return { ...base, reason: 'No new entries in the final 5 seconds.' };
  if (b.open || b.position) return { ...base, reason: 'Close the current position before another entry.' };
  if(!window.allowed)return {...base,reason:window.reason};
  if (r.cashoutLocked) return { ...base, reason: 'Timed cash-out completed. Re-entry blocked for this market; waiting for next market.' };
  if (r.entries >= max) return { ...base, reason: enabled ?
    `Market trade limit reached (${r.entries}/${max}). Waiting for next market.` :
    'Re-entry is off. One entry per market; waiting for next market.' };
  if (r.entries && r.lastSellAt == null) return { ...base, reason: 'No confirmed completed sell. Re-entry blocked.' };
  if (r.entries && remainingMs) return { ...base, reason: `Re-entry cooldown: ${Math.ceil(remainingMs / 1000)}s remaining.` };
  return { ...base, allowed: true, reason: r.entries ?
    'Cooldown complete. Waiting for a fresh entry signal.' : 'Waiting for an entry signal.' };
}

// Only confirmed executions enter this independent, session-private marker
// ledger. Do not infer Now from a sale price or a nearby chart observation.
function recordSale(b,fill,nowValue,completed,at=Date.now()){
  const r=record(b);
  const marker={at,mode:b.settings.mode,ticker:b.market.ticker,side:fill.side,
    now:Number.isFinite(nowValue)?nowValue:null,count:fill.filled,price:fill.px,completed};
  const o=b.open;
  if(o&&o.count>0&&o.ticker===b.market.ticker&&o.side===fill.side&&
    (!o.mode||o.mode===b.settings.mode)&&Number.isFinite(o.startedAt)){
    // Additive observation only. Never infer entry Now from a later price,
    // chart sample, sale or contract cost, including legacy missing anchors.
    marker.buy={id:o.tradeId||`${b.settings.mode}:${o.ticker}:${o.side}:${o.startedAt}`,
      mode:b.settings.mode,ticker:o.ticker,side:o.side,at:o.startedAt,
      now:Number.isFinite(o.entryNow)?o.entryNow:null,
      price:Number.isFinite(o.avg)?o.avg:null};
  }
  b.sellMarkers ||= [];
  b.sellMarkers.push(marker);
  b.sellMarkers=b.sellMarkers.slice(-500);
  if(completed){
    r.lastSellNow=marker.now;
    r.lastSellNowAt=at;
  }
  return marker;
}
function rebuy(b,m,side){
  const p=side==='UP'?'up':'down',s=b.settings,r=record(b);
  const enabled=s[p+'RebuyEnabled']===true;
  const base={enabled,allowed:true,applicable:false,direction:s[p+'RebuyDirection']||DEFAULTS[p+'RebuyDirection'],
    move:s[p+'RebuyMove']??DEFAULTS[p+'RebuyMove'],soldNow:r.lastSellNow??null,
    soldAt:r.lastSellNowAt??null,level:null};
  if(!enabled)return {...base,reason:`${side} sold-point re-entry OFF.`};
  if(!r.entries)return {...base,reason:`First ${side} entry: no sold-point gate.`};
  const active={...base,applicable:true};
  if(!s.reentryEnabled)return {...active,allowed:false,reason:'Enable ordinary re-entry first.'};
  if(!Number.isFinite(r.lastSellAt)||!Number.isFinite(r.lastSellNow)||r.lastSellNowAt!==r.lastSellAt)
    return {...active,allowed:false,reason:`${side} re-entry waits: latest completed sell has no recorded fresh Now. No reference is guessed.`};
  active.level=r.lastSellNow+(active.direction==='above'?active.move:-active.move);
  if(m?.ready!==true||!Number.isFinite(m.nowDiff))
    return {...active,allowed:false,reason:`${side} sold-point re-entry waits for fresh Now.`};
  const allowed=active.direction==='above'?m.nowDiff>=active.level:m.nowDiff<=active.level;
  return {...active,allowed,reason:`${side} re-entry needs Now ${active.direction==='above'?'at/above':'at/below'} ${active.level.toFixed(2)} (sold ${r.lastSellNow.toFixed(2)}, ${active.direction} by $${active.move}). ${allowed?'Point reached; other buy rules still apply.':'Waiting for movement.'}`};
}
function sales(b){
  return (b.sellMarkers||[]).filter(s=>s.mode===b.settings.mode&&s.ticker===b.market?.ticker);
}
module.exports = { DEFAULTS, validateSettings, settingValue, record, status, recordSale, rebuy, sales };
