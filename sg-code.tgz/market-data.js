'use strict';
const WebSocket = require('ws');
const {LiveCandleFeed}=require('./live-candle-feed');
const {assets}=require('./assets-config');
function createMarketFeed(asset='BTC',Socket=WebSocket){
if(!Object.hasOwn(assets,asset))throw Error('Unknown feed asset');
const candleFeed=new LiveCandleFeed(asset);
const pair=`${asset}-USD`, slash=`${asset}/USD`, symbol=`${asset.toLowerCase()}usd`;
const STALE_MS = 15000;
const venues = {};
const sockets = new Map();
let started = false;
function tick(name, raw, sourceTime, tradeId) {
  const price = Number(raw);
  if (!Number.isFinite(price) || price <= 0) return;
  // A delayed historical trade must not be treated as a fresh price.
  if (sourceTime && Math.abs(Date.now() - sourceTime) > STALE_MS) return;
  venues[name] = { name, price, at: Date.now(), connected: true };
  if(name==='Coinbase')candleFeed.observe(price,sourceTime,Date.now(),tradeId);
}
function connect(name, url, subscribe, parse) {
  let attempt = 0;
  function open() {
    const ws = new Socket(url, { handshakeTimeout: 10000 });
    sockets.set(name, ws);
    ws.on('open', () => { attempt = 0; if (subscribe) ws.send(JSON.stringify(subscribe)); });
    ws.on('message', raw => {
      try { parse(JSON.parse(raw.toString()), (p, t, id) => tick(name, p, t, id)); } catch {}
    });
    ws.on('error', () => ws.close());
    ws.on('close', () => {
      if (venues[name]) venues[name].connected = false;
      if(name==='Coinbase')candleFeed.disconnect();
      const timer = setTimeout(open, Math.min(30000, 2000 * 2 ** attempt++));
      timer.unref();
    });
    const heartbeat = setInterval(() => {
      if (ws.readyState === Socket.OPEN) {
        if (ws._waitingPong) ws.terminate();
        else { ws._waitingPong = true; ws.ping(); }
      }
    }, 12000);
    heartbeat.unref();
    ws.on('pong', () => { ws._waitingPong = false; });
    ws.on('close', () => clearInterval(heartbeat));
  }
  open();
}
function start() {
  if (started) return;
  started = true;
  connect('Coinbase', 'wss://ws-feed.exchange.coinbase.com',
    { type: 'subscribe', product_ids: [pair], channels: ['ticker'] },
    (d, put) => { if (d.type === 'ticker' && d.product_id === pair) {
      const at=Date.parse(d.time);
      if(asset==='BTC'||Number.isFinite(at))put(d.price,at,d.trade_id);
    } });
  connect('Kraken', 'wss://ws.kraken.com/v2',
    { method: 'subscribe', params: { channel: 'ticker', symbol: [slash], event_trigger: 'trades', snapshot: true } },
    (d, put) => { if (d.channel === 'ticker') for (const t of d.data || [])
      if(t.symbol===slash&&(asset==='BTC'||d.type==='update'))put(t.last); });
  // The original BTC aggregate is unchanged. ETH/SOL use the two confirmed USD pairs.
  if(asset!=='BTC')return;
  connect('Bitstamp', 'wss://ws.bitstamp.net',
    { event: 'bts:subscribe', data: { channel: `live_trades_${symbol}` } },
    (d, put) => { if (d.event === 'trade') put(d.data?.price, Number(d.data?.timestamp) * 1000); });
  connect('Gemini', `wss://api.gemini.com/v1/marketdata/${symbol}`, null,
    (d, put) => { for (const e of d.events || []) if (e.type === 'trade' && e.reason !== 'initial') put(e.price, d.timestampms); });
}
function snapshot(strike, quoteTs, now = Date.now()) {
  const rows = (asset==='BTC'?['Coinbase', 'Kraken', 'Bitstamp', 'Gemini']:['Coinbase','Kraken']).map(name => {
    const v = venues[name];
    return { name, price: v?.price ?? null, ageMs: v ? now - v.at : null,
      fresh: !!v && v.connected && now - v.at <= STALE_MS };
  });
  const fresh = rows.filter(v => v.fresh);
  const cb = rows[0];
  const aggregate = fresh.length ? fresh.reduce((sum, v) => sum + v.price, 0) / fresh.length : null;
  const hasTarget = typeof strike === 'number' && Number.isFinite(strike);
  let reason = null;
  if (!cb.fresh) reason = 'Coinbase feed is unavailable or older than 15 seconds.';
  else if (fresh.length < 2) reason = 'At least two fresh USD venues are required.';
  else if (!hasTarget) reason = 'Waiting for the current Kalshi target.';
  else if (!quoteTs || now - quoteTs > 10000) reason = 'Kalshi quote is unavailable or older than 10 seconds.';
  return { ready: !reason, reason, venues: rows, count: fresh.length,
    coinbase: cb.fresh ? cb.price : null, aggregate,
    spread: cb.fresh && aggregate != null ? aggregate - cb.price : null,
    targetDiff: hasTarget && aggregate != null ? aggregate - strike : null,
    nowDiff: hasTarget && cb.fresh ? cb.price - strike : null,
    strike: hasTarget ? strike : null, timestamp: now, staleMs: STALE_MS,
    method: 'Equal-weight mean of fresh last-trade prices, USD pairs only; includes Coinbase.' };
}
return { start, snapshot, candleFeed };
}
module.exports = {...createMarketFeed(),createMarketFeed};
