'use strict';
const MODES=new Set(['live','paper']), SIDES=['up','down'], STRICT='requireTwoCrossings', MIN_CROSSINGS=2;
const KEYS=[...SIDES,STRICT];
const available=mode=>MODES.has(mode);
const options=(mode,input)=>Object.fromEntries(KEYS.map(key=>[key,available(mode)&&input?.[key]===true]));
function writeOptions(input){
  if(!input||typeof input!=='object'||Array.isArray(input)||
    !SIDES.every(k=>Object.hasOwn(input,k))||
    Object.keys(input).some(k=>!KEYS.includes(k)||typeof input[k]!=='boolean'))
    throw Error('Provide UP and DOWN switches and, optionally, the crossing requirement as on/off values.');
  // Old clients write just the two sides. Omission is not a request to clear strict mode.
  return Object.fromEntries(KEYS.filter(k=>Object.hasOwn(input,k)).map(k=>[k,input[k]]));
}
function evaluate(enabled,reading,side,requireTwoCrossings=false){
  if(!enabled)return {enabled:false,allowed:true,label:null,reason:`${side} filter off.`};
  const label=reading?.label||'UNAVAILABLE';
  const score=Number.isFinite(reading?.score)?reading.score:null;
  const crossings=Number.isSafeInteger(reading?.crossings)&&reading.crossings>=0?reading.crossings:null;
  const measured={enabled:true,label,score,crossings,minCrossings:requireTwoCrossings?MIN_CROSSINGS:0};
  if(label==='CHOPPY'&&(!requireTwoCrossings||crossings>=MIN_CROSSINGS))
    return {...measured,allowed:false,
      reason:`Skip choppy buys: ${side} automatic buy blocked by Choppy Kalshi Now${score===null?'':` (${score}/100)`}`+
        (requireTwoCrossings?` with ${crossings} target crossings.`:'.')};
  return {...measured,allowed:true,reason:label==='UNAVAILABLE'?
    `Skip choppy buys: ${side} Kalshi Now unavailable; existing buy rules still apply.`:
    label==='CHOPPY'&&requireTwoCrossings?`${side} Choppy reading did not meet the two-crossing requirement.`:
    `${side} ${label.toLowerCase()} reading does not block an automatic buy.`};
}
module.exports={KEYS,STRICT,available,options,writeOptions,evaluate};
