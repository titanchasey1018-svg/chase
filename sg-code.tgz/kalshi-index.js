'use strict';
const NativeWebSocket=require('ws');
const {assets,matchesMarket}=require('./assets-config');
const URL='wss://external-api-ws.kalshi.com/trade-api/ws/v2';
const PATH='/trade-api/ws/v2';
const STALE_MS=5000;
class KalshiIndex {
  constructor({signHeaders,WebSocket=NativeWebSocket,now=Date.now,enabled=true,
    setIntervalFn=setInterval,clearIntervalFn=clearInterval,
    fetchImpl=(...args)=>fetch(...args)}={}){
    this.signHeaders=signHeaders;this.WebSocket=WebSocket;this.now=now;this.enabled=enabled;
    this.clients=new Map();
    this.setInterval=setIntervalFn;this.clearInterval=clearIntervalFn;
    this.fetch=fetchImpl;this.publicCache=new Map();
  }
  publicSnapshot(b){
    const asset=b.settings?.asset??'BTC',event=b.market?.eventTicker;
    if(!this.enabled||typeof event!=='string'||!event)return null;
    if(!Object.hasOwn(assets,asset)||(asset!=='BTC'&&!matchesMarket(asset,event)))return null;
    const cacheKey=asset==='BTC'?event:`${asset}:${event}`;
    let c=this.publicCache.get(cacheKey);
    if(!c){
      if(this.publicCache.size>=16)this.publicCache.delete(this.publicCache.keys().next().value);
      c={nextTry:0,busy:false,last:null,status:'connecting',reason:'Connecting to the public Kalshi chart reference.'};
      this.publicCache.set(cacheKey,c);
    }
    if(!c.busy&&this.now()>=c.nextTry){
      c.busy=true;c.nextTry=this.now()+2000;
      const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),4000);
      c.pending=(async()=>{
        try{
          const response=await this.fetch('https://api.elections.kalshi.com/trade-api/v2/live_data/events/'+
            encodeURIComponent(event)+'?range=15min',{headers:{Accept:'application/json'},signal:controller.signal});
          if(!response.ok){
            c.nextTry=this.now()+(response.status===429?15000:5000);
            throw new Error('unavailable');
          }
          const raw=(await response.json()).live_data,d=raw?.details;
          if(raw?.type!=='crypto'||raw.is_historical!==false||d?.coin?.toUpperCase()!==asset||
            d.event_ticker!==event||!Array.isArray(d.timeseries))throw new Error('unavailable');
          const latest=d.timeseries.reduce((best,p)=>{
            const t=Number(p.t),v=Number(p.v);
            return Number.isFinite(t)&&Number.isFinite(v)&&v>0&&(!best||t>best.sourceTime)?
              {value:v,sourceTime:t}:best;
          },null);
          if(!latest||latest.sourceTime-this.now()>1000)throw new Error('unavailable');
          c.last={...latest,receivedTime:this.now()};
          c.status='live';c.reason='';c.nextTry=this.now()+2000;
        }catch{
          c.status='unavailable';c.reason='Public Kalshi chart reference unavailable. Optional production API access can provide the faster authenticated index stream.';
          c.nextTry=Math.max(c.nextTry,this.now()+5000);
        }finally{clearTimeout(timer);c.busy=false;}
      })();
    }
    const last=c.last,age=last?Math.max(0,this.now()-last.sourceTime):null;
    const fresh=!!last&&age<=STALE_MS&&last.sourceTime-this.now()<=1000;
    return {indexId:asset,source:'Kalshi public event chart',sourceKind:'public_chart',
      status:fresh?'live':last?'stale':c.status,fresh,price:fresh?last.value:null,
      nowDiff:fresh&&Number.isFinite(b.market?.strike)?last.value-b.market.strike:null,
      sourceTime:last?.sourceTime??null,receivedTime:last?.receivedTime??null,ageMs:age,
      reason:fresh?'':last?'Public chart reference is older than 5 seconds; no live comparison shown.':c.reason,
      channel:'public_event_chart'};
  }
  close(b){
    const c=this.clients.get(b);
    if(!c)return;
    this.clients.delete(b);
    const ws=c.ws;c.ws=null;
    this.clearInterval(c.timer);
    if(ws)ws.terminate();
  }
  ensure(b){
    const creds=b.creds;
    if(!creds || (creds.env||'live')!=='live'){this.close(b);return null;}
    let c=this.clients.get(b);
    if(c&&c.creds!==creds){this.close(b);c=null;}
    if(!c){
      const index=assets[b.settings?.asset??'BTC']?.index;
      if(!index)return null;
      c={creds,index,ws:null,last:null,channel:'cfbenchmarks_value_5hz',retryAt:0,attempts:0,
        status:'connecting',reason:`Connecting to the production CF ${index} index.`,blocked:false};
      this.clients.set(b,c);
    }
    if(!this.enabled){c.status='unavailable';c.reason='Index network connection disabled in this test runtime.';return c;}
    if(c.ws || c.blocked || this.now()<c.retryAt)return c;
    let ws;
    try{
      const headers=this.signHeaders(creds,'GET',PATH);
      ws=new this.WebSocket(URL,{headers,handshakeTimeout:10000});
    }catch{
      c.status='unavailable';c.reason='Index connection could not be authenticated. Verify the production key.';
      c.retryAt=this.now()+60000;return c;
    }
    c.ws=ws;c.status='connecting';c.reason=`Waiting for a fresh CF ${c.index} index value.`;
    const current=()=>this.clients.get(b)===c&&c.ws===ws;
    const subscribe=()=>ws.send(JSON.stringify({id:c.channel==='cfbenchmarks_value_5hz'?1:2,
      cmd:'subscribe',params:{channels:[c.channel],index_ids:[c.index]}}));
    ws.on('open',()=>{if(current())subscribe();});
    ws.on('message',raw=>{
      if(!current())return;
      let d;try{d=JSON.parse(raw.toString());}catch{return;}
      if(d.type==='error'){
        if(d.msg?.code===8&&c.channel==='cfbenchmarks_value_5hz'){
          c.channel='cfbenchmarks_value';c.last=null;subscribe();return;
        }
        c.blocked=true;c.status='no_access';
        c.reason='Kalshi did not grant this index subscription. Verify account feed access and the production key.';
        ws.terminate();return;
      }
      if(!['cfbenchmarks_value_5hz','cfbenchmarks_value'].includes(d.type) || d.type!==c.channel)return;
      const m=d.msg;
      if(m?.index_id!==c.index)return;
      let upstream;try{upstream=typeof m.data==='string'?JSON.parse(m.data):m.data;}catch{return;}
      if(upstream?.id&&upstream.id!==c.index)return;
      const value=Number(m.value_usd??upstream?.value),ts=Number(m.source_ts_ms??upstream?.time),now=this.now();
      if(!(value>0)||!Number.isFinite(value)||!Number.isFinite(ts)||ts<=0||
        now-ts>STALE_MS||ts-now>1000||(c.last&&ts<=c.last.sourceTime))return;
      c.last={value,sourceTime:ts,receivedTime:now};c.attempts=0;c.status='live';c.reason='';
    });
    ws.on('unexpected-response',(_request,response)=>{
      if(!current()){response.resume();return;}
      if([401,403].includes(response.statusCode)){
        c.blocked=true;c.status='no_access';
        c.reason='Index authentication or access was denied. Verify your production Kalshi key and feed access.';
      }
      response.resume();ws.terminate();
    });
    ws.on('error',()=>{if(current())ws.terminate();});
    ws.on('close',()=>{
      this.clearInterval(c.timer);
      if(!current())return;
      c.ws=null;
      if(!c.blocked){
        c.status='reconnecting';c.reason='Index disconnected; retrying with backoff.';
        c.retryAt=this.now()+Math.min(30000,2000*2**Math.min(c.attempts++,4));
      }
    });
    ws.on('pong',()=>{ws.waitingIndexPong=false;});
    c.timer=this.setInterval(()=>{
      if(!current())return;
      if(!b.running&&this.now()-(b.lastPoll||0)>20000){this.close(b);return;}
      if(ws.readyState===1){
        if(ws.waitingIndexPong)ws.terminate();
        else{ws.waitingIndexPong=true;ws.ping();}
      }
    },10000);
    c.timer.unref?.();
    return c;
  }
  snapshot(b){
    const c=this.ensure(b),now=this.now(),last=c?.last;
    const age=last?Math.max(0,now-last.sourceTime):null;
    const fresh=!!last&&c.ws?.readyState===1&&!c.blocked&&age<=STALE_MS&&last.sourceTime-now<=1000;
    const status=fresh?'live':last&&c.ws?.readyState===1&&!c.blocked?'stale':c?.status||'needs_key';
    const reason=fresh?'':status==='stale'?'Index value is older than 5 seconds; no live comparison shown.':
      c?.reason||(!b.creds?'A verified production Kalshi API key is needed for this index, including in Paper.':
        'A production Kalshi key is needed. Demo credentials cannot connect to this live index.');
    const strike=b.market?.strike;
    const result={indexId:assets[b.settings?.asset??'BTC']?.index,source:'CF Benchmarks via Kalshi',sourceKind:'authenticated_index',status,fresh,
      price:fresh?last.value:null,
      nowDiff:fresh&&typeof strike==='number'&&Number.isFinite(strike)?last.value-strike:null,
      sourceTime:last?.sourceTime??null,receivedTime:last?.receivedTime??null,ageMs:age,
      reason,channel:c?.channel??null};
    return fresh?result:this.publicSnapshot(b)||result;
  }
  // Observe the same reference without connecting, fetching, or refreshing caches.
  peek(b,now=this.now()){
    if(!this.enabled||!Number.isFinite(b.market?.strike))return null;
    const c=this.clients.get(b);
    const authenticated=!!b.creds&&c?.creds===b.creds&&c.ws?.readyState===1&&!c.blocked;
    const recent=p=>p&&now-p.sourceTime<=STALE_MS&&p.sourceTime<=now+1000;
    const useIndex=authenticated&&recent(c.last);
    const asset=b.settings?.asset??'BTC';
    const last=useIndex?c.last:this.publicCache.get(asset==='BTC'?b.market.eventTicker:`${asset}:${b.market.eventTicker}`)?.last;
    if(!recent(last))return null;
    return {sourceKind:useIndex?'authenticated_index':'public_chart',
      nowDiff:last.value-b.market.strike,sourceTime:last.sourceTime,receivedTime:last.receivedTime};
  }
}
module.exports={KalshiIndex,PATH,URL,STALE_MS};
